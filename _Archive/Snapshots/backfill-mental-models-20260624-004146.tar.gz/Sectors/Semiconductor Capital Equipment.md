---
date: 2026-04-22
last_updated: 2026-04-30
tags: [sector, moc, semiconductors, WFE, capital-equipment, KLAC, AMAT, LRCX, ASMI, TEL, BESI]
status: active
sector: Semiconductor Capital Equipment
---
> [!tip] 2026-04-29 → Addressed 2026-04-30 [[pinned]]
> **Prompt:** *Does semiconductor and semi-cap permanently re-rate as cyclicality is removed from the industry. Traditionally semis were attached to the industrial cycle. Furthermore, price volatility and coupled with customer hoarding due to perception of cyclical shortages produced extreme drawdowns in revenue especially for equipment makers who are second derivative from industry revenue. As we move to the AI dominated era, where all semi coompanies exercise pricing power after being consolidated the various variables that made semi-cap extremely cyclical are removed - a) AI is a single industry that is secular not coupled to industrial cycles, 2) semi vendors do not increase capacity above short term demand, 3) there is no need to drop prices as inventory accumulation no longer occurs as there is an ongoing shortage.*
>
> **Response:** Re-rating thesis valid but conditional. All three drivers (demand decoupling, capacity discipline post-consolidation, shortage persistence preventing inventory glut) are quantitatively breaking down — historical 50% drawdown risk has shifted to 25-30% on AI-deceleration scenarios, with ~50%+ multiple-expansion headroom from cyclical (15-25x trough) to structural (40-50x sustained). Counter-cycle invalidators: DeepSeek/TurboQuant memory-efficiency breakthroughs, hyperscaler capex deceleration below the $600-750B floor, MATCH Act servicing ban. Full analysis: §Investor heuristics → Where consensus could be wrong → Insight #7 (cyclicality-discount mispricing).

# Semiconductor Capital Equipment

> **Map of Content** — The picks-and-shovels layer of the AI infrastructure stack. Every chip revenue dollar requires upstream equipment capex at a structurally rising rate: **the cycle has shifted from capacity (more wafers) to complexity (more tool steps per wafer)**. WFE guided $135.2B in CY2026 (+9.0%, SEMI Apr 2026) and $156B in CY2027 against four simultaneous technology inflections — GAA logic at 2nm volume, HBM4 16-Hi on microbump (HBM5 hybrid bonding deferred to 2028-2029 per JEDEC's April 900µm relaxation), 400-layer 3D NAND requiring cryogenic etch in HVM 2026, and CoWoS scaling 75-80K → 120-130K wafers/month — for the first time in the industry's history.
>
> This sector note also serves as the basket-level investment hub for the SEMICAP multi-ticker thesis (KLAC, AMAT, LRCX, ASMI, TEL, BESI) — see `## Investor heuristics` for portfolio positioning. Prior `Theses/SEMICAP - Semiconductor Capital Equipment` thesis was merged into this note 2026-04-29 and archived.

## Active Theses

*Scope: Equipment-Specific — Core WFE basket (Tier 1 + Tier 2 per `## Investor heuristics > What to own`)*
- [[Theses/KLA - KLA Corporation]] — **HIGH conviction (Apr 29 init).** The yield monopoly. ~63% process-control share with intensity rising 100-200bp/node × 56-63% share × 13-15% service annuity × 70% AP growth = 4 independent compounding legs vs typical 1-2 at peers. 73% ROIC sector-best; $26B 2030 IDay target
- [[Theses/AMAT - Applied Materials]] — **MEDIUM (Apr 29 init).** The value trade. ~31x P/E vs LRCX 48x / ASMI 45x; >20% guided CY26 equipment growth; EPIC Center 5–10yr customer lock-in; 9% BESI stake = Kinex hybrid-bonding optionality
- [[Theses/LRCX - Lam Research]] — **MEDIUM (Apr 29 init).** The vertical-scaling specialist. Q3 FY26 print revealed structural mix shift to 59% Foundry/Logic; 4 vectors compound (Akara GAA + Aether dry resist TOR + Cryo 3.0/ALTUS Halo + AP +40% CY26); 2028 IDay $25-27B / 50% GM / $6-7 EPS
- [[Theses/ASMI - ASM International]] — **MEDIUM (Apr 29 init).** Pure GAA play. ~55% single-wafer ALD share with $400-500M SAM expansion per node; POR annuity reframe (5-7yr lock per node win); 1.4nm slot count (TSMC pilot H2 2026) the binary catalyst
- [[Theses/BESI - BE Semiconductor Industries]] — **MEDIUM (active).** 3D-integration monopoly miscategorised as HBM-timing play; LRCX/AMAT dual takeover interest; ~67% D2W hybrid-bonding share with 150+ installed base; March 2026 SK Hynix mass-production Kinex order is logic/DRAM, not HBM

*Scope: Equipment-Specific — Photonics/test picks-and-shovels (Tier 3 asymmetric, also see [[Sectors/Photonic Metrology]] sub-cluster)*
- [[Theses/AIXA - Aixtron]] — **MEDIUM (Apr 29 init).** German MOCVD equipment maker repricing from cyclical SiC/GaN supplier to dominant InP photonics tool vendor; G10-AsP near-monopoly economics in 6-inch InP MOCVD subset; equipment-cycle valuation arbitrage to LITE/COHR/NVDA at thesis-cycle multiples
- [[Theses/FORM - FormFactor]] — **MEDIUM (Apr 29 init).** Sole US-listed pure-play probe-card vendor (~31% global share); HBM4 16-Hi second-derivative test-intensity inflection sell-side models as flat; CPO/optical-probe optionality; 130x trailing P/E gates HIGH until Q1 2026 print confirms ramp
- [[Theses/AEHR - Aehr Test Systems]] — **MEDIUM (Apr 29 init).** Sole commercial wafer-level burn-in (WLBI) platform at scale for AI accelerators >600W TDP, SiC, GaN, and silicon-photonics dies; Q3 FY26 bookings $37.2M / b-t-b >3.5x; 4-7yr competitive qualification gap is the moat

*Scope: Equipment-Adjacent (demand drivers)*
- [[Theses/LITE - Lumentum]] — Photonics/EML supply chain; demand driver for SiPh test equipment (FORM, AEHR) and photonics foundry capacity (TSEM, GFS)
- [[Theses/NVDA - Nvidia]] — 60%+ of TSMC CoWoS bookings 2026-27; primary demand driver across etch/deposition/inspection/bonding
- [[Theses/285A - Kioxia]] — NAND 332L → 400L roadmap drives TEL cryogenic-etch (2026 HVM) and Kokusai/LRCX batch-thermal demand
- [[Theses/SNDK - SanDisk]] — HBF (hybrid-bonded flash) is a second hybrid-bonding TAM vector beyond HBM; pilot line accelerated 6 months to H2 2026
- [[Theses/IQE - IQE]] — III-V substrates enabling photonics equipment supply chain
- [[Theses/TSM - Taiwan Semiconductor]] — Leading-edge foundry monopoly; primary WFE customer; Taiwan-tail anchor for sector customer-concentration risk

---

## Key industry questions

1. **Is CY2026 WFE actually $135B, $145B, or higher?** SEMI's April 2026 mid-year update guides WFE $135.2B (+9.0%) and broader semi equipment $145B (2026) / $156B (2027). Worldwide 300mm fab equipment spending alone is guided +18% to $133B in 2026 / +14% to $151B in 2027. Bank of America projects $131-150B. **Every $10B of WFE maps to ~$3B of LRCX+AMAT+KLAC combined revenue.** Variance is almost entirely China spending assumption.

2. **Advanced packaging as % of WFE by 2028?** Today ~10% (~$12B on KLAC's CY2026 guide). TSMC CoWoS scaling 75-80K → 120-130K wafers/month by late 2026 (3.7x since 2024); logic hybrid-bonding transition (TSMC SoIC, Intel Foveros Direct) independent of HBM timing. Packaging equipment could reach **15-20% of WFE by 2028**, re-ordering relative importance of LRCX (TSV etch, ECD), KLAC (3x inspection intensity), BESI (hybrid bonding), AMAT (CMP, bond prep).

3. **Does Chinese domestic equipment share keep rising at +10pp/yr?** Domestic equipment share hit **35% in 2025**, beating the 30% target and up from 25% in 2024; etch and thin-film deposition already exceed 40%. NAURA reported FY2025 revenue CNY 39.35B (~$5.4B, +30.85% YoY); AMEC's 5nm etch validating at TSMC. Roadmap targets 50-60% by 2030. **Every 5pp of China share shift removes ~$4-5B from Western vendors' TAM.** How quickly can Chinese vendors move to 14nm? At 7nm?

4. **Does the GAA transition actually triple ALD/selective-etch SAM?** ASMI claims 12%+ CAGR through 2030 on GAA; LRCX guides GAA revenue "triples" CY2026; AMAT guides equipment growth >20% CY2026. TSMC N2 reached volume Q4 2025 with both Taiwan fabs sold out for 2026; Samsung SF2P hit 70% yield Jan 2026; Intel 18A entered HVM Jan 21, 2026 at 30K wafers/quarter. **If overstated by 30%+, ASMI/LRCX are 25-35% overvalued at current ~40-48x forward.**

5. **When does hybrid bonding transition from pilot to volume — and for what?** JEDEC's April 2026 proposal to relax HBM package thickness to ~900µm (from original 775µm draft) allows HBM4 16-high stacks with existing microbump/MR-MUF technology, pushing mandatory HBM hybrid-bonding to **HBM5 (2028-2029)**. **Logic-side is already there:** SK Hynix placed first mass-production Kinex order March 2026 (AMAT + BESI integrated D2W); TSMC SoIC expanding to 50K wafers/month by 2027; BESI has 30 bonders deployed across 6 integrated logic production lines at a leading customer.

6. **How much of the cycle is AI-driven vs cyclical?** Hyperscaler CY2026 capex projected $600-750B (Amazon $200B, Google $175-185B, Meta $115-135B, Microsoft $120B+, Oracle $50B), ~75% AI-directed — 36% YoY growth, unprecedented multi-year floor. Memory capex: Samsung $20B (+11%), SK Hynix $20.5B (+17%), Micron $13.5B (+23%). A DeepSeek/TurboQuant-style inference-efficiency breakthrough could hit WFE cyclically 20-30% harder than broader tech, but GAA migration and 400L NAND cryogenic-etch provide independent demand legs.

7. **High-NA EUV adoption — 2 customers or 6 by 2030?** Intel leads with world's first commercial High-NA line at 30K wafers/quarter for 18A (Fab 52 Chandler, HVM January 2026); Samsung received first EXE:5200B late 2025, second unit H1 2026 at Taylor Texas; SK Hynix installed first unit September 2025; imec took delivery March 2026 (~12 EXE:5200s worldwide). TSMC deferred High-NA for 1.4nm. ASML guides 5-10 High-NA deliveries in 2026. At >€350M per tool, customer absorption capacity is the gating variable. Sub-6 customer adoption doesn't threaten ASML's EUV monopoly but caps revenue-per-tool dynamics.

8. **Is the CoWoS bottleneck permanent or transient?** TSMC capex $52-56B 2026 (+27-40% vs $40.9B 2025), 10-20% to advanced packaging; CoWoS outsourcing 240-270K wafers annually to Amkor (180-190K) and SPIL (60-80K). CoPoS (large-panel packaging) and glass substrates could render round-wafer CoWoS capacity partially obsolete — and the timing has pulled IN, not out: June-2026 reporting shows CoPoS pilot line completing ~June 2026, 2027 pilot production, and 2028–29 mass production at AP7 Chiayi (NVIDIA Rubin anchor), reversing the March-2026 "Q4 2030 at earliest" delay (see [[Macro & Technology/CoWoS-to-CoPoS Panel-Level Packaging Transition]]). The CoWoS-lifecycle-extension assumption weakens accordingly — round-wafer interposer capacity faces a panel-format transition on the 2028–29 horizon: a tailwind for panel-format litho (Onto JetStep, SUSS), path-agnostic inspection (KLA), bonding (BESI), and dicing (DISCO); a relative headwind for round-wafer-locked tooling.

9. **Taiwan tail risk — is semicap modelling it right?** TSMC's N2 (Fab 20/22, Hsinchu/Kaohsiung) and CoWoS capacity (Chunan/Kaohsiung AP7) are geographically concentrated. [[Research/2026-04-19 - TSM - Stress Test]] estimates a -85-95% Taiwan permanent-impairment scenario would consume **100% of ASML global EUV output for 12-18 months on rebuild**. Arizona buildout represents only 5-8% of TSMC's capacity through 2030. Sector's customer-concentration risk is higher than current valuations reflect.

10. **Does Section 232 / MATCH Act widen to equipment?** January 15, 2026 Proclamation imposes 25% tariff on narrow advanced-logic chip imports. April 2, 2026 MATCH Act introduced in House proposes extending controls to DUV immersion litho **and servicing of existing equipment in China** — the stealth risk vector since servicing is where the recurring-revenue annuity lives. ASML China exposure already guided down to ~20% of 2026 sales (from 33% in 2025). 150-day window for Netherlands/Japan to tighten before unilateral US action.

11. **AMAT CY2026 growth execution.** Management guided >20% equipment growth — a 15-percentage-point acceleration from FY2025's 4.4%. Both ICAPS recovery and GAA ramp must materialise. Q2 FY26 earnings (May 2026) will be the first read.

12. **LRCX foundry/logic mix durability.** LRCX achieved 59% Foundry/Logic revenue in Q2 FY26 (vs historically memory-heavy mix). Structural (permanent GAA etch share gains) or cyclical (temporary memory order weakness)? **If structural, LRCX deserves a permanent re-rating toward logic multiples.**

---

## Industry history

**1960s-1980s — Fragmented tool makers supply integrated device manufacturers.** Semicap emerged as captive supply to US memory and logic incumbents (IBM, Intel, TI, Motorola). Japanese entrants — Tokyo Electron (founded 1963 as an importer; first domestic tool 1968), Canon, Nikon — became global scale players during Japan's 1980s memory dominance. **TEL was the world's largest semiconductor production equipment company from 1989-1991**, displaced by Applied Materials thereafter. Trade friction between US and Japanese semicap producers culminated in the 1986/1991 US-Japan Semiconductor Agreements, restraining Japanese tool exports for the better part of the 1990s.

**1990s — US consolidation and ASML's lithography takeover.** Applied Materials scaled through aggressive M&A under James Morgan and later Mike Splinter (~21+ acquisitions historically), building the broadest portfolio in the industry. **KLA merged with Tencor in April 1997** ($1.3B all-stock) to consolidate inspection (KLA) and metrology (Tencor) into the dominant process-control franchise that exists today. ASML emerged from Philips (founded 1984, IPO 1995) and displaced Nikon and Canon in DUV lithography through TWINSCAN dual-stage architecture, reaching ~94% lithography share by the 2010s. Nikon's dominance in i-line and DUV gave way as ASML-led ArF immersion (co-developed with Carl Zeiss) became standard for 90nm and below.

**2000s — Memory consolidation, foundry rise.** WFE cycles became violently cyclical as memory pricing swings drove capex step-functions. **The 2007-2009 downturn collapsed DRAM producers from 9 to 3** (Samsung, SK Hynix, Micron) — concentrating customer power. **TSMC emerged as a dominant foundry customer** under Morris Chang, shifting equipment demand from IDM to pure-play foundry and creating the multi-decade flywheel that made foundry CAPEX the largest single line of WFE.

**2010s — EUV inflection, failed megamerger, Chinese ascent.** ASML's 2012 customer co-investment program (Intel, TSMC, Samsung took combined ~€1.4B equity stakes; Intel's stake was the largest at €829M for 15%) funded the EUV ecosystem when no single vendor could absorb the technology risk. **Applied Materials and Tokyo Electron announced a $30B+ merger on 24 September 2013**; it collapsed on 27 April 2015 under US/Chinese antitrust concerns. The failed combination preserved today's oligopoly structure. ASML shipped first EUV production tools in 2019, enabling 7nm volume; Carl Zeiss SMT became the locked-in optics partner. China's "Made in China 2025" plan (2015) seeded the domestic equipment industry that now matters.

**2020-2024 — Supply-chain crisis, export controls, AI pivot.** COVID's semi shortage elevated semicap to strategic-infrastructure status. **US October 2022 export controls** (BIS) and **Dutch 2023-2024 restrictions** (NXT:2050i and below) blocked EUV and advanced DUV shipments to China. 2023 memory glut drove WFE down to $95-100B; 2024 recovered to $104B on AI. Chinese domestic equipment vendors (NAURA, AMEC, Piotech, ACM Research, SiCarrier) scaled rapidly under indigenisation pressure, capturing share at 28nm and below.

> [!question] 2026-04-29 → Addressed 2026-04-30 [[pinned]]
> **Prompt:** *How would you quantify Chinese WFE's technology lead from the perspective of node generations lag and yield lag vs. best of breed western equipment. What is the rate of improvement we are seeing in China and when would they present a credible competitor.*
>
> **Response:** Asymmetric gap closure — fastest in etch/CVD (2027-2029 7nm/14nm parity, 10-15pp yield lag at 14nm today), structurally widest in process control and EUV lithography (likely never at parity while export controls hold, no defect-physics or Carl Zeiss optics IP equivalent). Domestic share rose 25% → 35% in 2025 (+10pp/yr), beating the 30% target; roadmap targets 50-60% by 2030. NAURA FY2025 ~$5.4B revenue (+31% YoY) is the only Chinese vendor at Tier-2-Western scale; AMEC's TSMC 5nm validation remains pre-HVM. Hybrid bonding has zero Chinese capability. Full quantification table by category (etch/CVD/ALD/DUV/EUV/process control/HB/test) with production-grade nodes, qualification status, yield lag, and credible-competitor horizon: §Competitive dynamics → Chinese equipment — node and yield gap quantification.

**2025 — Complexity supercycle begins.** AI capex drove CY2025 WFE to ~$115B. TSMC entered N2 volume production in Q4 2025 with both Taiwan fabs sold out for 2026; Samsung qualified SF2P (30% → 70% yield trajectory ending at stable-production threshold January 2026); Intel 18A progressed toward HVM. **Applied Materials acquired 9% of BESI April 2025** at €107.50/share (a strategic position, not a takeover). China domestic equipment share jumped 25% → 35%, beating the 30% target — the structural Western-share-loss narrative cemented.

**2026 — Inflection year.** (i) **Intel 18A HVM launched January 21, 2026** at Fab 52 Chandler with the world's first commercial High-NA EUV production line (30K wafers/quarter). (ii) SEMI's April 2026 update raised CY2026 broader semi equipment to $145B, WFE to $135.2B, CY2027 to $156B. (iii) **January 15, 2026: Section 232 25% tariff on narrow advanced-logic chips.** (iv) **February 2026: BESI Q4 2025** — €166.4M rev (+25.4% QoQ), €250.4M orders (+43.3% QoQ, +105.4% YoY), 150+ installed hybrid bonders at 18 customers. (v) **March 2026**: Axcelis-Veeco shareholder approval obtained for $4.4B all-stock merger (close H2 2026, pending Chinese regulatory); **SK Hynix placed first mass-production Kinex order** (AMAT + BESI integrated D2W); imec received EXE:5200; Reuters reported **dual LRCX/AMAT takeover interest in BESI**. (vi) **April 2026**: JEDEC relaxed HBM package height to ~900µm — HBM4 16-Hi stays on microbump/MR-MUF, hybrid-bonding transition deferred to HBM5 (2028-2029); ASML Q1 €8.8B rev / €38.8B backlog / FY guide raised to €36-40B; ASMI Q1 €863M with record 33.1% op margin; AMAT Q2 FY26 guide $7.65B; **MATCH Act introduced** extending DUV immersion controls and servicing controls to China.

**Pricing-power trajectory summary.** EUV unit prices rose ~$120M (NXE:3400) → ~$200M (NXE:3800) → **>€400M (EXE:5200 High-NA)** — a ~3.3x ASP inflation across a single decade. BESI hybrid bonder ASPs rose ~20% Gen-1 → Gen-2 with Gen-3 development underway. AMAT Sym3 etch tool ASPs **roughly doubled** across the FinFET-to-GAA transition. Service/installed-base revenue (LRCX CSBG, AMAT AGS, KLAC services) grows at stable double digits regardless of capex cyclicality, reflecting the annuity embedded in 45,000+ AMAT tools and 100,000+ LRCX chambers globally. KLAC raised service CAGR guide to 13-15%, targeting **~$6B service revenue by 2030**.

---

## Competitive dynamics

### Oligopoly structure and durability

The top-5 WFE vendors (ASML, AMAT, LRCX, TEL, KLAC) capture **~75% of industry sales**. Top-5 composition has been stable for 15+ years; share shifts happen at the margin (±2-3 points per technology transition). Effective monopolies in critical sub-categories: EUV lithography (ASML 100%), EUV mask inspection (Lasertec ~95%, ZEISS now competing on High-NA), coater/developer (TEL ~92%), batch ALD (Kokusai ~70%), D2W hybrid bonding (BESI ~67%), CMP (AMAT ~70%), single-wafer ALD (ASMI ~55%+).

Structural moats:

- **Co-development cycles of 5-10 years.** ASML's EUV required ~20 years and $10B+ industry investment. BESI's Kinex consumed five years of joint development with AMAT. ASMI's high-aspect-ratio ALD development for GAA has been a six-year customer-co-development cycle.
- **Process-of-record qualification creates 12-24 month switching barriers.** Customers Copy Exact tools across fab fleets — once a tool is qualified, it gets ordered again across every node ramp at every fab globally. The cost of changing a process-of-record (POR) tool is measured in **weeks of yield risk per tool** — and yield risk at 2nm GAA can mean millions in lost wafer output per day.
- **Precision requirements increase exponentially with node.** 2nm GAA demands sub-nm defect tolerance; hybrid bonding demands sub-0.5nm copper surface roughness; HBM4 16-Hi inspection requires 3x the photon energy precision of HBM3E. New entrants cannot close the gap as it widens.
- **Customer concentration creates symbiotic capture.** Top-5 chipmakers = 65-75% of WFE purchases. TSMC alone is ~25-30% of all WFE; Samsung ~15%; Intel ~10% (rising on 18A HVM); SK Hynix ~8%; Micron ~5%. The number of customers a new entrant must qualify with to be commercially viable (3-5) is roughly equal to the customer base.

> [!question] 2026-04-29 → Addressed 2026-04-30 [[pinned]]
> **Prompt:** *Realistically equipment share changes only shift between major node generations. What evidence have there been of share changes within node generations or within similar node generations and process architectures. I'm trying to quantify extent of stickiness or entrenchment of equipment slots.*
>
> **Response:** ~80-90% of share shifts occur between node generations; ~10-20% within node, traceable to four specific catalysts (yield failure at incumbent, new tool variant mid-cycle, geopolitical/commercial dispute, tool architecture change). Recent within-node examples in three of the four catalyst types over the last 24 months: KLA gaining at Samsung 3nm on yield issues; LRCX SABRE 3D doubling AP revenue 2024 displacing AMAT TSV-fill at TSMC; ASMPT taking SK Hynix TC-bonder share from Hanmi (~100-unit Dec 2025 order); TEL cryogenic-etch entering 400L NAND. Switching cost ~$100-300M per fab plus yield risk in millions/day at 2nm — challenger tools require 30%+ specification advantage to even trigger evaluation. POR slot wins at node transitions lock in 5-7 years of compounding revenue via Copy Exact across customer fabs. **GAA at 2nm and BSPDN/CFET at 1.4nm are the most consequential POR battlefields now.** Full analysis with catalyst-table examples and stickiness math: §Competitive dynamics → Within-node vs between-node share dynamics.

### Market share trajectory by category (CY2025 vs CY2020)

| Category                      | Top Vendor        | 2020 Share   | 2025 Share | Direction | Driver                                                 |
| :---------------------------- | :---------------- | :----------- | :--------- | :-------- | :----------------------------------------------------- |
| Lithography (overall)         | ASML              | ~90%         | ~94%       | ↑         | EUV monopoly extends to High-NA                        |
| EUV mask inspection           | Lasertec          | ~100%        | ~95%       | ↓         | ZEISS AIMS EUV 3.0 launched Sep 2025 (High-NA capable) |
| Coater/developer              | Tokyo Electron    | ~90%         | 90%+       | →         | Every EUV fab requires TEL track                       |
| Etch                          | Lam Research      | ~46%         | ~45-50%    | →         | GAA selective etch offsets China loss                  |
| Deposition (single-wafer ALD) | ASM International | ~50%         | ~55%+      | ↑         | GAA adds ~$400M SAM per 100K wafer starts              |
| Deposition (batch ALD)        | Kokusai Electric  | ~65%         | ~70%       | ↑         | Batch thermal scaling with 3D NAND recovery            |
| Process control               | KLA               | 50% (2010)   | ~63%       | ↑         | Defect intolerance at 2nm/HBM; AP +70% CY25            |
| Ion implant                   | Applied Materials | ~70%         | ~70%       | →         | Axcelis gaining in SiC niche                           |
| Hybrid bonding (D2W)          | BESI              | N/A pre-2020 | ~67%       | new       | D2W platform with AMAT Kinex partnership               |
| SoC test                      | Advantest         | ~50%         | ~55%       | ↑         | AI chip complexity growing 2-3x per gen                |
| HBM test                      | Teradyne          | 50%+         | 50%+       | →         | Magnum EPIC remains industry standard                  |
| CMP                           | Applied Materials | ~70%         | ~70%       | →         | Hybrid-bonding prep adds new SAM                       |

**Observation.** Market shares are **stable or rising** for top vendors in every category except EUV mask inspection (Lasertec faces its first credible competitive entry: ZEISS AIMS EUV 3.0 launched September 2025 with High-NA support that Lasertec's actinic tools currently lack). **No other top-5 vendor has lost share at any inflection in the last five years.** This is an unusually durable structural property — the cycle's complexity-driven nature reinforces incumbents because integration debt rises with each transition.

### Within-node vs between-node share dynamics

Equipment share shifts **dominantly happen at node transitions** — POR (process-of-record) qualification creates 12-24 month switching costs that prevent intra-node displacement except under specific catalysts. Quantitatively:

- **Between-node share shifts**: ~80-90% of historic share moves occur at major node transitions (180nm → 130nm → 90nm → 65nm → 45nm → 32nm → 22nm FinFET → 14nm → 10nm → 7nm → 5nm → 3nm → 2nm GAA). Each transition opens 3-5 critical-tool slots that get re-qualified across all customer fabs and locked in via Copy Exact across every subsequent fab build at that node.
- **Within-node share shifts**: ~10-20% of historic moves — and almost always traceable to one of four specific catalysts:

| Catalyst | Recent example | Outcome |
|:---|:---|:---|
| Yield/quality failure at incumbent | Samsung 3nm yield problems 2023-2024 caused redistribution among defect-inspection vendors mid-cycle | KLA gained Samsung process-control share intra-3nm before SF2P ramp |
| New tool variant introduced mid-cycle | LRCX SABRE 3D ECD launched 2022 displaced some AMAT TSV-fill share at TSMC CoWoS within 5nm/3nm cycle | LRCX advanced-packaging revenue doubled in 2024 entirely on within-cycle share gain |
| Geopolitical / supply / commercial dispute | Hanmi-Hanwha patent dispute caused SK Hynix to redistribute TC-bonder share to ASMPT mid-HBM3E cycle (Dec 2025 ~100-unit ASMPT order for HBM4 ramp) | ASMPT gained; Hanmi share at SK Hynix projected to fall majority → 20-30% by 2026 |
| Tool architecture change mid-cycle | TEL cryogenic-etch tool launched 2024-2025 displacing some LRCX dielectric-etch share at 3D NAND mid-roadmap | Material share opportunity for TEL within current 232L → 400L NAND cycle |

**Stickiness quantification.** Once qualified as POR, switching cost is ~$100-300M per fab in re-qualification time, yield risk, and process-development engineer hours — at 2nm GAA, yield risk per tool can be **millions of dollars per day** in lost wafer output. Customer-side cost-benefit math demands that a challenger tool offer **30%+ specification advantage** to even trigger evaluation. This explains why "Market share trajectory by category" (above) shows ±2-3 percentage point movements over **5-year windows** — the magnitude of within-cycle drift is dwarfed by the cumulative effect of POR Copy Exact across new fab builds.

**Implication.** When a vendor wins a POR slot at a node transition (e.g., ASMI winning GAA ALD at TSMC N2), it locks in **5-7 years of compounding revenue** as that node ramps across every customer fab. The opposite is also true: a vendor that loses a POR slot at a transition can take 5-7 years to recover, even if it produces a superior tool mid-cycle. **GAA at 2nm and BSPDN/CFET at 1.4nm are therefore the most consequential POR battlefields in the equipment industry** — the slot wins distribute now and lock in through 2030+. The entrenchment is real but not absolute: the four catalysts above are observable signals that intra-cycle share *can* shift, and have shifted as recently as the last 24 months in three of the four categories.

### Pricing power trajectory

| Segment | Historical (2015-2020) | Current (2023-2026) | Forward (2027-2030) |
|:---|:---|:---|:---|
| EUV litho | Strong (~60% GM) | Dominant (ASML Q1 2026: 53.0% consolidated GM; EUV-specific higher) | Dominant (High-NA extends moat) |
| Etch | Strong (~47% GM) | Rising (LRCX ~49-50% GM) | Rising (cryogenic etch for 400L NAND) |
| Deposition ALD | Good (~47% GM) | Strong (ASMI Q1 2026: 53.3% GM, record 33.1% OM) | Strong (GAA + 3D DRAM additions) |
| Process control | Very strong (~60% GM) | Dominant (KLAC ~62% GM / ~43% OM) | Dominant (3x HBM intensity; AP CAGR teens) |
| Hybrid bonding | N/A | Monopoly-like (BESI Q4 2025: 63.9% GM, Q1 2026 guide 63-65%) | Monopoly-like (Gen-3 in development) |
| Mature-node tools | Good (~45% GM) | Pressured (NAURA/AMEC 28nm competition) | Eroding (Chinese 14nm validation underway) |
| Test | Good (~45% GM) | Strong (AI chip complexity, HBM 10x DRAM test) | Strong (CPO/SiPh test emerging via FORM/AEHR) |

**Pricing-power summary.** The pricing-power trajectory is **uniformly positive** at the leading edge, with the only erosion being mature-node tool ASPs facing Chinese vendor competition.

### Key Metrics — top-6 SEMICAP basket

| Metric                      | KLAC                        | AMAT                    | LRCX                 | ASMI            | TEL                      | BESI          |
| :-------------------------- | :-------------------------- | :---------------------- | :------------------- | :-------------- | :----------------------- | :------------ |
| Market Cap ($B, approx)     | ~105                        | ~170                    | ~115                 | ~35             | ~85                      | ~18           |
| Forward P/E (CY2026)        | ~33-35x                     | ~31x                    | ~38-48x              | ~45x            | ~35x                     | ~45-60x       |
| Gross Margin                | 62%                         | 49%                     | 49–50%               | 53%             | 43–45%                   | 63–65%        |
| Operating Margin            | 43%                         | 29%                     | 34%                  | 33% (record)    | ~25%                     | ~35%          |
| Revenue Growth (latest)     | +7-15%                      | +2% (accelerating)      | +22%                 | +25%            | +10%                     | +30%          |
| WFE Market Share            | ~12% (proc. control)        | ~19% (broadest)         | ~14% (etch/dep)      | ~5% (ALD niche) | ~15% (etch/thermal/coat) | — (packaging) |
| China Revenue %             | ~30%                        | ~31%                    | ~35%                 | ~20%            | ~32%                     | ~20%          |
| Advanced Packaging Exposure | High (3x inspect intensity) | High (CMP, hybrid bond) | High (TSV etch, ECD) | Low             | Low-Medium               | Dominant      |
| Service Revenue %           | ~30%                        | ~25% (AGS)              | ~30% (CSBG $7.2B)    | Low             | ~25%                     | Low           |
|                             |                             |                         |                      |                 |                          |               |
> [!question] 2026-04-29 → Addressed 2026-04-30 [[pinned]]
> **Prompt:** *To what extent does WFE volumes to China since souring of US-China relations represent hoarding of leading edge equipment (fabs at below economic utilisation) that may present a major industry airpocket once this dynamic reverses.*
>
> **Response:** Substantial — estimated $30-50B cumulative Chinese WFE 2022-2025 was front-loaded ahead of export controls, with $15-25B of "ghost capacity" sitting in fabs running at 40-65% utilization (SMIC 14nm, CXMT DRAM, YMTC NAND). China WFE share hit 38-42% peak in 2023-2024 vs ~25% historical norm. Unwind already started: ASML China revenue 36% Q4 2025 → ~20% guide for full-year 2026 (-13pp / $5-7B revenue drop). Airpocket sizing if China share normalizes to 15-20%: **$15-25B incremental revenue gap concentrated in 2026-2027**, hits AMAT/LRCX/KLAC roughly equally; ASMI and BESI least exposed. Service annuity (~$3-4B) is partial offset; tool sales the at-risk line. Reversal vectors: direct fab capacity ramp at SMIC, domestic-displacement-driven second-source insurance demand, geopolitical normalization (low probability through 2028). Position monitoring: ASML China quarterly prints are leading indicator with 6-12 month lag to AMAT/LRCX/KLAC China disclosures. Full sizing, fab utilization data, and reversal-vector analysis: §Macro shifts → G. China WFE hoarding and the airpocket risk vector.

### Chinese equipment — node and yield gap quantification

Western incumbents face **asymmetric gap closure**: fastest in etch and CVD, slowest in process control and lithography. Yield lag at trailing nodes (28nm) has narrowed to single-digit percentage points; at 7nm/14nm production-grade, yield lag is 10-20pp; at leading-edge 2nm GAA, no Chinese equivalent exists. Process control and EUV lithography gaps are structurally widest and unlikely to close while export controls hold.

| Category | Leading Chinese vendor | Production-grade node | Qualification node | Yield lag (vs Western at competitive node) | Years to credible leading-edge competitor |
|:---|:---|:---|:---|:---|:---|
| Etch | NAURA, AMEC | 28nm | AMEC 5nm validated at TSMC; NAURA 14nm at SMIC | 10-15pp at 14nm | 2027-2029 (7nm parity); 2030+ (2nm GAA) |
| Deposition (CVD/PVD) | NAURA, Piotech | 28nm | 14nm in customer qualification | 8-12pp at 14nm | 2027-2029 (14nm parity); 2031+ (GAA-grade) |
| Deposition (single-wafer ALD) | Piotech, NAURA | 28nm conventional | None at high-aspect-ratio | n/a — no GAA capability | 2031+ (GAA precursor parity); structurally blocked without ASMI/AMAT IP |
| Lithography (DUV) | SMEE, SiCarrier (planned) | 90nm | 28nm DUV (SMEE roadmap 2026-2027) | unknown (pre-volume) | 2030+ (28nm DUV); never for advanced immersion without Carl Zeiss optics |
| Lithography (EUV) | None | None | Concept-stage only (Huawei/SMIC/SSMB) | n/a | 15+ years; effectively blocked by Zeiss optics monopoly + export controls |
| Process control / inspection | SMEE, Suzhou Hyc | Trailing-node e-beam metrology | None at advanced inspection | n/a — no defect-physics capability at leading edge | 2030+ at trailing edge; **structurally widest gap, likely never at parity** while export controls hold |
| Hybrid bonding / D2W | None at scale | None | None | n/a | n/a — zero Chinese capability; ASMPT (HK) is the only non-Western/Japanese player |
| Test (SoC, HBM) | Hwacheng (small) | Trailing-node SoC test | None at AI accelerator test | n/a | 2030+ (AI test parity); Advantest/Teradyne moats deep |

**Rate of improvement.** Domestic Chinese equipment share rose **25% (2024) → 35% (2025)** — a 10pp/yr acceleration that beat the 30% target year-end 2025. Most of this is mature-node displacement (28nm and above). Roadmap targets 50-60% by 2030. NAURA FY2025 revenue CNY 39.35B (~$5.4B, +30.85% YoY) — the only Chinese vendor with global scale comparable to a Tier-2 Western peer. AMEC's TSMC 5nm validation (2023) was the first credible leading-edge milestone but remains in qualification — not yet HVM. Etch and CVD are closing fastest because the underlying physics is more replicable from public IP / reverse engineering; lithography and process control require both precision optics (Carl Zeiss monopoly) and decades of accumulated defect-physics tool data that cannot be replicated from a standing start.

**When credible competitor.** Etch and CVD reach **2027-2029 7nm/14nm parity** if current trajectory holds — driving 5-10pp/yr Western mature-node share loss. Process control, lithography (especially EUV), and hybrid bonding likely **never** reach Western parity while US/Dutch/Japanese export controls remain — the precision-physics moats compound with export-control isolation rather than erode under it. Western incumbents are structurally protected at the leading edge through 2030; structurally exposed at trailing nodes throughout the period. **Implication for the basket**: Tier-1 holdings (KLAC, AMAT) face slowest erosion (process control, broadest portfolio); Tier-2 (LRCX, ASMI) face fastest erosion at the etch/CVD layer where Chinese vendors are most capable. AMAT's 31x discount partially reflects this; LRCX's 38-48x does not.

### New entrants and disruption vectors

- **Chinese domestic equipment — the only serious entrant threat.** NAURA (FY2025 ~$5.4B rev, +31% YoY) holds 60%+ share at SMIC 28nm and is pushing 14nm industrialisation with 5/7nm R&D targeted; AMEC's 5nm etch is validating at TSMC; Piotech in CVD; ACM Research in electroplating/wet clean; SiCarrier announced 28nm DUV roadmap extending to upgraded systems by 2026-2027. Western vendors retain leading-edge capability advantage (7nm+) but face structural share erosion at mature nodes at +10pp/yr. Business model: state-subsidised R&D, domestic-only customer base, "good enough" specs at trailing nodes, aggressive reverse engineering. **Leading-edge Chinese substitute remains 5-7 years away but the gap closes fastest on etch and CVD.**
- **ASMPT and Samsung Semes in hybrid bonding.** LITHOBOLT (ASMPT) remains pre-production; Semes captive to Samsung. Both 2-3 years behind BESI in qualification. Low-Medium threat. ASMPT received SK Hynix HBM4 TC bonder order December 2025 (~100 units for Q1 2026 ramp), validating its TC-bonder business but not (yet) its hybrid-bonder.
- **ZEISS in EUV mask inspection.** AIMS EUV 3.0 launched September 2025 with High-NA compatibility — a capability Lasertec's current ACTIS tools do not have. **First credible erosion threat to the 100% Lasertec monopoly.**
- **EV Group and SUSS MicroTec in wafer-to-wafer bonding.** Niche specialists for SoIC and CPO. EVG holds >70% W2W share; D2W approach less suited for heterogeneous integration. Strong IPO candidate for EVG.
- **ASML entering hybrid bonding?** TrendForce reported (March 2026) ASML evaluating hybrid-bonding equipment development — would reshape BESI narrative if confirmed. Speculative.

---

## Product level analysis

### 1. Lithography (~25% of WFE)

Patterning step — transferring circuit designs onto silicon wafers using light.

| Company | Ticker | Share | Key Products | Notes |
|:---|:---|:---|:---|:---|
| **ASML** | ASML | ~94% (EUV: 100%) | TWINSCAN EXE:5200B (High-NA EUV), NXE:3800 (EUV), NXT (DUV) | Q1 2026: €8.8B rev (53.0% GM), €2.8B net income; EUV 66% of system sales (up from 48% prior quarter); High-NA processed 500K+ wafers at 80%+ availability. €38.8B backlog. FY2026 guide raised to €36-40B. China guide ~20% of 2026 sales (vs 33% 2025 / 36% Q4 2025). 5-10 High-NA deliveries planned 2026. **Customers on High-NA today**: Intel (commercial HVM at 30K wafers/qtr), Samsung (2 tools), SK Hynix (1 tool), imec (1 tool, March 2026). TSMC deferred High-NA for 1.4nm. |
| **Canon** | 7739.T | ~5% (DUV/NIL) | FPA-5520iV, Nanoimprint | Niche in mature-node DUV and nanoimprint (Kioxia adoption pending for NAND). |
| **Nikon** | 7731.T | <1% (DUV) | NSR-S636E | Exited advanced litho. Focused on FPD and mature DUV. |

### 2. Etch (~15% of WFE)

Removing material to create circuit patterns. Critical for vertical scaling (3D NAND, HBM TSVs, GAA selective etch, BSPDN).

| Company | Ticker | Share | Key Products | Notes |
|:---|:---|:---|:---|:---|
| **Lam Research** | LRCX | ~45-50% | Vantex (HBM4 TSV), Akara (GAA conductor etch), Sense.i (cryo etch for 3D NAND), SABRE 3D (ECD) | Q3 FY26 consensus $5.76B rev / $1.36 EPS (reports April 22). Q3 guide midpoint $5.7B (+/-$300M), ~49% GM. Advanced packaging guided +40% CY2026 (from $1.5B in 2025). GAA revenue guided "triples" in CY2026. **59% Foundry/Logic mix** (vs historically memory-heavy) — structural re-rate candidate. CSBG $7.2B CY2025. BSPDN and dry-resist processing emerging as next growth vectors. |
| **Tokyo Electron** | 8035.T | ~25-28% | EVAROS, TELINDY, cryogenic etch (10μm-deep etch at -70°C, 2.5x etch rate, 84% GWP reduction) | 90%+ coater/developer share. **Cryogenic etch entering HVM 2026 for 400-layer NAND channel-hole etch — 0% → material share opportunity.** Samsung named as first NAND customer; SK Hynix in test. NAND channel etch TAM: $500M (2023) → $2B (2027). Japan discount vs peers persists. |
| **Applied Materials** | AMAT | ~15-18% | Centura (selective etch), CMP | Competes in selective removal and CMP; not high-aspect-ratio leader. |
| **NAURA** | 002371.SZ | ~5-7% (rising in China) | NAURA Etch | 35%+ share at SMIC 28nm; 14nm industrialisation underway; 5/7nm key-tech R&D targeted. FY2025 rev CNY 39.35B (+31% YoY). |
| **AMEC** | 688012.SS | ~3-5% (rising in China) | Primo nevo, 5nm etch | 5nm etch at TSMC validation — first serious credibility milestone for Chinese vendors at leading edge. |

### 3. Deposition (~20% of WFE)

Thin-film growth: CVD, PVD, ALD, ECD. GAA and BSPDN directly expand ALD content per wafer.

| Company | Ticker | Share | Key Products | Notes |
|:---|:---|:---|:---|:---|
| **Applied Materials** | AMAT | ~30% (CVD/PVD) | Endura (PVD/Mo), Centura (CVD), Producer (ALD) | Broadest portfolio. Pioneered molybdenum interconnects for GAA. FY2025 rev $28.4B; Q1 FY26 $7.01B with $1.04B FCF; Q2 FY26 guide $7.65B ± $500M, EPS $2.64 ± $0.20. Management guides CY2026 semi equipment growth >20%. ICAPS flat YoY (measured recovery after 2023-2024 surge). China ICAPS 27-30% of equipment sales; FY2025 China $8.5B (30%). EPIC Center Silicon Valley creates decade-long customer lock-in (SK Hynix R&D partnership announced March 2026). |
| **ASM International** | ASM.AS | ~55%+ single-wafer ALD | Intrepid (ALD), Epsilon (Epi) | Pure GAA play. Q1 2026: €863M rev (high end of guide), 53.3% GM, **record 33.1% adjusted OM**. Q2 2026 guide €980M ± 5% constant currency, H2 stronger than H1. Each GAA node adds **~$400M ALD SAM per 100K wafer starts**. Advanced-packaging wins progressing. |
| **Lam Research** | LRCX | ~25-30% PECVD | SABRE 3D (electroplating), ALTUS (ALD) | SABRE 3D for TSV copper fill **doubled revenue in 2024**; critical for HBM stack. |
| **Tokyo Electron** | 8035.T | ~15-20% | TELINDY PLUS (batch ALD) | Batch furnace ALD position. |
| **Kokusai Electric** | 6525.T | ~70% (batch ALD) | Vertus | Spun from AMAT (2018). Dominant in batch thermal for high-volume 3D NAND. FY26/3 NAND +15% YoY; high-value-added product ratio 70%+ March 2026. |

### 4. Process Control — Inspection & Metrology (~12% of WFE)

Yield gatekeepers: defect detection, critical-dimension measurement.

| Company | Ticker | Share | Key Products | Notes |
|:---|:---|:---|:---|:---|
| **KLA Corporation** | KLAC | ~63% | 8 Series (e-beam), Surfscan SP7, SpectraFilm | Near-monopoly with best-in-sector margins. Q2 FY26 (Jan 2026): $3.30B rev (+7.2% YoY), $8.68 diluted EPS. FY2025 rev $12.745B (+17% YoY). **Advanced packaging +70% YoY in CY2025**; CY2026 AP guided mid-high-teens growth (~$12B AP market). Q3 FY26 guide $3.35B ± $150M, 61.75% ± 1% non-GAAP GM, EPS ~$9.15. Core WFE CY2026 guided high-single to low-double digits (~low $120B range). Service CAGR raised to 13-15%, targeting ~$6B by 2030. **HBM4 16-Hi requires 3x inspection intensity vs standard DRAM.** |
| **Applied Materials** | AMAT | ~10% | SEMVision, Aera | Smaller player in inspection; integrated metrology. |
| **Lasertec** | 6920.T | ~95% (EUV mask) | ACTIS A200HiT Series (Oct 2025) | Sole vendor inspecting EUV patterned masks through pellicles. **No High-NA capability today** — ZEISS AIMS EUV 3.0 (Sep 2025) is first direct competitor with High-NA support. EUV mask inspection market CAGR ~14%, $3.7B by 2032. |
| **Onto Innovation** | ONTO | ~5% | Dragonfly, Atlas V (OCD/film) | Advanced-packaging specialist (die-to-die / die-to-wafer metrology). Growing with CoWoS/HBM. |

### 5. Ion Implantation & Thermal Processing (~5% of WFE)

Doping and heat treatment.

| Company | Ticker | Share | Key Products | Notes |
|:---|:---|:---|:---|:---|
| **Applied Materials** | AMAT | ~70% (implant) | VIISta | Dominant in silicon implant. |
| **Axcelis Technologies** | ACLS | ~25% (implant), 70-80% (SiC) | Purion (SiC), Purion H200 | Dominant in SiC ion implantation for EV power devices. Shareholder vote for $4.4B all-stock Veeco merger passed March 2026; expected H2 2026 close pending Chinese regulatory approval. Combined entity will be **#4 US WFE supplier**, $5B+ TAM, HQ Beverly MA, Axcelis holders ~58% / Veeco holders ~42%. |
| **Tokyo Electron** | 8035.T | ~60% (thermal) | TELINDY batch | Thermal processing leader. |
| **Kokusai Electric** | 6525.T | ~30% (thermal) | Vertus | Batch thermal specialist. |
| **Veeco** | VECO | Niche (laser spike anneal, thin film) | LSA annealers | Merging into Axcelis H2 2026. |

### 6. Advanced Packaging & Assembly (~10% of WFE; highest growth ~40%+ CY2026)

Die bonding, hybrid bonding, wire bonding, wafer-level packaging. **Growth-leading sub-sector.**

| Company | Ticker | Share | Key Products | Notes |
|:---|:---|:---|:---|:---|
| **BESI** | BESI.AS | ~67% D2W hybrid; 42% die attach | Kinex (inline with AMAT), Gen-2 50nm | Q4 2025: €166.4M rev (+25.4% QoQ, +8.5% YoY), €250.4M orders (+43.3% QoQ, +105.4% YoY), 63.9% GM, €42.8M net (+69% QoQ). 150+ installed hybrid bonders at 18 customers; 30 bonders deployed at 6 integrated logic production lines (with AMAT). Q1 2026 (April 23): guided +5-15% QoQ rev, 63-65% GM. **SK Hynix first mass-production Kinex order March 2026** (AMAT+BESI integrated D2W) — confirmed for logic-line 2nm process / DRAM hybrid bonding, NOT HBM4 (NVIDIA Vera Rubin HBM4 ~70% SK Hynix / 30% Samsung / 0% Micron all on MR-MUF). Reuters March 2026: dual LRCX/AMAT takeover interest. ~€476M hybrid-bonding revenue estimate for 2026 (pre-JEDEC 900µm relaxation; HBM4 hybrid-bonding revenue substantively deferred to HBM5+ 24-Hi 2029-2030). Projected 1,400 systems by 2030 (~€2.8B equipment TAM). |
| **ASMPT** | 522.HK | Growing | LITHOBOLT (hybrid bonder), TC-NCF bonders | Pre-production on D2W hybrid. SK Hynix TC-bonder order December 2025 (~100 units for Q1 2026 ramp) validates TC-bonder business; hybrid-bonder still 2-3 years behind BESI. ~25% of revenue from advanced packaging. |
| **Kulicke & Soffa** | KLIC | Legacy leader (wire bonding) | CuFirst, APTURA FTC | Wire/thermo-compression legacy. CuFirst differentiated but pre-scale. |
| **Hanmi Semiconductor** | 042700.KS | Historic leader at SK Hynix (TC bonders) | Advanced TC bonders | Hanmi-Hanwha patent dispute ongoing. Share at SK Hynix projected to fall from majority → 20-30% by 2026 as HBM4 pitch tightens; Hanmi publicly targeted 2027+ hybrid bonders. 100B KRW hybrid-bonding factory investment targeting end-2027. |
| **Samsung Semes** | Captive | Samsung-only | In-house hybrid bonder | "Lags behind BESI" (36Kr, April 2026). Not competitive externally. Samsung plans partial HBM4E hybrid bonding deployment at earliest. |
| **TOWA** | 6315.T | ~66% (HBM compression molding) | High-density compression molding | Sole-source compression molders for HBM3E/HBM4 MR-MUF stacking — direct beneficiary of JEDEC 900µm extension into HBM4 16-Hi and HBM5 first-gen 16-Hi. New tooling for 16-Hi HBM stacking shipping into SK Hynix M15x and Samsung Pyeongtaek HBM4 ramps. Revenue cadence tracks IDM HBM capex (SK Hynix $20.5B +17% 2026 / Samsung $20B +11% 2026). |
| **Disco** | 6146.T | ~70-80% (HBM wafer thinning/grinding) | DGP8761, DAG810 grinders/dicers | Sole-source wafer-grinding for HBM stack thinning to 30µm (SK Hynix HBM4 16-Hi) and HBM4 dicing. Equipment intensity rises with stack height (more grind/dice passes per Hi); 24-Hi (HBM5+) adds further pass count. Japan back-end specialist; not under US export controls but US-controlled stack thinning depth for Samsung China subsidiaries an emerging risk vector. |
| **EV Group** | Private | ~70% W2W bonding | GEMINI FB/Co-D2W | Wafer-to-wafer specialist for SoIC/CPO. Strong IPO candidate. |
| **SUSS MicroTec** | SMHN.DE | Niche (wafer bonding) | XBC300 Gen2 | D2W platform launched May 2025; unproven at scale. |

### 7. Test Equipment

Wafer-level and final test.

| Company | Ticker | Share | Key Products | Notes |
|:---|:---|:---|:---|:---|
| **Advantest** | 6857.T | ~55% (SoC) / ~70% (GPU memory niche) | V93000 EXA Scale (Pin Scale 5000B, April 2026), T2000/7038 SLT | De facto standard for AI accelerator test. Capacity scaling 3,000 units (July 2025) → 5,000 (2026). "ASML of test" framing. |
| **Teradyne** | TER | ~35% (SoC), 50%+ (HBM) | UltraFLEX, Magnum EPIC / Magnum 7H | Industry standard for HBM wafer-stack test; HBM test ~10x DRAM complexity. Also Universal Robots (robotics). |
| **Cohu** | COHU | Niche | DIAMONDX handler | Test handlers and interface. |
| **Aehr Test** | AEHR | Niche (wafer-level burn-in) | FOX-XP, FOX-NP | Photonics pure-play. Q3 FY2026 (Apr 2026): $37.2M bookings, 3.5x+ book-to-bill, $50.9M effective backlog; new major SiPh transceiver customer + hyperscale optical-interconnect customer (March 2026 follow-on order). 9x 300mm wafer parallel test. CoWoS-packaged device burn-in interest building. |
| **FormFactor** | FORM | Niche (optical + probe) | Optical metrology probes | Optical test is the CPO yield bottleneck — cannot localise loss mechanisms, dramatically slower than electrical test. Advantest partnership on wafer-level HBM. |

### 8. Photonics & Optical Equipment Enablers

Equipment and foundry services enabling copper-to-optical transition.

| Company | Ticker | Role | Notes |
|:---|:---|:---|:---|
| **GlobalFoundries** | GFS | SiPh foundry | Acquired AMF Singapore → world's largest pure-play SiPh foundry. Targeting $1B+ photonics revenue by 2030. 45CLO process. |
| **Tower Semiconductor** | TSEM | SiPh foundry | Tripling photonics capacity by mid-2026. SiGe-integrated process for ultrafast modulators. OpenLight InP-on-silicon partnership. |
| **TSMC** | TSM | SiPh/CPO foundry | COUPE in risk production with NVIDIA (GTC 2025) and Broadcom. Volume 2026. Yields below ideal — outsourcing optical-engine packaging possible. |
| **Fabrinet** | FN | Optical assembly | Nvidia's primary optical assembly partner. Micron-level laser alignment. Gearing for CPO module assembly. |
| **AIXTRON** | AIXA.DE | InP MOCVD epi | G10-AsP near-monopoly on 6-inch InP MOCVD; Nokia G10-AsP confirmed; SMART Photonics + 3 undisclosed laser makers; analogous to ASML EUV monopoly during 7→5nm window. See [[Theses/AIXA - Aixtron]]. |
| **Veeco** | VECO | MOCVD competitor | Targeting 6-inch InP MOCVD product 18-24 months out. Currently 28% MOCVD aggregate share but minimal InP-specific 6-inch presence. |

---

## Acquisitions and new entrants

### Historical M&A — the consolidation record

| Year | Deal | Strategic Objective | Outcome |
|:---|:---|:---|:---|
| 1997 | KLA + Tencor merger ($1.3B) | Consolidate inspection + metrology | Created today's KLA monopoly (63% share). |
| 2012 | Customer Co-Investment Program (Intel/TSMC/Samsung → ASML, ~€1.4B combined) | Fund EUV development through customer equity | Enabled ASML EUV monopoly. Intel's €829M for 15% was the largest stake. |
| 2013 | Applied Materials + Tokyo Electron announced ($30B+) | Create #1 WFE, broader portfolio | **Aborted April 2015 on antitrust.** Preserved current 5-vendor oligopoly. |
| 2018 | Applied Materials + Kokusai Electric announced ($2.2B) | Add batch thermal to AMAT portfolio | **Aborted 2019 on Chinese antitrust delays.** Kokusai IPO'd 2023. |
| 2019 | Entegris + Versum Materials; KLA + Orbotech ($3.4B) | Materials/inspection consolidation | Strengthened KLAC in flat-panel/PCB inspection. |
| 2020-2022 | Lam + SEMSYSCO (ECD); Applied + Picosun (ALD) | Tuck-ins for hybrid bonding/GAA | Integrated into LRCX SABRE 3D and AMAT ALD portfolio. |
| 2023 | Kokusai Electric IPO (TSE) | Post-AMAT-abort independent listing | ~$700M raised; ~$3B market cap. |
| 2025 Apr | AMAT acquires 9% BESI stake (~€840M at €107.50) | Secure hybrid-bonding partnership | Enables Kinex integrated platform; creates takeover option. |
| 2026 Mar | Axcelis + Veeco shareholder approval ($4.4B all-stock) | Create #4 US WFE supplier | Close H2 2026 pending Chinese regulatory; $5B+ TAM; SiC lifecycle one-stop shop. |
| 2026 (reported, pending) | BESI takeover interest from LRCX and AMAT | Acquire advanced-packaging monopoly | Dutch national-security review required; ongoing per Reuters March 2026. |

**Strategic pattern.** Two successful mega-deals (KLA+Tencor, AMAT's 21+ roll-up) produced today's dominant US players. **Two aborted mega-deals (AMAT+TEL 2015, AMAT+Kokusai 2019) preserved the 5-vendor oligopoly** — antitrust authorities in the US and China have effectively become guarantors of the existing market structure. Sub-$5B technology tuck-ins (ECD, ALD, SiC implant) are how incumbents close capability gaps without provoking regulatory blockage. The BESI situation is the first pending advanced-packaging mega-deal and would be the largest equipment M&A since the 2013 AMAT+TEL attempt; Dutch national-security law adds a sovereign-veto layer that did not exist in 2013.

### New entrants and business models

- **Chinese domestic equipment.** NAURA (etch, deposition, thermal), AMEC (etch), Piotech (CVD), ACM Research (electroplating, wet clean), SiCarrier (DUV/EUV aspiration), Huawei/SMIC (in-house tool development). Business model: state-subsidised R&D, domestic-only customer base, "good enough" specs at trailing nodes, aggressive reverse engineering. Impact: Western equipment share at China mature nodes will continue to erode 5-10pp per year. Leading-edge Chinese substitute remains 5-7 years away but gap closes fastest on etch and CVD.
- **ASML in hybrid bonding** (reported, unconfirmed). TrendForce (March 2026) reported ASML evaluating hybrid-bonding equipment development. Would disrupt the BESI / ASMPT duopoly dynamics if real.
- **Specialty disruption candidates.** Aehr Test (photonics burn-in), FormFactor (optical probes), Onto Innovation (3D metrology), ZEISS (EUV mask inspection), AIXTRON (InP MOCVD) — small/mid-cap picks-and-shovels names levered to specific technology inflections.

---

## Macro shifts

### A. The complexity multiplier — the durable variable is equipment per wafer, not wafer volume

Previous WFE cycles scaled with wafer starts. This cycle scales with **process steps per wafer**:

| Transition | Step Count Impact | Equipment Beneficiary |
|:---|:---|:---|
| FinFET → GAA nanosheet | ~350 → 400-600 steps | ASMI (ALD), LRCX (selective etch), AMAT (Mo interconnect) |
| 2D NAND → 400+ layer 3D NAND | Etch aspect-ratio 60:1 → >100:1 | LRCX (cryogenic etch), TEL (cryogenic etch, HVM 2026), Kokusai (batch thermal) |
| Monolithic die → CoWoS | 1 die → multi-die per package | LRCX (TSV etch, ECD), AMAT (CMP), KLAC (3x inspection), BESI (logic hybrid bond), EV Group (W2W) |
| HBM3E (8-12 Hi) → HBM4 (16 Hi microbump/MR-MUF) → HBM5+ (24+ Hi hybrid) | Stack height 825µm → ~900µm (JEDEC Apr 2026) | **Architectural-mandate winners (HBM5+ 24-Hi, 2029-2030)**: BESI (D2W hybrid), AMAT (CMP/Kinex integration). **Logic-line bridge winners (HBM4 / HBM5 first-gen)**: TC bonders (ASMPT taking SK Hynix share, Hanmi 71%→20-30% by 2027), Disco (70-80% wafer-thinning), Towa (66% molding), AMAT EPIC (SK Hynix R&D partnership Mar 2026). **Materials moat (orthogonal to equipment)**: Namics EMC (SK Hynix sole supplier, contract expires; Resonac/Nagase ChemteX backup deliberately under-developed). |
| Front-side only → BSPDN | New wafer-bonding / thinning modules | AMAT (CMP, bonding prep), ASMI (thin-film), EV Group / BESI (wafer bonding), LRCX (BSPDN etch) |
| Copper I/O → Silicon photonics | New photonic modules | FORM, AEHR, TSEM, GFS, FN, AIXA (InP MOCVD epi) |

**Implication.** Equipment revenue per wafer start is structurally increasing at every node transition. Historic revenue-per-wafer-start doubled from 45nm to 10nm; at 2nm GAA it is **30-50% higher** than 3nm FinFET for ALD and selective etch. **Even flat wafer starts produce rising WFE demand** — making the cycle structurally less violent on the downside than 2007-2009 or 2022-2023.

### B. JEDEC HBM4 900µm — the hybrid-bonding timing reset

April 2026 TrendForce reported JEDEC plans to relax HBM package height from the original 775µm draft toward ~900µm, accommodating HBM4 16-Hi (and prospective 20-Hi) stacks on existing microbump/MR-MUF bonding. Consequences:

- **Near-term:** BESI's HBM-derived hybrid-bonding revenue deferred. SK Hynix publicly committed to MR-MUF for HBM4 16-Hi (CES 2026), using 30µm-thinned wafers to stay within 775µm under prior specification; 900µm relaxation cements microbump continuation. Samsung plans partial HBM4E deployment at earliest. **NVIDIA Vera Rubin HBM4 allocation ~70% SK Hynix / ~30% Samsung / 0% Micron initial** — both SK Hynix and Samsung qualify on MR-MUF; the HBM4 architectural shift now happens at HBM5+ 24-Hi (2029-2030), not the first-generation HBM5 16-Hi.
- **Medium-term:** **HBM5+ 24-Hi (2029-2030) becomes the mandatory hybrid-bonding transition point**, not HBM5 first-generation. Pad pitch tightening below 10µm and 24-layer thermal aggregation cross the microbump-feasibility threshold; HBM5 first-gen 16-Hi remains MR-MUF-compatible per JEDEC 900µm envelope.
- **Logic-side is independent.** TSMC SoIC (50K wafers/month by 2027), Intel Foveros Direct, and the March 2026 SK Hynix mass-production Kinex order are all logic/DRAM hybrid bonding — not HBM. BESI's 150+ installed base is predominantly logic. The HBM timing reset does not invalidate BESI's 3D-integration-monopoly framing; it narrows the CY2026-2027 HBM-timing call.
- **Materials moat is orthogonal to equipment.** Namics Corp (Japan) is SK Hynix's sole MR-MUF EMC supplier — the contract expires 2026-2027 and is the single most critical SK Hynix HBM bottleneck per the deep-dive. Resonac and Nagase ChemteX hold backup positions deliberately under-developed to preserve SK Hynix's exclusivity option. This is an equipment-adjacent moat: it does not consume more WFE, but it determines which IDM continues to dominate HBM revenue, which feeds back into IDM capex allocation (SK Hynix +17% 2026 vs Samsung +11%).
- **Implication for SEMICAP basket / BESI thesis:** monitor revenue timing vs €476M 2026 hybrid-bonding estimate; monitor AMAT takeover interest (undiminished by HBM timing since logic integration is AMAT's primary interest). See [[Theses/BESI - BE Semiconductor Industries]] and [[Research/2026-05-11 - HBM Packaging Equipment Stack - MR-MUF to Hybrid Bonding Transition - deep-dive]].

### C. Geopolitical bifurcation

- **China bifurcates into two distinct equipment markets.** *Trailing nodes* (28nm, 45nm) — demand for capacity, served increasingly by domestic Chinese vendors (NAURA/AMEC). Western vendor China revenue declining ~$4-5B/year. *Leading edge* (export-controlled, effectively unavailable) — zero market, but also zero Chinese competitive pressure, **preserving Western pricing power**.
- **US/Dutch/EU export control regime.** October 2022 US BIS + Dutch 2023-2024 + EU 2025 blocked EUV, advanced DUV (1970i/1980i/2100i), advanced deposition/etch tools to China. April 2025 Dutch inspection/metrology rules added ASML and ASM International. Advanced packaging tools not yet restricted — BESI's China exposure (~20% of orders) remains intact but is a future risk vector.
- **MATCH Act (April 2, 2026).** House bill to extend controls to DUV immersion litho **and servicing of existing equipment in China**. 150-day window for Netherlands/Japan to tighten before unilateral US action. ASML already guided China to ~20% of 2026 sales (from 33% in 2025). If passed, **the servicing ban is the incremental damage vector** — recurring-revenue annuity on China-installed base at risk.
- **Section 232 tariffs January 2026.** 25% tariff on narrow "advanced logic" semiconductor imports (NVIDIA H200, AMD MI325X explicitly named); exemptions for US data centers, domestic R&D, startups, public sector. Second-phase proclamation anticipated; equipment formally in scope but not yet subject.

### D. AI capex structural floor

- **Hyperscaler CY2026 capex $600-750B (+36% YoY)**, ~75% AI-directed (~$450B AI infra). Individual: Amazon $200B, Google $175-185B, Meta $115-135B, Microsoft $120B+, Oracle $50B. Free cash flow turns negative at some; debt-funded pivot underway.
- **Memory capex 2026 (cautious vs hyperscaler, focused on HBM).** DRAM total $61.3B (+14% YoY): Samsung $20B (+11%), SK Hynix $20.5B (+17%, M15x HBM4 expansion), Micron $13.5B (+23%, 1-gamma + TSV). NAND $22.2B (+5%). Samsung/SK Hynix reducing NAND to fund HBM/DRAM.
- **TSMC 2026 capex $52-56B (+27-40% YoY).** 70-80% to advanced process; 10-20% to advanced packaging.
- **Three simultaneous inflections.** (1) **Logic**: GAA at 2nm across TSMC (N2 HVM Q4 2025, sold out 2026), Intel (18A HVM Jan 2026 at 30K wafers/qtr, High-NA EUV), Samsung (SF2P 70% yield Jan 2026, Taylor Texas 2nm-first). (2) **Memory**: HBM4 12-Hi mass production Q1 2026; HBM4 16-Hi push H2 2026 on microbump/MR-MUF; HBM5 hybrid bonding 2028-2029. (3) **Advanced packaging**: CoWoS 75-80K → 120-130K wafers/month by late 2026; logic hybrid bonding transitioning now via SK Hynix Kinex March 2026.
- **AI capex deceleration risk.** DeepSeek / TurboQuant-style memory-efficiency breakthroughs or hyperscaler cap-ex pause would hit WFE cyclically 20-30% harder than the broader tech market. GAA and 400L NAND transitions provide partial independent demand.

### E. Customer concentration and Taiwan tail

- **Top-5 chipmakers = 65-75% of WFE purchases.** TSMC alone is ~25-30% of all WFE; Samsung ~15%; Intel ~10% (rising on 18A HVM); SK Hynix ~8%; Micron ~5%.
- **Taiwan concentration risk.** TSMC's N2 (Fab 20/22 — Hsinchu/Kaohsiung) and CoWoS capacity (Chunan/Kaohsiung AP7) are geographically concentrated. Per [[Research/2026-04-19 - TSM - Stress Test]], a -85-95% Taiwan permanent-impairment scenario would consume 100% of ASML's global EUV output for 12-18 months on rebuild. Arizona buildout represents only 5-8% of TSMC's capacity through 2030 and does not materially hedge. Sector's customer-concentration risk is higher than current valuations reflect.

### F. Razor-and-blade economics and the service annuity

Equipment lifecycles run 15-20 years before scrap, with major refurbishments at 7-10 years. Service/installed-base revenue is **typically 30-40% of total** and grows at stable double-digit rates regardless of capex cyclicality, reflecting annuities embedded in 45,000+ AMAT tools, 100,000+ LRCX chambers, and the global EUV/DUV installed base. AMAT's Applied Global Services (AGS) and LRCX's Customer Support Business Group (CSBG, **$7.2B CY2025**) are both $2B+ annuity streams. KLA raised its service CAGR guide to 13-15%, targeting **~$6B service revenue by 2030**. The service annuity is what makes a 2022-2023-style downturn ~25% peak-to-trough at revenue level rather than 50%+.

**Carl Zeiss SMT capacity is currently the binding constraint on ASML EUV throughput** ([[Research/2026-04-24 - Dylan Patel on AI Token Supply and Demand - video-transcript]]) — not ASML's own assembly capacity, not customer demand. Tail-whip pre-payments along the supply chain (Dylan Patel, April 2026) signal demand far exceeds available output through 2027.

### G. China WFE hoarding and the airpocket risk vector

Estimated **$30-50B of cumulative Chinese WFE purchases (2022-2025)** represent equipment installed in fabs running below economic utilization — a multi-year hoarding pattern driven by export-control anticipation, not by current production demand. Quantitative evidence:

- **China WFE share peak.** China captured **38-42% of global WFE in 2023-2024**, anomalously high vs ~25% in 2019-2021. The spike directly correlates to the October 2022 BIS export controls and subsequent Dutch/Japanese tightening, indicating front-loaded purchases ahead of further restrictions rather than organic demand.
- **Fab utilization mismatch — the "ghost capacity" signature.** SMIC 14nm production utilization estimated **40-55%** through 2024-2025; CXMT DRAM ~50-60%; YMTC NAND ~55-65% — substantially below the 80%+ utilization threshold that defines economic operation. Equipment is on the floor; output is not commensurate. Industry-source estimates (Caixin / SemiAnalysis) place China's qualified-but-not-utilized capacity at **~$15-25B equivalent of installed equipment**.
- **ASML China revenue trajectory as canary.** ASML China ran **36% of revenue Q4 2025**; full-year 2025 ~33%; **Q1 2026 guide ~20% for full-year 2026**. The trajectory drop of ~13pp in one year ($5-7B revenue) is the first quantitative signal that the hoarding cycle is unwinding. AMAT (China 30%), LRCX (35%), KLAC (30%), TEL (32%) are likely on similar trajectories with 6-12 month lag to ASML; investor monitoring of quarterly China disclosures across the basket is the cleanest early-warning telemetry.
- **Airpocket sizing.** If China WFE share normalizes to **15-20%** (long-term trend post-export-control regime steady-state), the **incremental revenue gap is $15-25B over 12-24 months** — concentrated in 2026-2027 as inventory works through. Service revenue is a partial offset (~$3-4B annuity continues regardless of new tool sales), but tool sales are the primary at-risk line. The airpocket maps roughly equally across AMAT/LRCX/KLAC; ASMI is least exposed (China ~20%); BESI is least exposed (China ~20% with packaging tools not yet under controls).

**What reverses the dynamic.** (i) **Direct absorption**: a major Chinese fab capacity ramp that consumes the equipment overhang — most likely at SMIC 14nm/7nm via state subsidy, but constrained by yield/scale realities and downstream customer (Huawei, ByteDance) demand limits. (ii) **Domestic displacement acceleration**: Chinese domestic equipment share reaching 50%+ by 2027 forces incumbents at TSMC/Samsung/SK Hynix Chinese subsidiaries to consume Western tools faster as second-source insurance — partially offsetting the hoarding-reversal hit. (iii) **Geopolitical normalization**: any thaw in US-China relations would re-open the order book, but political probability is very low through 2028 election cycle.

**Implication for sector positioning.** The airpocket risk is **partially priced** at AMAT (31x P/E reflects discount); LRCX 38-48x reflects less; KLAC 33-35x less still. KLAC is the most exposed to a MATCH-Act servicing-ban scenario specifically because service revenue is its highest-quality earnings line (13-15% CAGR target, $6B by 2030). **Position monitoring**: ASML China revenue Q2-Q4 2026 prints are the leading indicator; cross-check with AMAT/LRCX/KLAC quarterly China disclosure for 6-month-lagged confirmation. A +5-10pp surprise to the downside on China share in any 2026 quarter validates the airpocket framing and justifies basket de-grossing per `## Investor heuristics > Caution triggers`.

---

## Investor heuristics

### Current consensus

- **Sector view.** AI supercycle is real and durable; WFE grows to $135B (2026) / $156B (2027). Top 5 compounders (ASML, AMAT, LRCX, KLAC, TEL) all rated Overweight by most sell-side. ~31-48x forward P/E range with BESI at premium.
- **Top-pick heuristic.** ASML for the monopoly, LRCX for etch leadership at HBM/GAA, ASMI for pure GAA. KLAC and AMAT treated as "safe" but less interesting.
- **China narrative.** Widely understood as a multi-year headwind; discounted into ~31x forward for AMAT but not fully into ASML (40-48x) or LRCX (38-48x). MATCH Act risk adds new tail.
- **Advanced packaging.** Consensus sees BESI primarily as HBM-timing play; JEDEC 900µm softens near-term HBM urgency, but logic-side hybrid bonding (SK Hynix Kinex order March 2026) continues to surprise positively.
- **Photonics.** Consensus long LITE, COHR, AAOI, AXTI — the laser/transceiver names, up 300-900% over 24 months.

### What is priced in

| Segment | Priced-in Scenario | Forward P/E |
|:---|:---|:---|
| ASML | 12% revenue CAGR through 2030, High-NA success, China ~20% of 2026 | ~40-48x |
| AMAT | 20% equipment growth CY2026 (management guide), ICAPS flat | ~31x |
| LRCX | Advanced packaging +40% CY2026, GAA etch tripling, Foundry/Logic mix stickiness | ~38-48x |
| KLAC | Mid-high-teens advanced-packaging growth CY2026, stable process-control share | ~33-35x |
| ASMI | 12%+ CAGR through 2030, GAA ALD dominance | ~45x |
| TEL | Flat share at top peers despite 92% coater share; cryo-etch optionality not priced | ~35x |
| BESI | Hybrid-bonding transition to HBM5 (delayed); logic continues; premium for LRCX/AMAT takeover option | ~45-60x fwd |
| Advantest / Teradyne | AI chip test growth, stable share | ~30-35x |

### Where consensus could be wrong — seven non-consensus insights

**1. KLA is the most structurally underappreciated compounder in the entire equipment stack.** The market prices it as a mature process-control business (~33-35x fwd) when it is actually the primary beneficiary of rising defect intolerance across every end market simultaneously. HBM4 16-Hi requires **3x inspection intensity vs standard DRAM**; CoWoS doubles process-control spend per unit vs monolithic die. Process-control share rose from 50% (2010) to ~63% (CY2025), with Q2 FY26 (Jan 2026) at $3.30B revenue (+7.2% YoY), 62% gross margin, 43% operating margin — best-in-sector across both dimensions. Advanced-packaging revenue grew 70% in CY2025 to ~$950M; CY2026 guide is mid-high-teens growth on a $12B AP market. Service CAGR was raised to 13-15%, targeting ~$6B by 2030. A DCF anchored on inspection-intensity inflation (KLA content per wafer rising at 8-12%/yr vs WFE's 5-7%) produces ~30% upside from current. **The "process control matures with the node" narrative is exactly backwards — process control compounds *with* the node.**

**2. Applied Materials is the most mispriced large-cap in semicap.** ~31x forward P/E vs LRCX ~48x and ASMI ~45x is a 15-turn discount on stale framing. Every major inflection now flows through AMAT's integrated platforms: **GAA** (molybdenum interconnects on Endura PVD), **BSPDN** (CMP + bonding prep), **hybrid bonding** (9% BESI stake → Kinex integrated platform), **3D DRAM** (epi for vertical channel transistors), **advanced packaging** (CMP + selective etch + thermal). Q2 FY26 guide is $7.65B with management projecting **>20% equipment growth in CY2026** — a 15-percentage-point acceleration from FY2025's 4.4% revenue growth. The EPIC Center in Silicon Valley creates decade-long customer lock-in: TSMC developing 1.4nm inside EPIC Center means Copy Exact mandates AMAT tools in every high-volume fab, and SK Hynix's R&D partnership announced March 2026 deepens the moat. ICAPS guided flat-to-slightly-down for CY2026 represents already-derisked downside; reacceleration in H2 2026 is unpriced upside option. **Best risk/reward in the sector.**

**3. Advanced packaging equipment grows 40%+ regardless of HBM hybrid-bonding timing.** The "when does hybrid bonding inflect" debate is a distraction. CoWoS capacity expansion (75-80K → 120-130K wafers/month by late 2026, 3.7x since 2024), TSV etch intensity, and inspection requirements are all inflecting now on microbump-based architectures. LRCX advanced packaging revenue is guided **+40% CY2026** (from ~$1.5B base); KLA inspection grew **+70% CY2025** entirely on microbump-based HBM3E and CoWoS — zero hybrid bonding contribution. JEDEC's April 2026 relaxation of HBM package height to ~900µm confirms HBM4 16-Hi stays on microbump/MR-MUF; mandatory HBM hybrid-bonding moves to HBM5 (2028-2029). But **logic-side hybrid bonding has already started**: SK Hynix placed first mass-production Kinex order March 2026 (AMAT + BESI integrated D2W); TSMC SoIC scaling to 50K wafers/month by 2027; BESI has 30 bonders deployed across 6 integrated logic production lines at a leading customer. Hybrid-bonding inflection is *additive* upside to a 40%-growth base case, not the base case itself.

**4. The cycle is complexity-driven, not capacity-driven — and this re-orders who compounds.** Historic WFE cycles scaled with wafer-start volume; this one scales with **process steps per wafer** (see Macro shifts > Complexity multiplier). **Implication for stock selection**: re-rate candidates are not those with the most volume exposure but those with rising-intensity exposure — KLA (intensity per package), ASMI (ALD content per node), LRCX (selective etch tripling at GAA), BESI (hybrid-bond per die-stack). Even flat wafer-start volume produces rising WFE demand under this model, making the cycle **structurally less violent on the downside** than 2007-2009 or 2022-2023.

**5. Tokyo Electron is a structural mispricing on Japan discount.** 92% coater/developer share — no EUV fab on Earth operates without TEL tools, and every High-NA EUV ASML ships requires a corresponding TEL track system. ~35x forward P/E vs ASMI 45x and LRCX 48x despite a monopoly position in a critical EUV adjacency, comparable margins (~43-45% GM, ~25% OM), and equal exposure to GAA/HBM/3D NAND. **Cryogenic etch is the bonus**: TEL's tool achieves 10µm-deep etch at -70°C with 2.5x etch rate and 84% GWP reduction, enters HVM 2026 for 400-layer NAND channel-hole etch (Samsung named first customer; SK Hynix in test). Share opportunity: 0% → material in a $2B (2027) TAM. Japan-listed discount and headline China revenue noise mask structural quality that should command parity with Western peers.

**6. The optical equipment enabler chain is the true picks-and-shovels of the photonics supercycle.** LITE (+867%), COHR (+150%), AAOI (+300%), AXTI (+500%) over 24 months have priced in the laser/transceiver supercycle. Optical characterisation is dramatically slower than electrical testing and **cannot localise loss mechanisms** — the actual CPO mass-production bottleneck. Real chokepoints: **FormFactor (FORM)** optical metrology probes, Advantest partnership on wafer-level HBM; **Aehr Test (AEHR)** wafer-level SiPh burn-in (Q3 FY26 $37.2M bookings + $50.9M backlog + March 2026 hyperscale optical-interconnect win); **Tower Semiconductor (TSEM)** tripling SiPh foundry capacity by mid-2026; **GlobalFoundries (GFS)** world's largest pure-play SiPh foundry post-AMF Singapore acquisition (targeting $1B+ photonics revenue by 2030); **Fabrinet (FN)** NVIDIA's primary optical-assembly partner; **AIXTRON (AIXA)** sole-source 6-inch InP MOCVD reactor (G10-AsP). All trade at fractions of laser/transceiver valuations and win regardless of CPO vs pluggable mix. **Highest asymmetric leverage in the sector.**

**7. The cyclicality discount is being mispriced — semicap is in the early innings of a structural re-rating.** Three legacy variables that historically drove 50%+ peak-to-trough WFE drawdowns are simultaneously breaking down. **(i) Demand decoupling from industrial cycles.** Hyperscaler AI capex ($600-750B aggregate CY2026, 75% AI-directed) is governed by token-economics and model-training compute requirements — not by smartphone shipments, auto inventories, or industrial PMI, the three demand vectors that historically drove memory/foundry capex pulses. NVDA/AMD/hyperscaler accelerator demand has been pre-paid through 2027 (Dylan Patel April 2026 tail-whip prepayments per [[Research/2026-04-24 - Dylan Patel on AI Token Supply and Demand - video-transcript]]), structurally smoothing the order book. **(ii) Capacity discipline post-consolidation.** DRAM consolidated 9 → 3 vendors during 2007-2009; NAND consolidation is in progress (Samsung/SK Hynix reducing NAND capex to fund HBM/DRAM); foundry concentrated to TSMC + Samsung + Intel at the leading edge; equipment to a 5-vendor oligopoly. The consolidated structure at every layer means **no participant has incentive to overbuild** ahead of demand. TSMC explicitly under-supplied N2 for 2026 (sold out); Samsung/SK Hynix under-supplied HBM3E throughout 2024-2025; ASML chronically backlogged. The capacity-discipline test will be H2 2027 when N3 capacity rolls off and could redirect to non-leading-edge capacity-build. **(iii) Inventory-glut prevention via shortage persistence.** Multi-year HBM shortage, multi-year CoWoS shortage, multi-year EUV-output shortage (Carl Zeiss SMT capacity binding per `## Macro shifts > F`) all prevent the inventory accumulation that historically triggered price-war cycles. Carl Zeiss SMT capacity is structurally binding — Zeiss capex pause caps EUV TAM at the bottleneck output rate, which simultaneously caps the supply response to any demand spike, locking in shortage-premium pricing. **Implication for valuation.** Semicap historically traded **15-25x at trough** on cyclical multiple compression. Current 30-48x range partially prices structural compounder framing but not fully — the gap between cyclical and structural multiples implies **~50%+ multiple expansion** at full re-rating. The basket today is in middle-innings re-rating; full structural multiples (40-50x sustained) require: (a) AI capex visibility through 2030 (currently visible only to 2027); (b) Carl Zeiss SMT capex announcement materially expanding EUV capacity; (c) successful TSMC N2/A21 ramp without yield disappointment; (d) MATCH Act servicing ban does NOT pass. **Counter-cycle vectors that would invalidate the re-rating thesis**: DeepSeek/TurboQuant-class memory-efficiency breakthroughs cutting per-token DRAM/HBM requirements ≥50%; hyperscaler capex deceleration beyond the current $600-750B floor; export-control servicing ban that strips the 30-40% recurring annuity. **Conclusion**: the cycle has not been eliminated — it has been **dampened, lengthened, and decoupled from the industrial cycle**. The risk is no longer "memory glut → 50% drawdown" but "AI deceleration → 25-30% drawdown over a longer cycle". Re-rating thesis valid but conditional, not unconditional.

### Forward scenarios (Bull / Bear)

**Bull case.** The AI infrastructure supercycle extends through 2030 with WFE reaching $200B+ as every technology transition (GAA, BSPDN, HBM5 hybrid bonding, 3D NAND 400+ layers, CPO) enters volume production simultaneously. ICAPS recovers in H2 2026, providing additional demand. **TSMC builds 6+ N2 fabs plus Arizona A21/A22 greenfield, each requiring $15-20B in equipment.** Memory capex doubles as all three DRAM makers build HBM5 hybrid-bonding lines starting 2028. Advanced packaging equipment reaches 15-20% of WFE. China export controls tighten further (MATCH Act passes), creating pull-forward demand as Chinese fabs rush to stockpile tools and the servicing-revenue annuity remains protected by allowed-list scope. Carl Zeiss SMT capacity expands enough to unlock ASML EUV throughput, triggering a 12-18 month order delivery acceleration. The sector re-rates from "cyclical" to "structural compounder" multiples (40-50x P/E), led by **KLA and AMAT closing their valuation gaps to ASMI/LRCX**. BESI takeover by AMAT or LRCX closes at €175-200/share.

**Bear case.** Hyperscaler capex deceleration in H2 2026 as AI monetisation disappoints, triggering WFE cuts similar to 2022-2023. Memory correction if HBM demand plateaus (DeepSeek Engram / TurboQuant-style memory-efficiency breakthroughs reduce per-model HBM requirements). China equipment stockpiling reverses as export controls prevent tool installation, creating $10-15B in deferred revenue. **GAA yields disappoint at 2nm**, delaying TSMC N2 ramp and pushing out equipment orders. **MATCH Act passes including servicing ban** — recurring-revenue annuity on China-installed base goes to zero at AMAT and LRCX. Tariff escalation disrupts supply chains. JEDEC HBM5 timing slips to 2030, deferring BESI's HBM revenue inflection by 12-24 months. Current 30-48x forward P/E multiples compress to 20-30x in a downturn scenario, **implying 30-40% downside** across the basket.

### Sector-level catalysts (2026-2027)

- **Q2 FY2026 earnings (May 2026):** AMAT growth acceleration test; LRCX advanced packaging momentum; KLAC guidance for CY2026 advanced packaging.
- **BESI Q1 2026 earnings (April 23):** Order momentum following €250.4M Q4 2025 orders (+105% YoY). SK Hynix Kinex qualification update.
- **TSMC CoWoS capacity milestones:** Each 10K wafer/month increment translates to ~$1-2B in incremental equipment demand across the chain.
- **BESI M&A resolution:** Formal bid from LRCX or AMAT would reprice the entire advanced-packaging equipment segment — and force Dutch national-security review timeline transparency.
- **JEDEC HBM5 thickness standard (2027):** Determines hybrid bonding timeline for HBM5 applications.
- **ICAPS recovery confirmation:** Automotive/industrial inventory normalisation drives AMAT earnings surprise.
- **Intel 18A customer wins:** Validates Intel Foundry capex trajectory, which drives incremental WFE demand across the basket.
- **Carl Zeiss SMT capacity expansion announcement:** Currently the binding constraint on ASML EUV throughput; an expansion announcement would materially raise ASML 2027-2028 revenue ceiling.
- **MATCH Act vote / Senate companion bill:** Servicing-ban scope determines downside on AMAT/LRCX China annuity.
- **High-NA EUV customer adoption announcements:** Each new customer beyond current 4 (Intel, Samsung, SK Hynix, imec) materially extends ASML's High-NA TAM.

### Sector-level risks

1. **Cyclical downturn.** Despite "structural" narrative, semicap has always been cyclical. A sharp AI spending correction would hit the sector 20-30% harder than the S&P 500. Service-revenue annuity provides ~25% peak-to-trough cushion at revenue level vs 50%+ historical, but multiple compression is uncapped.
2. **China revenue cliff.** Combined China exposure across the Big 5 is ~30% of revenue. Escalating export controls (MATCH Act servicing ban) could remove $15-20B in annual revenue. **AMAT and LRCX China installed-base annuity is the most exposed.**
3. **Customer concentration.** Top 5 chipmakers = 65-75% of revenue. Any single customer capex cut (Intel financial distress, Samsung memory downturn) has outsized impact.
4. **Chinese equipment self-sufficiency.** NAURA/AMEC are 5-7 years behind at leading edge but closing the gap at trailing nodes. **Long-term structural share loss in China is near-certain**; fastest erosion in etch and CVD.
5. **Taiwan tail risk.** Per [[Research/2026-04-19 - TSM - Stress Test]], a -85-95% Taiwan permanent-impairment scenario would consume 100% of ASML's global EUV output for 12-18 months on rebuild. Sector exposure is higher than current valuations reflect; Arizona buildout (5-8% of TSMC capacity through 2030) does not materially hedge.
6. **Carl Zeiss bottleneck.** ASML EUV throughput is currently constrained by Carl Zeiss SMT optics capacity, not by ASML's own assembly or customer demand. A Zeiss capex pause or yield issue caps the entire EUV TAM at the bottleneck output rate.
7. **JEDEC / hybrid-bonding timing slippage.** If HBM5 hybrid bonding slips from 2028-2029 to 2030+, BESI's revenue inflection delays meaningfully and ~€476M 2026 hybrid-bonding estimate gets re-rated. Logic side is independent and unaffected.
8. **Tariff uncertainty.** Section 232 second-phase proclamation could include semicap equipment formally; current tariff is on chips. Equipment exposure is reciprocal — Japan-listed (TEL), Netherlands-listed (ASML, ASMI, BESI) all face potential US import friction.
9. **Valuation.** Even the "cheap" names (AMAT at 31x, TEL at 35x) are above historical averages. **A mean-reversion implies 20-30% downside before growth bail-out.**
10. **PCN re-qualification cycle.** Iran-war Japanese photo-materials disruption ([[Research/2026-04-24 - Iran War Japan Semiconductor Photo Materials Shortage - news]]) creates ~1-year customer-side fab-evaluation uncertainty for alternate PR/BARC solvents; WFE tool orders tied to fab ramps could slip if Samsung/SK Hynix delay HBM4 12-Hi ramp on material qualification.

### Position monitoring triggers (basket-level)

**Bullish (basket holds at structural compounder framing) if:**
- AMAT Q2/Q3 FY26 results confirm >15% equipment growth trajectory; ICAPS turns positive QoQ in H2 2026
- LRCX foundry/logic mix sustains ≥55% across two consecutive quarters; advanced packaging revenue tracks +40% CY26 guide
- KLAC advanced-packaging revenue growth ≥mid-teens CY26; service revenue tracks 13-15% CAGR target
- TSMC CoWoS capacity ramps to ≥110K wafers/month by Q4 2026
- BESI quarterly orders sustain >€200M with logic-line deployment continuing (≥35 bonders at integrated logic lines by Q4 2026)
- Hyperscaler capex prints ≥$600B aggregate in CY2026 with no major guide cut

**Caution (de-grossing or rotation within basket) if:**
- AMAT CY26 equipment growth guide cut below +12% on either ICAPS persistent weakness or GAA push-out
- LRCX foundry/logic mix reverts below 50% indicating cyclical (not structural) memory-orders weakness
- KLAC advanced packaging guide cut to <high-single-digit growth or process-control share loss to ZEISS at High-NA mask inspection becomes material (>10% share)
- Carl Zeiss SMT capacity expansion delayed past 2027 — caps EUV TAM near term
- BESI HBM5 hybrid-bonding timeline pushes to 2030 (vs 2028-2029 current expectation)
- Multiple compression takes basket P/E below 25x without earnings cuts (multiple-driven derate)

**Defensive (reduce basket weight or exit) if:**
- Hyperscaler capex aggregate cut ≥15% from current $600-750B trajectory
- MATCH Act passes with servicing-ban scope; AMAT/LRCX China annuity revenue revised down ≥30%
- TSMC N2 yield disappointment delays HVM ramp beyond Q2 2026 by ≥6 months
- Chinese domestic equipment captures ≥45% share by 2027 (vs current 35%) — accelerating Western TAM loss
- 2007-2009-style memory glut returns; DRAM capex cut ≥40% over 2 quarters

**Exit basket if:**
- AI-capex-driven WFE thesis breaks: hyperscaler aggregate capex cut >25% with no offsetting demand legs
- DeepSeek / TurboQuant-class inference-efficiency breakthrough cuts memory-per-token requirements ≥50%, collapsing HBM growth and forward DRAM capex
- Chinese leading-edge equipment achieves 7nm production parity at SMIC (5+ years earlier than current expectation)
- Major Taiwan tail event materialises (geopolitical crisis with TSMC capacity impairment >50%)

### What to own — basket allocation framework

The recommended SEMICAP basket prioritises structural compounders trading below peers on stale narratives, with satellite positions in higher-beta names for specific technology exposure.

**Tier 1: Core Holdings (70% of Semicap Allocation)**

| Position | Allocation | Rationale |
|:---------|:-----------|:----------|
| **KLA (KLAC)** | 25% | The yield monopoly. 63% process control share, best-in-class margins (62% GM / 43% OM), and rising inspection intensity across every end market. Advanced packaging inspection grew 70% in CY25. Fairly valued at ~33-35x but the durability and quality of earnings deserves a premium. **Highest-conviction name in the basket.** |
| **Applied Materials (AMAT)** | 25% | The value trade. Broadest portfolio, 31x P/E vs 45-48x peers, >20% guided growth acceleration in CY2026. EPIC Center creates decade-long customer lock-in (TSMC 1.4nm; SK Hynix March 2026 R&D partnership). ICAPS recovery provides additional catalyst. Hybrid bonding exposure via BESI partnership. **Best risk/reward in the sector.** |
| **Lam Research (LRCX)** | 20% | The vertical scaling specialist. 45-50% etch share, dominant in HBM TSV etch, advanced packaging growing >40%. Foundry/logic mix shift (59%) fundamentally de-risks the memory cyclicality narrative. Premium valuation (48x) is justified by structural positioning but limits incremental upside vs AMAT. |

**Tier 2: Satellite Positions (20% of Semicap Allocation)**

| Position | Allocation | Rationale |
|:---------|:-----------|:----------|
| **BESI (BESI.AS)** | 10% | The 3D-integration monopoly. ~67% D2W hybrid bonding share, 150+ installed systems, 30 bonders at 6 integrated logic lines with AMAT. SK Hynix Kinex March 2026 mass-production order signals technology transition is beginning. M&A interest from LRCX/AMAT provides downside floor. Premium valuation (45-60x) requires patience on HBM5 timeline. See [[Theses/BESI - BE Semiconductor Industries]]. |
| **ASM International (ASM.AS)** | 10% | The pure GAA play. 55%+ ALD share with $400M SAM increase per 100K wafer starts at GAA. Record revenue and 33.1% adjusted OM. Premium valuation (45x) is correct — own for GAA architectural validation, not deep value. |

**Tier 3: Asymmetric Opportunity Watch (10% of Semicap Allocation)**

| Position | Allocation | Rationale |
|:---------|:-----------|:----------|
| **Tokyo Electron (8035.T)** | 5% | The overlooked monopoly. 92% coater/developer share, essential EUV partner. Japan discount creates valuation arbitrage vs Western peers with comparable or superior market positions. Cryogenic etch volume deployment in 2026 for 400-layer NAND is a 0% → material share opportunity in a $2B (2027) TAM. |
| **FormFactor (FORM) or Aehr Test (AEHR)** | 5% | Photonics picks-and-shovels. Optical test is the critical bottleneck for CPO manufacturing yield. These are the undiscovered enablers of the photonics supercycle at a fraction of LITE/COHR valuations. AEHR's Q3 FY26 record bookings and March 2026 hyperscale optical-interconnect order is an early signal. **Highest risk, highest potential asymmetry.** |

**Positions to avoid / underweight**

- **ASML at current levels:** Monopoly is real and durable, but at €38.8B backlog and ~40-48x P/E, the upside/downside is symmetric. China revenue decline creates near-term headwind. Better to own the EUV ecosystem (TEL coater/developer, Lasertec mask inspection optionality) at cheaper entry points. ASML is a "fair price for a great business" — not non-consensus.
- **Advantest/Teradyne:** Test equipment is more exposed to smartphone/mobile cyclicality than AI. AI chip test complexity is growing but the companies trade at premiums that reflect this. Less compelling than the core basket names.

### Watchlist (un-positioned, monitoring)

- **Lasertec (6920.T)** — ~95% EUV mask inspection (eroding). ZEISS AIMS EUV 3.0 (Sep 2025) is first credible High-NA competitor. Mask inspection TAM $1.47B (2026) → $3.7B (2032) at ~14% CAGR. Watch for share data in 2026-2027 ASML High-NA delivery cohort.
- **Kokusai Electric (6525.T)** — Batch thermal monopoly (70%+ share). NAND recovery driving FY26/3 +15%. Post-AMAT-abort independent listing. Near-term revenue push into FY27/3.
- **Onto Innovation (ONTO)** — Advanced-packaging metrology specialist. Growing with CoWoS/HBM. Die-to-die / die-to-wafer bonding metrology.
- **Axcelis (ACLS) / Veeco (VECO)** — Merger creates #4 US WFE supplier ($5B+ TAM); H2 2026 close pending Chinese regulatory; SiC lifecycle one-stop shop.
- **EV Group (Private)** — Wafer-to-wafer bonding for SoIC/CPO. ~70% W2W share. Strong IPO candidate.
- **ASMPT (522.HK)** — Second-source hybrid bonder; TC-bonder leader (SK Hynix Dec 2025 ~100-unit HBM4 order). 2-3 years behind BESI on hybrid. Long-dated BESI hedge.
- **Advantest (6857.T)** — AI accelerator test standard; capacity scaling 3K (2025) → 5K (2026). "ASML of test" framing. Watch for 2026 capacity utilisation print.

---

## Related Research

- [[Research/2026-03-20 - Semis - Gemini WFE Equipment Canvas]] — Five-company WFE evaluation (AMAT/LRCX/KLAC/ASMI/TEL)
- [[Research/2026-02-26 - Semis - Gemini Lam vs AMAT Canvas]] — AMAT vs LRCX strategic analysis
- [[Research/2026-03-20 - Lam Research and Applied Materials Evaluation]] — LRCX/AMAT deep dive (Tier-1 supplier outlook for M&A context)
- [[Research/2025-11-27 - Semis - Gemini HBM4 Market Canvas]] — HBM4 technology trajectory, vendor bonding strategies, yield dynamics
- [[Research/2026-01-17 - Semis - Gemini AI Compute HBM Canvas]] — AI compute and HBM demand modeling
- [[Research/2026-01-15 - AI Compute and Memory Demands - HBM Shortage]] — HBM shortage dynamics
- [[Research/2025-11-01 - DRAM HBM Competitive Dynamics]] — Samsung/SK Hynix/Micron HBM competitive dynamics
- [[Research/2026-04-10 - Hybrid Bonding and BESI Revenue Impact]] — Comprehensive hybrid-bonding market, BESI financials, JEDEC dynamics
- [[Research/2026-04-15 - BESI - Hybrid Bonding Market Projections]] — HB market $1.47B → $5.6B (2030) at 25.1% CAGR, D2W positioning
- [[Research/2025-11-01 - BESI - BESI Role in HBM Manufacturing]] — BESI role in HBM hybrid bonding
- [[Research/2025-07-06 - BESI - Analyst Estimates and Valuation Trends]] — BESI analyst estimates, valuation, competitive segment analysis
- [[Research/2025-11-26 - Semis - Gemini Silicon Photonics Canvas]] — SiPh supply chain, BESI Tier 3 enabler
- [[Research/2026-03-10 - LITE - Gemini Photonics CPO Canvas]] — CPO market dynamics, TSMC COUPE architecture
- [[Research/2026-03-09 - Photonics and CPO Investment Outlook]] — Photonics investment outlook
- [[Research/2026-03-18 - CPO Market Entry for Pluggable Optics]] — CPO vendor analysis
- [[Research/2026-03-02 - Chinese Silicon Photonics Threat]] — Chinese competitive dynamics in photonics
- [[Research/2026-04-19 - TSM - Stress Test]] — Taiwan concentration stress scenario; global EUV supply implications
- [[Research/2025-11-27 - HBM4 Breakthroughs and Yields]] — HBM4 vendor yields and capacity diversion
- [[Research/2026-05-11 - HBM Packaging Equipment Stack - MR-MUF to Hybrid Bonding Transition - deep-dive]] — Equipment-cohort bifurcation framework (architectural-mandate vs logic-line bridge winners), Vera Rubin HBM4 ~70/30/0 allocation, Namics EMC materials moat, Disco/Towa Japanese back-end share confirmation, Hanmi 71%→20-30% TC-bonder erosion, JEDEC 900µm pushes hybrid-bonding mandate to HBM5+ 24-Hi (2029-2030)
- [[Research/2025-11-25 - LITE - Silicon Photonics Supply Chain]] — SiPh supply chain depth for LITE
- [[Research/2026-04-24 - Dylan Patel on AI Token Supply and Demand - video-transcript]] — ASML "completely sold out" + TSMC 2028 capex ~$100B implied + tail-whip prepayments; validates complexity-driven supercycle Bull Case across all SEMICAP names
- [[Research/2026-04-24 - Iran War Japan Semiconductor Photo Materials Shortage - news]] — PCN requalification cycle ~1yr creates near-term fab capex timing uncertainty as customers re-evaluate PR/BARC sources
- [[Research/2026-04-29 - AIXA VECO - MOCVD Revenue Exposure to InP Photonics Cycle - synthesis]] — MOCVD exposure analysis driving AIXA equipment-specific positioning
- [[Sectors/NAND Memory & Storage]] — NAND sector dynamics, supply deficit through 2027, YMTC capacity impact on equipment demand
- [[Sectors/Photonic Metrology]] — Sub-cluster covering optical wafer-test, burn-in, and metrology stratum (AEHR FOX-XP wafer-level burn-in + FORM optical probe + ficonTEC alignment); Insight #6 (photonics picks-and-shovels) maps directly to this sub-cluster's named candidates
- [[Research/2026-05-24 - 2802 vs 6857 - Competitive Comparison]] — Ajinomoto ABF substrate (2802.T) vs Advantest HBM/SoC test (6857.T) comparison; test-equipment-tier (Advantest) picks-and-shovels framing parallel to ABF substrate moat — backend complement to upstream WFE basket, validates Watchlist Advantest 3K→5K (2025-2026) test capacity print as monitorable signal
- [[Research/2026-05-29 - Earnings Transcripts vs Thesis - 6 Holdings - synthesis]] — earnings-transcript review; Aixtron FY26 guide corrected €560M→€520M (mgmt "slightly down") + 800V GaN second leg slipped to '27–'29 ("not there yet"); Advantest capacity reframed 5K→10K systems/yr by ~CY2029 — refines the "3K→5K" framing above (annual capacity, not installed base)
- [[Research/2026-05-31 - DRAM HBM Memory Supercycle - deep-dive]] — SemiAnalysis memory supercycle: memory WFE capex +26/34/20% (Samsung/SK Hynix/Micron) 2026; 1b/1c node migration confirmed by ASML+LRCX; rising EUV layer counts; HBM ~5x wafer-capacity build → broad WFE demand leg
- [[Macro & Technology/CoWoS-to-CoPoS Panel-Level Packaging Transition]] — round-wafer→panel format transition (CoPoS 2028–29 HVM, NVIDIA Rubin anchor); equipment winners are panel-format lithography (Onto JetStep, SUSS), path-agnostic inspection (KLA, Camtek, Onto), bonding (BESI), deposition/plating (AMAT, LRCX), dicing (DISCO), and glass TGV (LPKF); round-wafer-locked tooling is the relative loser (see Q#8)

## Legacy Callouts
<!-- Auto-managed by /archive-callouts. Addressed callouts older than the sweep threshold (default 180 days) are moved here from their original sections as plain bulleted entries: `- **<addressed-date>** · <type> · <section> · raised <fresh-date> → <body>` with a `**Response:**` sub-bullet. Sorted descending (newest first). Do NOT hand-edit. To exempt a callout from sweeping, add `[[pinned]]` to its header in-place. -->

## Log

### 2026-04-19 (TSM stress test sync)
- [[Research/2026-04-19 - TSM - Stress Test]]: TSM Taiwan tail (-85-95% permanent impairment scenario) = loss of largest single leading-edge equipment buyer. ASML EUV global output 60 units/yr vs TSMC Taiwan installed base 50+; full replication for US/JP/DE rebuild consumes 100% of global output 12-18mo. CoWoS Kaohsiung/Chunan = 100% of BESI hybrid-bonding + AMAT packaging pipeline exposure. Sector's TSMC-concentration risk structurally higher than current thesis models — not hedged by Arizona buildout through 2030 (5-8% of capacity).

### 2026-04-22
- Reordered sections: Active Theses moved to first position per Sector Template / CLAUDE.md §Sector Notes (MOC navigation goes first).

### 2026-04-22 (full sector rebuild)
- Rebuilt to Sector Template structure (10 sections). Web-primary refresh: WFE $135B CY26 (SEMI, +9.0%) / $156B CY27; ASML Q1 2026 €8.8B rev + €38.8B backlog, FY guide raised to €36-40B; AMAT Q2 FY26 guide $7.65B, ICAPS flat; LRCX March Q guide $5.7B, advanced packaging >40% CY26; KLAC CY26 adv. pkg mid-high teens; ASMI Q1 2026 €863M + 33.1% record OM; TEL cryogenic etch volume 2026 for 400L NAND; BESI Q1 2026 April 23, SK Hynix mass-production Kinex order March 2026; China domestic equipment 25% → 35% in 2025 (NAURA $6.74-7.49B; AMEC #13 globally); Axcelis-Veeco $4.4B merger close mid-2026; Intel foundry equipment orders +50% YoY early 2026; Section 232 25% tariff (Jan 15, 2026) on narrow advanced logic. Status unchanged (active).

### 2026-04-22 (web-primary rebuild — JEDEC HBM4 reset + Q1 2026 earnings refresh)
- Major delta: **JEDEC HBM4 package height relaxed to ~900µm** (TrendForce April 2026). HBM4 16-Hi stays on microbump/MR-MUF; mandatory HBM hybrid-bonding deferred to HBM5 (2028-2029). BESI's HBM-timing story narrows; logic-side (SK Hynix Kinex March 2026, 150+ installed at TSMC SoIC / Intel Foveros) is the durable demand leg and is unchanged.
- Earnings/guide refresh: ASML Q1 2026 €8.8B / 53.0% GM / €38.8B backlog / FY guide raised €36-40B / High-NA 500K+ wafers at 80% availability / China 20% of 2026 (vs 33% 2025); AMAT Q1 FY26 $7.01B + Q2 FY26 guide $7.65B, CY26 equipment >20%, ICAPS flat; LRCX Q3 FY26 consensus $5.76B / $1.36 EPS; advanced packaging +40% CY26, GAA triples; KLAC Q2 FY26 $3.30B (+7.2%), FY2025 $12.745B (+17%), AP +70% CY25 / mid-high teens CY26 ($12B market); service CAGR raised 13-15% targeting $6B 2030; ASMI Q1 2026 €863M + 53.3% GM + record 33.1% adjusted OM; Q2 guide €980M; BESI Q4 2025 €166.4M rev (+25.4% QoQ) / €250.4M orders (+43.3% QoQ, +105.4% YoY) / 63.9% GM / 150+ installed at 18 customers / 30 bonders at 6 integrated logic lines with AMAT.

### 2026-04-24 (/sync)
- [[Research/2026-04-24 - Dylan Patel on AI Token Supply and Demand - video-transcript]]: ASML sold out + TSMC 2028 capex ~$100B + tail-whip prepayments across upstream — directly validates complexity-driven supercycle thesis for KLA/AMAT/LRCX/ASMI/TEL/BESI. Reinforces sector's core framing that equipment revenue per wafer start is structurally rising.
- [[Research/2026-04-24 - Iran War Japan Semiconductor Photo Materials Shortage - news]]: PCN cycle ~1yr for alternate PR/BARC solvents creates customer-side fab-evaluation uncertainty; WFE tool orders tied to fab ramps could slip if Samsung/Hynix delay HBM4 12-Hi ramp on material qualification.

### 2026-04-29 (SEMICAP thesis merger — sector becomes basket-level investment hub)
- Manual edit: Merged `[[Theses/SEMICAP - Semiconductor Capital Equipment]]` into this sector note. Thesis archived to `_Archive/Theses/SEMICAP - Semiconductor Capital Equipment.md`. Sector now serves dual role: (i) sector MoC per CLAUDE.md template; (ii) basket-level investment hub absorbing the prior thesis's positioning content into `## Investor heuristics` (six non-consensus insights, Bull/Bear scenarios, sector-level catalysts, sector-level risks, position monitoring triggers, what-to-own basket allocation). Materially deeper Industry History (1990s Japan-US trade friction, KLA+Tencor specifics, AMAT roll-up under Splinter/Dickerson, Carl Zeiss-ASML co-development); Competitive Dynamics expanded with Key Metrics table for top-6 basket; Macro shifts adds razor-and-blade economics (service annuity sizing, Carl Zeiss SMT bottleneck) plus retains complexity multiplier / JEDEC reset / geopolitical bifurcation / AI capex floor / customer concentration / Taiwan tail. AIXA added to Active Theses (Equipment-Specific) and Photonics product-level analysis since AIXA thesis was created 2026-04-29 with this sector classification. Inbound wikilinks across vault redirected from `Theses/SEMICAP - Semiconductor Capital Equipment` → `Sectors/Semiconductor Capital Equipment`. Pre-merge snapshots: `_Archive/Snapshots/Semiconductor Capital Equipment (pre-merge 2026-04-29-120033).md` + `_Archive/Snapshots/SEMICAP - Semiconductor Capital Equipment (pre-merge 2026-04-29-120033).md`. Conviction (basket-level, formerly thesis-level) unchanged at high. User should run `/graph last` to reconcile `_graph.md` adjacencies post-merge.

### 2026-04-29 (/sync — Active Theses backfill post-thesis-creation wave)
- /sync run propagated the Apr 27–29 thesis creation wave (KLA, AMAT, LRCX, ASMI, FORM, AEHR — each created with `sector update skipped per /thesis draft contract` Log note) into the sector's `## Active Theses` MOC. Reorganised Equipment-Specific scope into two tiers: **Core WFE basket** (KLA HIGH, AMAT/LRCX/ASMI/BESI MEDIUM) matching `## Investor heuristics > What to own` Tier 1+2 allocation framework, and **Photonics/test picks-and-shovels** (AIXA/FORM/AEHR MEDIUM) cross-referencing the new [[Sectors/Photonic Metrology]] sub-cluster. Equipment-Adjacent demand-driver entries (LITE, NVDA, 285A, SNDK, IQE, TSM) preserved verbatim. Added `[[Sectors/Photonic Metrology]]` to Related Research as the optical-domain sub-cluster pointer. No analytical body content modified — append-only MOC navigation update; conviction (basket-level) unchanged. Six theses now linked instead of two.

### 2026-04-30 (Addressed user callouts: re-rating, China gap, intra-node share, China hoarding)
- Addressed user callouts: 4 pinned callouts dated 2026-04-29 addressed across the note. (1) `[!tip]` at top — secular re-rating thesis → added Insight #7 to `## Investor heuristics > Where consensus could be wrong` (now seven non-consensus insights); structural re-rating valid but conditional, ~50%+ multiple expansion vs cyclical trough, conditional on AI capex visibility through 2030, Carl Zeiss capex announcement, TSMC N2 yield, MATCH Act non-passage. (2) `[!question]` in `## Industry history` — Chinese WFE tech gap quantification → added new `### Chinese equipment — node and yield gap quantification` subsection in `## Competitive dynamics` with 8-row table covering etch/CVD/ALD/DUV/EUV/process control/HB/test by production-grade node, qualification status, yield lag, and credible-competitor horizon. (3) `[!question]` in `## Competitive dynamics` — within-node share dynamics → added new `### Within-node vs between-node share dynamics` subsection between Market share trajectory and Pricing power trajectory; ~80-90% share shifts at node transitions, ~10-20% within-node via four catalysts (yield failure, new tool variant, geopolitical/commercial dispute, architecture change) with recent examples in three of four categories. (4) `[!question]` in `## Competitive dynamics` (after Key Metrics table) — China hoarding airpocket risk → added new `### G. China WFE hoarding and the airpocket risk vector` subsection in `## Macro shifts` quantifying $30-50B hoarding 2022-2025, $15-25B ghost-capacity equipment, $15-25B airpocket sizing if China share normalizes to 15-20% concentrated 2026-2027, position-monitoring telemetry via ASML China quarterly prints. All four callouts marked addressed with `[[pinned]]` markers preserved (exempt from `/archive-callouts` 180-day sweep, available for re-address as new data arrives). `last_updated` bumped to 2026-04-30. No conviction or status changes; basket framing unchanged.

### 2026-05-11 (/sync)
- [[Research/2026-05-11 - HBM Packaging Equipment Stack - MR-MUF to Hybrid Bonding Transition - deep-dive]]: Equipment-cohort bifurcation framework formalised across Macro Shifts §A complexity-multiplier table and §B JEDEC HBM4. **Architectural-mandate winners** (BESI, AMAT) durably benefit only at HBM5+ 24-Hi (2029-2030) — earlier than that is logic-line bridge demand. **Logic-line bridge winners** (ASMPT, Hanmi, Disco, Towa, AMAT EPIC) carry HBM4 and HBM5 first-gen revenue. NVIDIA Vera Rubin HBM4 ~70% SK Hynix / 30% Samsung / 0% Micron initial — all on MR-MUF. **Mar 2026 SK Hynix Kinex order reclassified to logic/DRAM-hybrid only (not HBM4)** — sector-level confirmation of the BESI thesis HBM-timing narrative. Disco added to Product-Level Analysis Advanced Packaging table (70-80% HBM wafer-thinning/grinding); Towa refined (66% HBM compression molding, sole-source). Namics EMC moat documented in §B as materials-side (orthogonal to equipment) — SK Hynix sole-supplier exclusivity expiring 2026-2027 is the single most critical HBM bottleneck not captured by WFE intensity models. No conviction/status changes; basket framing reinforces architectural-mandate-winner cohort (BESI, AMAT) on 2029-2030 timeline vs logic-line-bridge cohort (ASMPT, Disco, Towa, AMAT EPIC) on 2026-2028 timeline.

### 2026-05-12 (/sync)
- [[Research/2026-05-11 - INTC - Institutional Equity Research - deep-dive]]: **Intel Foundry +50% YoY equipment order ramp confirmed Q1 2026 with named-anchor visibility** — Tesla Terafab 100K WPM 18A-P (signed Sept 2025 with WFE pre-payment milestones), Apple preliminary 14A Cuyamaca scope (entry-level M-series only, validates third-party 14A anchor), Microsoft Maia 2/3 ("Griffin") $15B 18A commitment. Intel 18A "two quarters ahead of schedule" (CFO Zinsner, Q3 2025) and EMIB-T H2 2026 launch (120×180mm 24-HBM-stack vs CoWoS-L 100×100mm 8-stack) at "low hundreds" vs $900–1,000 CoWoS-L Rubin-class — first quantified non-TSMC advanced-packaging path for hyperscaler ASIC customers facing TSMC CoWoS 35K→130K WPM 2026 allocation squeeze. Direct BESI relevance: **Intel Foveros Direct is BESI-tooled** (Meteor Lake = first high-volume hybrid-bonded client product); Intel confirmed customer in BESI's 18-customer / 150+-system installed base. Intel Foveros + EMIB scaling +150% / +30% New Mexico expansion = incremental advanced-packaging tool pull for BESI/AMAT outside the TSMC SoIC-X channel. Hyperscaler $750B 2026 capex (+67% YoY, CreditSights) reaffirms WFE supercycle demand pillar across the basket. No conviction/status changes; basket framing reinforced — IFS becomes the credible third advanced-packaging anchor (TSMC + Samsung + Intel) and a meaningful incremental customer for BESI Foveros and AMAT EPIC tools through 18A-PT 2028.

### 2026-05-19 (/sync)
- Cross-sector propagation from [[Macro & Technology/800VDC Adoption]]: Macro note (created 2026-05-18, enhanced 2026-05-19) covers 800VDC rack-architecture transition with adoption forecast (10-15% of new AI racks 2027 → 65-75% by 2032) and six-layer value-chain map. Direct semicap relevance: Layer 4 (wide-bandgap silicon — SiC + GaN) and Layer 6 (passives + tools — Disco at ~30% / ~35% AI-DC, ~54% / ~30x ROIC/EV-EBIT; Aixtron at ~35% / ~45% AI-DC, ~12% / ~20x). Every SiC fab capacity addition (Wolfspeed Mohawk Valley + ROHM India + onsemi Czech + STMicro Catania) and GaN-on-Si fab (Infineon Kulim/Villach + Innoscience Suzhou 200mm 15,000 wpm + GlobalFoundries) adds tool orders for AMAT (PVD/CMP/etch), LRCX (selective etch + ALD), ASMI (ALD), KLA (inspection at each new packaging tier), and Aixtron (MOCVD epi-tools — Layer 6 directly). The macro's bottleneck-cascade analysis identifies wide-bandgap silicon + on-board VPD as Layers 4-5 binding constraints; epi-tool capacity-cycle lead times (12-18 months) make AIXA/VECO orders a leading indicator of 2027-2028 rack volume. No conviction changes — adds a wide-bandgap-fab demand tail to the existing basket framework (KLAC + AMAT + LRCX + ASMI + TEL + BESI + AIXA + FORM + AEHR).

### 2026-05-22 (/sync)
- [[Research/2026-05-22 - NVDA Q1-2027 - earnings]]: NVDA Q1 FY2027 transcript reinforces the WFE supercycle capex-floor pillar of the basket thesis. **$1T Blackwell+Rubin visibility 2025–2027** (explicitly framed by Jensen) is the highest-credibility multi-year accelerator-side capex anchor printed to date — translates downstream into TSMC CoWoS-L 35K→130K WPM ramp, HBM4 vendor allocation (~70% SK Hynix / 30% Samsung / 0% Micron initial), and the corresponding tool orders captured in §Macro shifts §A complexity-multiplier and §B JEDEC HBM4 frameworks. Combined with the 2026-05-12 CreditSights $750B 2026 hyperscaler capex (+67% YoY) datapoint, NVIDIA management's own visibility floor is now consistent with the basket's "complexity-driven supercycle" thesis horizon through 2027. **Net-new sector signal: Vera CPU $200B brand-new TAM** — opens an incremental host-CPU production ramp that flows to BESI Foveros Direct (NVIDIA Vera-Rubin NVL72 host-CPU per 2026-05-12 INTC entry) and to AMAT EPIC + Disco/Towa HBM-tier loadings on the Vera-side memory stack (Rubin Ultra HBM4 16-Hi). **No transcript content on HBM packaging transitions, Namics EMC, hybrid-bonding architecture, or equipment-cohort timing** — the architectural-mandate (BESI/AMAT Kinex H2 2029-2030) vs logic-line-bridge (ASMPT/Hanmi/Disco/Towa/AMAT EPIC 2026-2028) bifurcation framework formalised in the 2026-05-11 HBM Packaging Equipment Stack research remains the sector's own observability layer — transcript provides demand-floor confirmation but not packaging-stack delta. **Q&A skeptical-keyword density = 0 at NVDA**: contrarian sentiment indicator at the demand-side cluster — worth monitoring if sell-side capitulation extends to basket names KLA/AMAT/LRCX/ASMI in Q2 prints. No conviction changes — capex-floor pillar reinforced; equipment-cohort bifurcation framework unchanged; Vera CPU TAM provides modest incremental basket demand tail.

### 2026-05-24 (/sync all)
- [[Research/2026-05-24 - 2802 vs 6857 - Competitive Comparison]]: Ajinomoto (ABF substrate, 2802.T) vs Advantest (HBM/SoC test, 6857.T) competitive comparison frames test-equipment-tier monopoly as a backend picks-and-shovels parallel to ABF substrate chemistry-IP moat. Direct basket relevance: Advantest sits inside Watchlist as the "ASML of test" with 3K→5K capacity scaling (2025-2026) — this comparison reinforces the bifurcation between the **cyclical-WFE tier** (KLA/AMAT/LRCX/ASMI/TEL anchored on node transitions + capacity ramps) and the **HBM/test picks-and-shovels tier** (Advantest test capacity + ABF substrate chemistry moat) inside the broader semicap value chain. Test-tool capacity 3K→5K is the cleanest backend-of-line leading observable for HBM4 Rubin ramp, complementary to the Namics EMC materials moat documented for SK Hynix in Macro Shifts §8. Watchlist Advantest entry reinforced — consider thesis-evaluation candidacy if 6857 test-utilization print confirms structural backend monopoly thesis through 2027. No conviction changes at basket level; framework strengthened — backend monopoly cohort (Advantest + Disco + Towa) is structurally similar to architectural-mandate WFE cohort (BESI, AMAT-Kinex H2 2029-2030) in terms of single-vendor chemistry/process-IP defensibility.

### 2026-05-29 (/sync)
- [[Research/2026-05-29 - Earnings Transcripts vs Thesis - 6 Holdings - synthesis]]: transcript-vs-thesis review registered. Aixtron FY26 guide corrected €560M→€520M (mgmt "slightly down") + 800V GaN second leg slipped to '27–'29 ("not there yet"); Advantest capacity reframed 5K→10K systems/yr by ~CY2029 (refines the "3K→5K" Watchlist framing — annual capacity, not installed base). No sector-framework change.

### 2026-06-01 (/sync)
- [[Research/2026-05-31 - DRAM HBM Memory Supercycle - deep-dive]]: memory WFE capex +26/34/20% (Samsung/SK Hynix/Micron) 2026 + 1b/1c node migration (ASML+LRCX-confirmed) + rising EUV layer intensity + HBM ~5x wafer-capacity build (123→668 kwspm) reinforce the memory leg of the WFE supercycle. No basket-conviction change.

### 2026-06-18 (/sync)
- [[Macro & Technology/CoWoS-to-CoPoS Panel-Level Packaging Transition]]: corrected Q#8 — June-2026 reporting reverses the March-2026 "CoPoS → Q4 2030" delay (now 2028–29 HVM, NVIDIA Rubin anchor), weakening the CoWoS-lifecycle-extension assumption. Panel-format tools (Onto, SUSS, Camtek, KLA, BESI, DISCO, LPKF) flagged as winners vs round-wafer-locked tooling; added macro to Related Research. No basket-conviction change.
