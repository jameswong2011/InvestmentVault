---
date: 2026-04-15
tags: [thesis, semiconductors, NAND, kioxia, memory, AI-storage]
status: monitoring
conviction: medium
sector: NAND Memory & Storage
ticker: 285A.T
---

# Kioxia Holdings (285A.T) — The Inventor's Edge in a Structurally Tight NAND Market

## Summary

¥35,950 (up ~2,371% from ¥1,455 December 2024 IPO), ~¥17T ($107B) market cap. Kioxia invented NAND flash at Toshiba in 1987 and is the third-largest supplier globally (~14% share), operating through a JV with SanDisk that shares fab costs while enabling independent competition. BiCS8 (218-layer) in production; BiCS10 (332-layer) expedited to 2026. The LC9 enterprise SSD (245.76TB, 32-die stack) won "Best of Show" at Flash Memory Summit 2025. The investment case: whether Kioxia's technology leadership, capital-efficient JV structure, and position as the only major NAND supplier without conflicting HBM priorities can sustain earnings through a cycle that has already delivered extraordinary returns.

## Key Non-consensus Insights

- **The inventor's advantage is structural, not merely historical — the market systematically undervalues it by fixating on layer counts.** CBA achieves 15-20% higher gigabyte density than competitors at similar layer counts; headline layers (Samsung 286, Micron 276, SK Hynix 321 vs. Kioxia 218) are misleading. BiCS10 (332-layer) expedited from H2 2027 to 2026 because CBA permits aggressive stacking without yield penalties competitors face. 35+ years of accumulated process knowledge embedded in engineering culture.

- **Kioxia's die-supply model exploits the hyperscaler shift to custom storage controllers.** Google, Amazon, and Microsoft designing own controllers (same impulse as Google TPU, Amazon Trainium). Kioxia sells bare die directly as a "NAND foundry" — no enterprise SSD sales teams, shorter qualification cycles, no controller R&D competition. Samsung and Micron resist die-supply because it cannibalizes their SSD businesses. LC9 245.76TB with 32-die stacking demonstrates technology ceiling while die-only flexibility gives optionality competitors lack.

- **The Flash Ventures JV is the most underappreciated structural asset in memory.** Eight fabs split with SanDisk (49.9%), $4.5B 2026 capex (+41% YoY) — most aggressive NAND investment among majors. JV extended to 2034. No competitor shares fab costs: Samsung, Micron, SK Hynix absorb 100% of capex. Greenfield fabs cost $10-24B; this halves the burden. SanDisk pays cost-plus, giving Kioxia a guaranteed revenue floor.

- **Japan-centric manufacturing is a geopolitical moat but carries a newly-visible material-input tail risk that the "insulated" framing understated.** Government semiconductor subsidies, zero US export control risk, and no China counter-sanction exposure still contrast favorably with Samsung (South Korea's complex position), Micron (China's 2023 ban), and YMTC (US export-controlled). Kitakami Fab2 (operational September 2025) produces BiCS10 332-layer in a facility insulated from US-China fault lines. The concession introduced in April 2026: Iran War's Strait of Hormuz blockade cut 40%+ of Japan's naphtha supply (6 of 12 NCCs in production cuts), collapsing PGME/PGMEA solvent production and threatening Japanese PR/BARC/SOH supply to Kioxia's Yokkaichi + Kitakami fabs — the same Japan-centric chemical ecosystem that is a geopolitical strength is also a concentrated material-input chain. PCN re-qualification of alternate solvents takes ~1 year at standard nodes, longer for leading-edge BiCS10. Korean alternative suppliers (Chemtronics, Jaewon Industrial) exist but are not drop-in substitutes without requalification. Historical precedent (2019 Japan-Korea trade dispute, Korea reduced HF dependence from 87.9% to ~30% within 18 months) suggests this is a manageable 12-18 month vulnerability rather than a thesis-breaking risk — but the "insulated moat" framing requires this carve-out.

- **Bain Capital's orderly exit is positive institutional signaling, not a structural risk.** $2.1B (November 2025, 9% discount) and $2.3-3.5B (March 2026) absorbed without sustained price damage. Below 50% triggers governance normalization: board independence, index inclusion eligibility, transition from "PE exit trade" to institutional holding. Exiting near highs, not distressed levels.

## Outstanding Questions

- **How durable is the NAND supercycle, and what are the leading indicators of its end?** The structural argument — HBM capacity diversion, AI demand, depleted inventories — is compelling, but memory supercycles have never sustained beyond 2–3 years historically. Kioxia's 2026 production is sold out with firm POs extending to 2027–2028, but Yole Group has flagged 2027 as a potential inflection point. The IC should monitor: (1) YMTC Phase III ramp pace, (2) Micron Fab 10B timeline (H2 2028 earliest), (3) Samsung's NAND capex decisions, and (4) enterprise SSD contract structure shifts from spot to LTA. If Samsung breaks ranks on capex discipline — as it has done in every prior cycle — the supply-demand equation could shift faster than consensus expects. *(Sources: [[Research/2026-03-31 - SanDisk Valuation Assessment]], web research)*

- **What is the realistic path to resolving the Bain Capital and SK Hynix shareholder overhang?** Bain retains ~51% post-secondary sales. SK Hynix holds a ~15% convertible bond stake that blocked a Kioxia–Western Digital merger in 2023. Both shareholders have strategic interests that may not align with minority shareholders. The IC should assess: (1) Bain's exit timeline — at current pace, full exit could take 2–3 more years; (2) SK Hynix's long-term intentions — is the convertible a financial position or a strategic blocking stake?; (3) whether Bain's exit below 50% triggers governance improvements or activist opportunities. The $18B original acquisition price versus the current ~¥17T ($107B) market cap represents a 6x return for Bain, creating strong exit incentives.

- **Can Kioxia's balance sheet withstand a cycle downturn, given its leveraged buyout origins?** Net debt/equity has improved from 277% to 126% over seven consecutive quarters of positive free cash flow. However, the original LBO debt structure means Kioxia entered the upcycle with materially higher leverage than Samsung, Micron, or SK Hynix. If NAND pricing reverts to 2023 levels (when Kioxia posted a ¥252.7B operating loss), the balance sheet could re-stress rapidly. The IC should assess the company's liquidity runway under a severe pricing scenario and compare capital structure resilience to competitors.

- **Is the BiCS10 (332-layer) expedited timeline achievable without yield degradation?** Moving BiCS10 from H2 2027 to 2026 is aggressive. The Kitakami Fab2 will be the production base, but executing a generational node transition on a new fab introduces compounding risk. If yields disappoint, the expected bit cost reduction from density improvement fails to materialize. The IC should monitor Flash Memory Summit 2026 announcements and any changes to the technology roadmap timeline.

- **What happens to Kioxia's competitive position if the Flash Ventures JV faces internal tension or structural change?** The JV extension to 2034 provides visibility, but Kioxia and SanDisk are increasingly competing in the enterprise SSD market. SanDisk's Stargate program directly competes with Kioxia's LC9. If one partner gains significant share at the other's expense, the incentive to cooperate on shared fab capacity could erode. Additionally, any M&A involving either party (e.g., Samsung acquiring Kioxia, or a Kioxia re-merger with SanDisk) would fundamentally alter the structure.

- **How does the die-supply business model scale as hyperscalers consolidate their storage controller designs?** If Google, Amazon, and Microsoft all converge on internal controller designs and source die from multiple suppliers, Kioxia's differentiation narrows to cost-per-bit and reliability. Samsung and SK Hynix could aggressively enter die-supply, eliminating Kioxia's first-mover advantage. The IC should assess whether Kioxia's die-supply position is a durable competitive advantage or a transitional benefit that erodes as the market matures.

## Business Model & Product Description

Kioxia Holdings Corporation is a Japanese semiconductor company that designs, manufactures, and sells NAND flash memory and solid-state drives. It is the direct descendant of Toshiba's memory division, which invented NAND flash memory in 1987 — arguably the most commercially significant semiconductor invention since DRAM. The business was spun off from Toshiba in June 2018 and sold to a Bain Capital-led consortium (including Apple, Dell, Seagate, and Kingston) for approximately ¥2 trillion (~$18B). Toshiba retained a ~30% stake. The company rebranded from Toshiba Memory Corporation to Kioxia in October 2019 (combining Japanese "kioku" — memory — with Greek "axia" — value).

**The Business Model in Analogy:** Kioxia can be understood as a hybrid between a semiconductor foundry (like TSMC) and a branded chipmaker (like AMD). Through Flash Ventures, it operates shared fabs that produce NAND die for both itself and its JV partner SanDisk — similar to how TSMC manufactures for multiple customers. But unlike a pure foundry, Kioxia also designs and sells its own branded enterprise SSDs and controllers, competing in the end market. This dual role — die supplier and product company — gives it revenue optionality that pure-play competitors lack.

**Revenue Segments and Products:**

Kioxia's revenue is generated across three primary channels:

1. **Enterprise & Data Center SSD Products** — The flagship is the LC9 Series, the industry's first 245.76TB NVMe enterprise SSD, built on BiCS8 QLC NAND with a proprietary 32-die stack architecture and PCIe 5.0 x4 interface. The LC9 won "Best of Show" at Flash Memory Summit 2025 and is sampling to select hyperscaler customers. The CD9P and CM9 series provide enterprise SSDs in lower capacity tiers. This is the highest-margin, fastest-growing segment.

2. **NAND Die & Component Supply** — Kioxia supplies bare NAND die directly to hyperscalers building custom SSDs and to third-party SSD assemblers. This "NAND foundry" model is a unique strength: hyperscalers increasingly want to design their own storage controllers (mirroring the trend in custom AI silicon), and Kioxia's willingness to sell die rather than only finished SSDs positions it as the preferred supplier for this procurement shift.

3. **Consumer & Client SSD Products** — USB drives, memory cards, and client NVMe SSDs sold under the Kioxia brand. This is a lower-margin segment that provides volume utilization for the JV fabs.

**Technology Platform — BiCS FLASH:**

BiCS FLASH is Kioxia's proprietary 3D NAND architecture. The key innovation is CBA (CMOS directly Bonded to Array), which separates the memory array from the control logic onto two different wafers, bonds them together, and enables faster, more complex logic to drive the memory cells. This unlocks parallelism and density improvements impossible in traditional NAND where logic and memory share the same wafer.

- **BiCS8 (8th generation, 218-layer):** Currently in volume production. Uses CBA to achieve 15–20% higher density per layer than competitors at comparable layer counts.
- **BiCS9:** Intermediate node at Yokkaichi fabs.
- **BiCS10 (332-layer):** Expedited from H2 2027 to 2026. Will be produced at Kitakami Fab2. Represents Kioxia's leap to match/exceed competitors' layer counts while maintaining the CBA density advantage.

**Manufacturing Footprint:**

- **Yokkaichi Plant (Mie Prefecture):** Six flash memory fabrication facilities. The established production center for BiCS8 and BiCS9. Houses the core of the Flash Ventures JV.
- **Kitakami Plant (Iwate Prefecture):** Two fabrication facilities. Fab2 began operations September 2025. Will produce BiCS10 332-layer NAND. Designated as the center for next-generation technology ramp.
- **Combined output:** Approximately 30% of global NAND bit production (joint with SanDisk).
- **Capacity plan:** Kioxia aims to double bit output by FY2029 versus FY2024 through Yokkaichi/Kitakami expansion and BiCS10 density gains.

**Financial Trajectory (FY2025, ending March 2026):**

| Period | Revenue | Operating Income | Net Income | Notes |
|--------|---------|-----------------|------------|-------|
| FY2024 | ¥1,706B | ¥451.7B | — | +58.5% YoY; swing from ¥252.7B operating loss |
| Q3 FY2025 | ¥543.6B | ¥144.7B (non-GAAP) | ¥89.5B | Record quarter; 26.6% OP margin |
| FY2025 guidance | ¥2,180-2,270B | ¥717-807B | — | +28-33% YoY revenue |

## Industry Context

**The NAND Flash Oligopoly (2026 Market Structure):**

The global NAND flash market is a tight oligopoly of five suppliers that collectively control virtually all production:

| Supplier | Market Share | NAND Focus | HBM/DRAM | Key Differentiator |
|----------|-------------|------------|----------|-------------------|
| Samsung | 30–35% | Diversified | Yes (HBM leader aspirant) | Scale, vertical integration, V9/V10 NAND |
| SK Hynix (incl. Solidigm) | 20–25% | Shifting to HBM | Yes (HBM #1) | HBM dominance; NAND de-prioritized |
| Micron | 15–20% | Diversified | Yes (HBM challenger) | US-based; HBM3E/HBM4 ramp; Idaho fab 2028 |
| **Kioxia** | **~14%** | **100% NAND** | **No** | **Inventor; BiCS/CBA tech; die-supply model** |
| SanDisk | ~12% | 100% NAND | No | Consumer brand; HBF optionality; JV partner |

**The HBM Capacity Diversion Dynamic:**

The single most important structural factor in the NAND market is that Samsung and SK Hynix — controlling ~50–55% of NAND supply — are actively reallocating up to 40% of advanced wafer capacity from NAND to HBM production. HBM margins far exceed NAND margins ($98B HBM TAM projected by 2030 vs. ~$94B NAND in 2026), creating a rational economic incentive for integrated players to *starve* NAND supply. Total 2026 NAND capex is just $22.2B (+5% YoY) versus DRAM capex of $61.3B (+14%). This capex asymmetry means NAND supply discipline is being enforced by competitors' capital allocation decisions, not by voluntary restraint — making it more durable than typical cyclical discipline.

**Supply-Demand Fundamentals:**

- **Demand growth (2026):** 20–22% YoY, pulled by AI data center buildout (~$660B+ hyperscaler capex), enterprise SSD displacement of HDDs, and edge/AI PC storage requirements.
- **Supply growth (2026):** 15–17% YoY, constrained by flat wafer capacity and density-only bit growth.
- **Structural gap:** 3–7 percentage points, widening.
- **Pricing:** NAND contract prices rose 55–60% QoQ in Q1 2026. NAND wafer prices up 246% YoY. A 30TB enterprise TLC SSD surged from $3,062 to $10,950 (258% increase in 9 months). QLC NAND backordered by two years for some products.
- **Inventories:** Channel at 2–4 weeks versus 8–10 normal. All 2026 production sold out; customers negotiating 2027 allocations.

**New Supply Timeline:**

Meaningful relief from new greenfield capacity arrives no earlier than 2028. The only greenfield NAND fab under construction among the top three is Micron's Singapore Fab 10B (H2 2028 earliest). YMTC Phase III could add capacity by 2027 but faces US Entity List restrictions and primarily serves domestic China. Kioxia's own Kitakami Fab2 ramp is the most significant near-term NAND capacity addition globally.

**Competitive Dynamics and Value Chain:**

Kioxia occupies a unique competitive niche as the only major NAND supplier that: (1) has no HBM/DRAM business competing for management attention and capex; (2) operates through a cost-sharing JV that halves capital intensity; (3) is willing to sell bare die to hyperscalers rather than insisting on finished SSD products; and (4) has the deepest 3D NAND process heritage in the industry. The primary competitive risk is not from peers (Samsung/Micron are focused on HBM) but from YMTC, which could disrupt commodity NAND pricing if its Phase III ramp succeeds — though export controls constrain its technology roadmap.

## Key Metrics

| Metric | Value | Notes |
|--------|-------|-------|
| Stock Price | ¥35,950 | Up ~2,371% from Dec 2024 IPO at ¥1,455 |
| Market Cap | ¥17.06T (~$107B) | As of April 10, 2026 |
| Trailing P/E | ~70x | Reflects LBO-era earnings base |
| Forward P/E | ~7.3x | Massive earnings inflection expected |
| FY2025 Revenue (guided) | ¥2,180–2,270B | +28–33% YoY |
| Q3 FY2025 OP Margin | 26.6% | Non-GAAP; record quarter |
| NAND Market Share | ~14% | 3rd globally |
| JV Capacity Share | ~30% | Combined with SanDisk via Flash Ventures |
| 2026 Combined Capex | $4.5B | +41% YoY; most aggressive in NAND |
| Bain Capital Stake | ~51% | Exiting via secondary sales |
| Net Debt/Equity | ~126% | Down from 277%; 7 consecutive FCF+ quarters |

## Bull Case
- **Technology leadership:** Inventor of NAND; BiCS/CBA architecture delivers best density-per-layer; LC9 245TB sets new enterprise SSD standard
- **Structural supply deficit:** HBM capacity diversion by Samsung/SK Hynix constrains NAND through 2027+; 2026 fully sold out
- **Capital efficiency:** Flash Ventures JV splits fab capex with SanDisk; neither bears full capital burden of leading-edge NAND
- **Forward P/E ~7.3x:** If earnings estimates hold, the stock is cheap on forward multiples despite the 2,371% run
- **Die-supply model:** Uniquely positioned for hyperscaler shift toward custom storage controllers
- **BiCS10 expedited:** 332-layer production in 2026 positions Kioxia to capture density-driven pricing premium
- **Kitakami Fab2 ramp:** Newest, most advanced NAND fab globally now in production
- **Geopolitical stability:** Japan-based manufacturing insulated from US-China cross-fire
- **Bluefield-4 KV-cache-to-NAND demand vector (net-new, emerging):** NVIDIA's Bluefield-4 Context Memory Storage Platform (Grace + ConnectX-9) offloads model KV-cache to high-speed NAND — a "third network" tier beyond cold storage. Small today, architecturally significant: model-context tiering to NAND is a structural high-performance-NAND demand leg that partially offsets the algorithmic-efficiency bear (Risk #5 / Bear #149). Per [[Research/2026-06-02 - Datacenter CPU Landscape 2026 - deep-dive]].

## Bear Case
- **PE overhang:** Bain Capital ~51% stake creates persistent selling pressure; ~$5.4B+ already sold
- **Balance sheet risk:** LBO-origin debt structure; 126% net D/E still elevated versus zero-debt peers
- **Cycle timing:** Memory supercycles have never sustained beyond 2–3 years; 2027 could mark the peak
- **No HBM diversification:** 100% NAND exposure means no participation in the highest-margin memory segment
- **Trailing P/E ~70x:** On trailing earnings, the stock appears extremely expensive
- **SK Hynix blocking stake:** ~15% convertible bond position limits strategic flexibility
- **YMTC risk:** If YMTC Phase III ramps successfully, commodity NAND pricing could break
- **Algorithmic efficiency compounding:** TurboQuant + Muon optimizer + quantization could reduce GPU count per data center → fewer enterprise SSDs per rack

## Catalysts
- **Q4 FY2025 earnings (May 14, 2026):** Revenue guided ¥845–935B with ¥440–530B operating profit; significant sequential acceleration
- **BiCS10 production start:** First 332-layer NAND production in 2026 at Kitakami Fab2
- **Bain Capital exit below 50%:** Governance normalization; potential index inclusion eligibility
- **LC9 enterprise SSD revenue recognition:** Currently sampling; production shipments in 2026
- **2027 NAND contract negotiations:** Kioxia's ability to secure LTAs at elevated prices provides visibility
- **Flash Memory Summit 2026:** Technology roadmap updates; BiCS10 yield data

## Risks
1. **Cycle timing:** Supercycle extension through 2027 is required to justify current valuations; historical precedent warns against extrapolation
2. **Bain Capital exit mechanics:** Further $2B+ secondaries could pressure the stock if market absorption capacity weakens
3. **Balance sheet under stress:** If NAND pricing reverts to 2023 levels, the LBO debt structure re-stresses rapidly
4. **BiCS10 execution:** Expedited 332-layer timeline introduces yield risk on a new fab
5. **Algorithmic efficiency compounding:** If TurboQuant + Muon + quantization compound, fewer GPUs per data center → fewer enterprise SSDs per rack
6. **SK Hynix strategic risk:** Convertible bond holder with potential misaligned interests
7. **JV tension:** SanDisk's enterprise SSD competitive push (Stargate) creates potential friction with Kioxia's LC9
8. **Japanese photo-materials supply chain (new, 2026-04-22):** Iran War naphtha disruption → PGME/PGMEA solvent shortage at Shin-Etsu/TOK/JSR/Fujifilm/Nissan Chemical → risk to PR/BARC/SOH/HBM bonding adhesive supply into Yokkaichi + Kitakami. PCN requalification cycle ~1 year nominal, longer for leading-edge BiCS10. Korean alternatives (Chemtronics, Jaewon Industrial) exist but need requalification. Tail risk overlay on "Japan moat" Insight #4.

## Related Research
- [[Research/2026-04-15 - SNDK - Investment Evaluation]] — Post-separation NAND assessment; Kioxia JV structure analysis
- [[Research/2026-03-31 - SanDisk Valuation Assessment]] — NAND structural shortage thesis; wafer supply-demand model
- [[Research/2026-03-27 - Semis - Gemini TurboQuant Memory Canvas]] — TurboQuant impact on memory; Jevons Paradox framework
- [[Research/2026-03-27 - TurboQuant Impact on Memory Demand]] — Full deep-dive on ICLR 2026 paper: 3-bit KV cache, ≥6× compression, Jevons Paradox analyst consensus, Mar 24 memory-stock selloff (SK Hynix -6.2%, Micron -5.8%, Samsung -4.7%, SNDK -8%)
- [[Research/2026-03-28 - AI - Gemini AI Ecosystem Canvas]] — Edge/local AI inference as net-new NAND demand vector
- [[Research/2026-01-18 - SNDK - Gemini AI Investment Canvas]] — SanDisk AI storage thesis (covers JV dynamics)
- [[Research/2025-11-27 - HBM4 Breakthroughs and Yields]] — HBM4 vendor yields; competitive dynamics affecting NAND capex diversion
- [[Research/2025-11-01 - DRAM HBM Competitive Dynamics]] — Samsung/Micron/SK Hynix capex allocation and HBM-vs-NAND priority
- [[Research/2026-01-17 - Semis - Gemini AI Compute HBM Canvas]] — HBM shortage dynamics; inference economics
- [[Theses/SNDK - SanDisk]] — Flash Ventures JV partner; shared thesis dynamics
- [[Sectors/NAND Memory & Storage]] — NAND sector note: competitive dynamics, YMTC disruption analysis, product-level technology comparison, HBF category outlook
- [[Sectors/Semiconductor Capital Equipment]] — WFE sector hub: TEL cryogenic etch HVM 2026 for 400L NAND (Samsung first customer); JEDEC HBM4 900µm relaxation delays hybrid-bonding to HBM5; equipment-adjacent secondary sector reference
- [[Research/2026-04-24 - Iran War Japan Semiconductor Photo Materials Shortage - news]] — Iran War Hormuz blockade cuts 40% of Japan naphtha; PGME/PGMEA solvent shortage threatens Japanese PR/BARC supply to Yokkaichi/Kitakami fabs
- [[Research/2026-04-24 - Dylan Patel on AI Token Supply and Demand - video-transcript]] — NAND capacity growth constrained (low double digits, lower than DRAM); supply deficit durability through 2027+; die-supply positioning reinforced
- [[Research/2026-05-31 - DRAM HBM Memory Supercycle - deep-dive]] — DRAM/HBM supercycle read; adjacent NAND context (supply-discipline + capex-restraint parallels), no NAND-specific delta
- [[Research/2026-06-02 - Datacenter CPU Landscape 2026 - deep-dive]] — "CPUs are back": Bluefield-4 KV-cache-to-NAND ("third network") = net-new emerging high-performance-NAND demand vector (added to Bull Case)

## Log
### 2026-04-16 (NAND sector research sync)
- [NAND sector creation + web research]: Three conviction-relevant findings: (1) Kioxia posted 33.1% QoQ revenue growth in Q3 2025 — highest among all NAND producers — validates capacity utilization and enterprise demand thesis — strengthened. (2) YMTC at 13% share targeting 15% by end-2026 but primarily consumer/PC — Entity List blocks western enterprise procurement; Kioxia's enterprise/die-supply focus is structurally insulated from YMTC pricing pressure — conviction unchanged. (3) CBA architecture advantage confirmed: BiCS10 332L at 4.8 GT/s Toggle DDR 6.0 vs Samsung V10 at 5.6 Gbps; Samsung wins on raw IO speed but CBA's 15-20% density/layer advantage means Kioxia's 332L is density-competitive with Samsung's 400+L V10 — conviction unchanged. Additional: Solidigm QLC enterprise share at 51% with 321L QLC is the primary competitive threat to LC9; Micron 6600 ION 245TB in hyperscaler qualification creates direct product competition. NAND Q2 2026 contract prices +70-75% QoQ (TrendForce) — supports pricing through Q4 FY2025 earnings (May 14).

### 2026-04-16 (sector key questions deep dive)
- [[Research/2026-04-16 - NAND Sector Key Questions Deep Dive - deep-dive]]: CBA density advantage now quantified: BiCS10 at 29 Gb/mm² (+59% vs BiCS8), 4μs latency gain, 29% power reduction — the strongest data point yet for CBA's structural superiority vs layer-count-dependent competitors. GP Series (GTC 2026, 10M+ IOPS) opens HBF-adjacent revenue stream. Samsung V10 dependency on YMTC hybrid bonding IP is a new vulnerability Kioxia doesn't share — CBA uses no external IP. Kioxia supply sold out through 2027, LTAs extending to 2028. Conviction unchanged (medium); density thesis quantified and strengthened.

### 2026-04-15
- [Thesis created]: Split from KIOXIA-SNDK archive. Consolidated ChatGPT/Gemini/Claude/web research. Stock ¥35,950 (vs ¥15,210 at original thesis). Q3 FY2025 record ¥543.6B rev, JV extended to 2034, BiCS10 expedited to 2026. Conviction medium — structural thesis offset by extreme appreciation, PE overhang, cycle risk.

### 2026-04-22
- Sector re-scoped: Semiconductors & Photonics → NAND Memory & Storage (vault-wide subsector taxonomy reorganization).

### 2026-04-22 (Semicap sector rebuild sync)
- Wikilink cleanup: Replaced stale `[[Sectors/Semiconductors]]` parent reference with `[[Sectors/Semiconductor Capital Equipment]]` in Related Research; 285A remains listed in Semicap sector's Equipment-Adjacent scope (TEL cryogenic etch HVM 2026 for 400L NAND, Kokusai batch ALD for 3D NAND recovery). Thesis body unchanged; conviction unchanged.

### 2026-04-23
- Wikilink cleanup: Related Research: `[[Sectors/NAND Flash & Storage]]` → `[[Sectors/NAND Memory & Storage]]` (sector file renamed; pure rename fix). Conviction unchanged.

### 2026-04-23 (/sync — orphan linking)
- [[Research/2026-03-27 - TurboQuant Impact on Memory Demand]]: KV cache compression is DRAM-resident (HBM), zero architectural impact on NAND; validates Bear Case #149 / Risk #5 framing that TurboQuant-in-isolation does not threaten NAND demand — compound-risk only if paired with Muon + quantization. Conviction unchanged (medium).

### 2026-04-24 (/sync)
- [[Research/2026-04-24 - Iran War Japan Semiconductor Photo Materials Shortage - news]]: Rewrote Non-consensus Insight #4 to add Japan material-input tail-risk caveat; added Risk #8 (PGME/PGMEA / photoresist supply chain). Conviction unchanged — directionally weaker on "Japan moat" framing but 2019 HF-dispute precedent caps this as 12-18mo manageable vulnerability. Snapshot: [[_Archive/Snapshots/285A - Kioxia (pre-sync 2026-04-24-101646)]]
- [[Research/2026-04-24 - Dylan Patel on AI Token Supply and Demand - video-transcript]]: NAND supply growth <DRAM, true incremental supply not until 2028; reinforces Bull Case supply-deficit durability through 2027+. Conviction unchanged.

### 2026-05-01 (/sync)
- [[Research/2026-04-24 - Luo Fuli on OpenClaw and Agent-Era Compute Reallocation - video-transcript]]: 1T-parameter dense models proportionally raise NAND demand (KV-cache spillover, checkpoint storage, training-data state); pre-training-not-dead empirical refutation from frontier-lab insider supports through-2028 supply-deficit Bull Case pillar. Conviction unchanged.

### 2026-05-22 (manual)
- Status change: portfolio-wide realignment — not in current Live Portfolio holdings; status active→monitoring.

### 2026-05-24 (/sync all)
- [[Research/2026-05-23 - Iran-US Peace Deal Polymarket Signal Deterioration - web-clip]]: Marginal indirect-negative — extended Scenario A keeps Japanese PR/BARC/PGMEA tail-risk window open past Jun 15; 2019 HF-dispute precedent caps as 12-18mo manageable vulnerability per Risk #8. Conviction unchanged (medium, monitoring).

### 2026-06-01 (/sync)
- [[Research/2026-05-31 - DRAM HBM Memory Supercycle - deep-dive]]: DRAM/HBM supercycle read — adjacent NAND context (supply-discipline + capex-restraint parallels); no NAND-specific delta, conviction unchanged (monitoring).

### 2026-06-02 (/sync)
- [[Research/2026-06-02 - Datacenter CPU Landscape 2026 - deep-dive]]: NVIDIA Bluefield-4 KV-cache-to-NAND ("third network") added as net-new emerging Bull demand vector — model-context tiering to high-speed NAND partially offsets the algorithmic-efficiency bear. Small today, architecturally significant. Conviction unchanged (medium, monitoring). Snapshot: [[_Archive/Snapshots/285A - Kioxia (pre-sync 2026-06-02-121812)]]
