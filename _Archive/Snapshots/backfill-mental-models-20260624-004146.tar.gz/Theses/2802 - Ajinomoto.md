---
date: 2026-05-16
tags: [thesis, semiconductors, packaging, substrates, materials, japan, 2802]
status: monitoring
conviction: medium
sector: ABF Substrates & Advanced Packaging Supply Chain
ticker: 2802
source: https://www.ajinomoto.com/cms_wp_ajnmt_global/wp-content/uploads/pdf/2026_05_07_03E.pdf (Ajinomoto Consolidated Financial Results FY2025) + [[Sectors/ABF Substrates & Advanced Packaging Supply Chain]] vault sector primer
---
> [!question] 2026-05-16 → Addressed 2026-05-16
> **Prompt:** *What is the projected share of the ABF business as a % of total revenues and EBIT by 2030 if the volume of advanced packaging doubles as finished product from 2026 baseline - using substrate-AREA × layer-count × yield-adjusted-throughput logic to estimate total ABF demand given doubling chip level deliveries.*
>
> **Response:** Composite ABF revenue multiplier 2026→2030 under chip-volume 2.0× × substrate-area 2.5× × layer-count 1.20× × yield-throughput 1.10× × AI-mix-premium 1.15× = ~7.6× (central) / ~3.5-5× (execution-discounted), scaling FY2026E ¥130B baseline to ¥450-1,000B by FY2030. ABF share of consolidated revenue rises to ~20-36% (vs ~6% today) and share of EBIT to ~55-76% (vs ~30% today) — the conglomerate-multiple narrative becomes untenable by FY2030 even at 40% bull-case realization. Full derivation with multiplier-by-multiplier sensitivity: §Bull Case → FY2030 segment-share extension scenario.

> [!question] 2026-05-16 → Addressed 2026-05-16
> **Prompt:** *What is the traditional multiple applied to the food business during pre-ABF era, and given growth rates going forward what % of the market today can be attributed to the food business alone.*
>
> **Response:** Pre-ABF era (2010-2019) Ajinomoto traded at ~20-25× P/E in line with Japanese food peer median (Kikkoman ~25×, Nissin ~22×, Yakult ~24×, Suntory Beverage ~20×). Applying peer multiples to FY2025 segment business profit: Food ¥95B × 22× + Amino ¥25B × 14× + Healthcare ¥10B × 18× = ¥2.6T (~52% of current ¥5.04T MC), leaving ~¥2.4T (~48% of MC) implicitly attributed to Electronic Materials at ~44× standalone OP multiple. Full SOTP table + segment-by-segment multiple derivation: §Key Metrics → Valuation Decomposition: SOTP and FCF Bridge.

> [!question] 2026-05-16 → Addressed 2026-05-16
> **Prompt:** *Give me a detailed engineering view on how ABF is applied in advanced packaging processes. Expand this analysis to the entire process step of how interposer, substrates is utilised in the context of an end-to-end advanced packaging process.*
>
> **Response:** ABF arrives at substrate vendors as B-stage (semi-cured) film on release-liner backing and runs through a 7-step build-up cycle (vacuum lamination → thermal cure → laser drilling → desmear → electroless seed → pattern plating → flash etch) repeated 14-20 times per side; cumulative-yield compounding across iterated layers is what makes ABF dielectric uniformity structurally hard to replicate at >50% margin. At the package level, ABF consumption sits in stage 4 of an 8-stage end-to-end flow (front-end wafer → HBM stack → silicon interposer → **organic substrate (ABF here)** → die-to-interposer attach → interposer-to-substrate attach → BGA / underfill → test+ship), where the substrate forms a fan-out hierarchy from interposer-side 40-100μm die-bump pitch down to PCB-side 0.8-1.0mm BGA pitch via the 14-20 ABF dielectric layers. Full substrate fabrication engineering (process steps + chemistry + yield drivers): §Business Model & Product Description → ABF application engineering. Full end-to-end packaging flow + interposer-vs-substrate architectural distinction: §Industry Context → End-to-end advanced packaging process flow.

# 2802 — Ajinomoto

## Summary

Ajinomoto is a hidden ~95%-share monopoly on ABF dielectric film (the single material that gates every CoWoS / Foveros / EMIB / SoIC / I-Cube advanced-packaging substrate globally), buried inside a ¥1.6T consumer-staples food + amino-acid conglomerate that the market values on a 40× P/E food multiple rather than a semi-monopoly multiple. The Electronic Materials segment booked FY2025 sales of ¥100.7B (+31% YoY) at >50% operating margin and contributed ~30% of consolidated business profit despite being <7% of consolidated revenue — the segment has gone from invisible to financially material in two years on AI substrate body-size growth, and the inflection is still in inning 3-4. The non-consensus angle is not "discover the monopoly" (sell-side knows ABF exists) but "the segment's standalone EBIT is now compounding 35-50% annually inside a parent whose narrative, capital allocation, and equity story are still 75% controlled by the food business" — meaning the segment's economics are systematically under-modeled by both food analysts (who treat ABF as a small contributor to a defensive staple) and semi analysts (who can't own Ajinomoto cleanly because 70% of revenue is MSG and broth). Three credible competitive entrants (Hanwha E-ssential's HBF launching 2026, Sekisui Chemical SAP build-up film at ~5% share, glass substrates at TSMC R&D) plus single-facility Kawasaki seismic risk cap the conviction at MEDIUM; the rally to ¥5,269 (vs ¥4,288-4,939 sell-side avg, Morningstar fair value ¥8,178) has already absorbed the easy SOTP arbitrage, so this is a 3-5 year compounder bet on a structurally tightening AI-substrate cycle, not a 12-month re-rating trade.

## Key Non-consensus Insights

**1. The ABF segment is now the single largest contributor to consolidated business-profit growth, but the equity is still priced on consumer-staples cyclicality.** FY2025 Electronic Materials segment delivered ¥54.6B operating profit (+35% YoY) — that single line item contributed roughly half of Ajinomoto's ¥21B (+13%) consolidated business-profit growth, against Food Products' steadier single-digit growth — though the transcripts through Q3 FYE-Mar-2026 show the food side improving, not dragging: Japan and overseas seasonings drove sales and profit growth, frozen foods entered a "profit recovery phase," and management revised the full-year food forecast upward. The relative point stands (ABF compounds far faster), but the "margin-pressure drag" framing is stale. The segment's operating margin (>50%) is structurally 3-4× the food segment (~12-14%) and is widening as AI substrate mix shifts to higher-layer-count premium-priced film. Sell-side models still anchor Ajinomoto's terminal margin to a blended ~12-13% food-weighted average; the actual trajectory is converging toward a 18-22% blended margin by FY2028 if Electronic Materials hits ¥160-200B revenue at sustained 50%+ segment margin. The conglomerate-multiple discount the market applies (~40× consolidated P/E vs ~22× peer Japanese food on the food piece + ~25-30× pure-play semi-materials on the ABF piece) is structurally too high but mechanically requires the ABF segment to reach ~25% of consolidated EBIT before equity analyst frameworks rebase — which is where it lands in FY2026 on current trajectory.

**2. AI substrate body-size growth compounds ABF consumption per package on a curve that is steeper than the substrate-vendor ASP step-up the market has already priced.** Substrate body sizes have grown from ~58×58mm Skylake-EP (2015) to ~80×100mm B300 (2025) to a projected 120×180mm Intel EMIB-T (2026) — a ~7× area increase. ABF is consumed in proportion to substrate surface area × layer count, and modern AI substrates use 14-16 build-up layers (vs 8-12 on PC CPU substrates), so ABF consumption per package has grown 10-15× over the same window. The market models ABF as substrate-volume-linked (units × ASP), but the actual demand driver is substrate-AREA × layer-count × yield-adjusted-throughput — a much steeper curve. When the EMIB-T 24-HBM-stack package ramps in H2 2026 at 120×180mm with 16+ layers, single-package ABF consumption steps another 2× from B300 levels. The proportion of ABF going to servers/networks has gone from 40% in FY2017 to 70% in FY2025 and Ajinomoto's own guidance is 75-85% by FY2030 — the high-mix shift to AI-substrate film at 50-57% segment margin (vs PC at low-30s%) is the underappreciated mix-shift accelerator that pulls forward the segment-margin re-rating.

**3. The competitive threat-stack against ABF (Hanwha HBF, Sekisui SAP film, Thintronics, Chinese Qin Film, glass substrates) is broader than at any time in the franchise's 30-year history — but the qualification-cycle moat means none of these threats compress Ajinomoto pricing power before 2028, and most never reach AI-substrate spec at all.** Switching dielectric film in an FC-BGA production line requires 18-36 months of substrate-vendor qualification (Ibiden / Unimicron / Nan Ya / Shinko each separately) followed by 6-12 months of end-customer qualification (Intel / NVIDIA / AMD / Apple / hyperscaler ASIC). The cycle compounds: Sekisui has been "qualified at major substrate makers in Japan and Taiwan" since 2014 and still holds ~5% share after 12 years. Hanwha E-ssential's HBF launches commercially in 2026 — even if it qualifies through SK Hynix-affiliated Simmtech immediately, broader substrate-vendor + end-customer qualification puts material share gains beyond 2029. Thintronics (US startup) has no substrate-vendor qualification at all. Chinese Qin Film is locked out of TSMC + Western hyperscaler accounts by ITAR + customer trust constraints. Glass substrates are a 2030+ technology transition (Intel stopped funding internal development; TSMC R&D-only). The result: 2026-2028 is the window of maximum pricing power for Ajinomoto, because the competitive entrants are visible enough to constrain customer ASP escalation rhetoric but not yet operational enough to take share.

**4. The Kawasaki single-facility risk is real and asymmetric, but the market has been pricing it as binary catastrophic when the actual exposure is partial — and Ajinomoto's expansion roadmap (Gunma, plus 2032 Kani-Mitake Gifu third plant) materially reduces the geographic concentration over the next 6-7 years.** Ajinomoto produces ABF at Kawasaki (Kanagawa Prefecture) — within the Tokai-Tonankai-Nankai megathrust seismic zone, ~50km from the Tokyo metro. A full facility incident would cascade through every CoWoS + Foveros + EMIB substrate in production within 4-8 weeks, costing the global advanced-packaging stack 12-24 months of supply-chain reset. The market prices this as a binary tail risk and consequently keeps the multiple compressed. The actual exposure is partial: (a) Gunma plant has been ABF-active since 2007 and is being expanded with the ¥25B Gunma+Kawasaki package (+50% capacity by 2030); (b) the 2032 Kani-Mitake plant in Gifu Prefecture (¥1.2B land buy announced May 2026, construction 2028) is on a different tectonic plate boundary than Kawasaki and explicitly framed by management as resilience-driven; (c) ABF film inventory at downstream substrate vendors (Ibiden / Unimicron) is held at 4-8 week levels under sole-source-supplier protocol, providing a buffer that the market underweights. The geographic-concentration risk is real but is being actively de-risked on a 5-7 year curve that the equity has not yet absorbed.

**5. The hidden-cost-pass-through dynamic at the ABF stack creates structural margin expansion the market does not model.** Ajinomoto's principal upstream cost inputs are inorganic filler chemistry (Tatsumori, Admatechs, Denka — diversified specialty), epoxy resin base chemistry (sourced or internal), glass fiber for reinforcement (Nitto Boseki — announced a 20% price hike in 2025), and laser-drillable solder mask chemistry. Each upstream cost rise is passed through to substrate vendors with a 3-6 month lag at quasi-monopoly pricing power, but the ASP step-up exceeds the cost increase by a factor of 2-3× because substrate vendors absorb the cost pass-through and re-mark to end-customer at higher gross margin. The 2024-2025 substrate ASP step-up (+50-100% on AI substrate body sizes) decomposes as roughly 20% pure mix shift (PC → AI substrate), 30% layer-count and body-size yield premium, and 50% margin capture by Ajinomoto + substrate vendors on quasi-monopolistic pricing — a margin-expansion dynamic that compounds with each customer contract reset (typically 18-24 month cycles). The segment is at 50%+ operating margin today; the structural ceiling at frontier-AI-substrate mix is plausibly 60-65% by FY2028, materially above the 45-50% the market models on a "mature monopoly" basis.

## Outstanding Questions

**1. What is the actual segment-level capital intensity of the ABF franchise, and can the 50%+ operating margin survive the 2028-2032 capex cycle?** Ajinomoto has guided ¥25B for the Gunma+Kawasaki +50%-capacity expansion (2024-2030) and a new ¥1.2B land buy for the Kani-Mitake Gifu plant (construction 2028, ops 2032 — capex undisclosed but likely ¥30-50B+ for a third-facility scale). The cumulative ABF segment capex 2024-2032 is plausibly ¥60-100B against ¥100-160B cumulative segment operating profit — an 60-70% reinvestment rate. The segment is monopoly-margin-profitable but capital-hungry in a way that PC-substrate-era ABF was not. A skeptical IC would ask: at what point does segment ROIC compress as fixed-asset base grows faster than incremental margin capture?

**2. Will Hanwha E-ssential HBF actually qualify at scale by 2028, and if so, what is the SK Hynix-affiliated substrate-vendor (Simmtech) supply route that bypasses normal qualification timelines?** Hanwha E-ssential is a Hanwha Solutions subsidiary; Hanwha Solutions has equity / commercial relationships across the Korean memory ecosystem (SK Hynix-adjacent through Hanwha's general industrial portfolio) and Korean substrate vendor Simmtech. If Simmtech qualifies HBF as a secondary dielectric for HBM-base-die substrate (Korean memory ecosystem, less dependent on Intel-NVIDIA-AMD primary qualification), Hanwha could establish a Korean-domestic share foothold by 2027-2028 that erodes Ajinomoto's HBM-substrate dielectric share more quickly than the Sekisui-style trajectory implies. The investment-committee question: what level of HBM-base-die-substrate ABF share does Ajinomoto have to lose to Hanwha to materially impact segment margin?

**3. How exposed is the ABF franchise to a glass-substrate transition timeline that accelerates from 2030+ to 2027-2028?** TSMC has explicitly committed engineering headcount to glass substrate R&D; Intel stopped funding internal glass-core substrate development in mid-2025 but announced external-vendor sourcing for glass substrates. Samsung is investing in glass substrate development for high-end packaging. The consensus glass-substrate volume timeline is 2030-2032 for first volume + 2034-2035 for displacement of organic substrate at the highest-end packages. If TSMC accelerates the timeline to 2028 for CoWoS-glass or NVIDIA Rubin Ultra-equivalent at glass substrate, Ajinomoto's frontier-AI-substrate ABF revenue starts compressing 2-3 years ahead of model. The data point that would answer this: TSMC's COUPE / advanced-packaging roadmap commentary at the next Symposium on VLSI Technology + AMD / NVIDIA / Microsoft glass-substrate qualification announcements.

> [!question] 2026-05-16 → Addressed 2026-05-16
> **Prompt:** *Explain the physics behind glass substrate replacement of ABF organic substrate technology in interposer specifications.*
>
> **Response:** Glass wins on five physical vectors at 120×180mm+ body sizes — CTE match to silicon (3-9 vs organic 12-17 ppm/°C eliminating warpage), TGV precision (5-10μm vs ABF 30-50μm enabling 3-5× I/O density), dielectric loss tangent (0.001 vs 0.005-0.008 cutting >50 GHz signal loss 5×), Young's modulus (70 GPa vs 15-25 GPa improving solder reliability), and thermal conductivity (~1-1.5 vs 0.3-0.5 W/m·K). The Ajinomoto-specific nuance: glass core + organic build-up dielectric is the likely intermediate architecture, preserving ABF demand even when BT-resin cores get displaced — full-glass substrate (which would displace ABF entirely) is 2032-2034+ at earliest. Full physics breakdown with displacement-timeline analysis: §Industry Context → Glass substrate displacement physics.

**4. What is the Electronic Materials segment's customer concentration, and what is the contractual visibility on 2027-2029 AI substrate dielectric demand?** ABF film flows through ~5 substrate vendors (Ibiden + Unimicron + Nan Ya + Shinko + AT&S) to ~10-15 end customers (Intel, NVIDIA, AMD, Apple, AVGO, Microsoft, AWS, Google, Meta, Apple, etc.). Ajinomoto's customer concentration is therefore through the substrate-vendor layer; if Ibiden + Unimicron together represent ~55-60% of ABF demand, a customer-mix shock (e.g., Intel substrate-share loss to TSMC) propagates upstream to Ajinomoto. The disclosure question: does Ajinomoto report ABF revenue by substrate-vendor customer or only at segment-aggregate level, and how visible is the FY2027-2029 substrate-vendor demand to Ajinomoto's capacity planning?

**5. Is the BT-resin pricing pass-through dynamic (Mitsubishi Gas Chemical adjacent monopoly) shifting the share of substrate-stack value capture toward MGC and away from Ajinomoto?** Substrate-stack value capture is split across (a) ABF dielectric (Ajinomoto ~95% share), (b) BT resin core (MGC ~70-80% share), (c) glass cloth reinforcement (Nittobo ~50%), (d) solder mask (Taiyo Ink ~60%), and (e) substrate vendor fabrication (Ibiden / Unimicron / etc.). As body sizes grow, BT resin core size grows proportionally — MGC has greater pricing power on larger panels than Ajinomoto on thinner film. The market treats Ajinomoto + MGC as parallel monopolies but the relative value-capture share may be shifting. The investment-committee question: at what level of substrate body size does BT resin pricing power surpass ABF dielectric pricing power, and what does that imply for Ajinomoto's segment-margin trajectory at 100×100mm+ frontier-AI-substrate spec?

**6. How does the consumer / amino-acid / pharma business compose its capital allocation against the ABF franchise's reinvestment needs?** Ajinomoto's total FY2025 business profit was ¥181B; Electronic Materials contributed ~¥55B (~30%). The remaining ~¥126B comes from Food Products (~70% of revenue, ~50% of profit) and Amino Acids / Pharma / Healthcare / Others. The food business has lower-margin growth opportunities (international seasonings expansion, plant-based foods, healthier-living portfolio) competing for capital with the ABF franchise. If management allocates 50%+ of FCF to lower-return food-segment growth rather than accelerating ABF capacity expansion + non-Japan ABF facility build-out (which would materially reduce Kawasaki concentration risk), the equity story is structurally suboptimal even with ABF segment-margin compounding. The proxy question: what proportion of FY2026-2028 announced capex flows to ABF / electronic materials, and what is management's stated capital-allocation framework?

## Business Model & Product Description

**Ajinomoto is a four-segment conglomerate** with consolidated FY2025 (FYE March 2026) sales of ¥1,583.7B and business profit of ¥181.1B (+13% YoY):

| Segment | FY2025 Sales (¥B) | % of Sales | FY2025 Business Profit (¥B) | % of BP | OP Margin |
|---|---|---|---|---|---|
| Food Products (seasonings, frozen foods, processed foods, beverages) | ~830 | ~52% | ~95 | ~52% | ~11.5% |
| Amino Acids (animal nutrition + amino-acid-based industrial inputs) | ~290 | ~18% | ~25 | ~14% | ~8.5% |
| Healthcare & Others (pharma intermediates, biotech reagents, specialty chemistry) | ~270 | ~17% | ~10 | ~6% | ~3.5% |
| **Functional Materials / Electronic Materials (ABF + adjacent specialty films)** | **~101** | **~6%** | **~55** | **~30%** | **>50%** |
| Other / Adjustments | ~93 | ~6% | -4 | ~-2% | n/a |

The Electronic Materials segment, although <7% of revenue, contributes ~30% of consolidated business profit — that asymmetry is the entire investment case.

**Within Electronic Materials, ABF (Ajinomoto Build-up Film) is the dominant product line.** ABF is a thermosetting epoxy-resin-based dielectric film (~40 µm thickness, ~600×400mm sheet format) embedded with proprietary inorganic filler chemistry. It is the dielectric layer between copper redistribution traces on every modern high-end IC substrate. The chemistry:

- **Base resin**: epoxy-novolac proprietary formulation (Ajinomoto-internal IP, trade-secret protected)
- **Inorganic filler**: silica + alumina + proprietary filler-treatment chemistry, particle-size distribution tuned for ±2 µm thickness uniformity and 30-50 µm laser-drillability
- **Manufacturing**: B-stage cure film cast on release-liner backing; vacuum-laminated onto BT-resin core at customer (substrate vendor) site

**Production footprint** (as of May 2026):
- **Kawasaki, Kanagawa Prefecture** (HQ + R&D + primary production) — operating since 1999; expanded multiple times 2010-2025; current production ~70% of total
- **Gunma Prefecture (Showa Village)** — second facility, operating since 2007; current production ~30% of total
- **Kani-Mitake, Gifu Prefecture (third facility)** — land acquired May 2026 (¥1.2B land buy); construction 2028; operations 2032; designed to add another major-facility scale, partly redundancy / resilience and partly capacity expansion

**Capacity expansion**: ¥25B Gunma + Kawasaki expansion announced 2024-2025, targeting +50% nameplate capacity by 2030. Gifu plant 2032 ops adds further capacity (capex undisclosed, plausibly ¥30-50B+).

**Customer / value-chain structure**: Ajinomoto sells ABF film to ~5-7 substrate vendors (Ibiden, Unimicron, Nan Ya PCB, Shinko Electric [private], AT&S, Kinsus, Simmtech) who fabricate finished substrates for end customers (Intel, NVIDIA, AMD, Apple, AVGO, hyperscaler ASIC programs). Ajinomoto has no direct end-customer relationship; its commercial relationship is substrate-vendor-level. This creates a customer-concentration analogy to ASML: a small set of substrate-vendor customers (Ibiden + Unimicron together ~55-60% of demand) gate Ajinomoto's revenue, but the substrate vendors are mutually committed to Ajinomoto-quality dielectric and have not historically defected.

**Pricing structure**: contract-based, typically 18-24 month renewal cycles between Ajinomoto and substrate vendors, with cost-pass-through clauses for upstream filler / glass-fiber / energy cost movement. Pricing is set per square meter of finished ABF film; AI substrate film commands a 50-100% premium over PC / consumer CPU substrate film because of higher filler-loading specs + tighter thickness tolerance + co-qualification effort.

**Adjacent products inside Electronic Materials**: solder mask hybrids (small), specialty films for flexible PCB (small), test reagents (small). ABF is >80% of segment revenue and >85% of segment profit.

**ABF function — dielectric insulator, not adhesive**: despite the "film + lamination + cure" application sequence that resembles an adhesive process, ABF's primary function is **electrical insulation between copper redistribution layers**. A 14-20-build-up-layer substrate has 14-20 copper trace planes routing signal / power / ground — each plane must be electrically isolated from its neighbors or the entire package shorts. ABF is the dielectric barrier between every adjacent pair of copper layers; laser-drilled vias (Cu-plated through ABF) provide controlled vertical interconnect where the dielectric isolation needs to be punctured. The defining specifications that drive Ajinomoto's pricing power are dielectric properties — Dk ~3.5 (controlled-impedance routing for high-speed signals), Df 0.005-0.008 (signal attenuation at >50 GHz frequencies like NVLink-7 / PCIe 7 / CXL 4.0), thickness uniformity ±2-3μm across 600×400mm panel (lane-to-lane impedance variability), and laser drillability at 30-50μm via diameter / >10:1 aspect ratio. The B-stage lamination behavior described below is the application mechanism, not the function; the post-cure structural rigidity (Young's modulus 15-25 GPa) is incidental. Categorically, ABF sits in the dielectric category alongside FR-4 prepreg (PCB inner-layer dielectric), low-k dielectrics (front-end IC interlayer dielectric), and BT-resin core — not in the adhesive category that contains underfill (Namics / Henkel), die-attach film, or thermal interface material. Competitor materials (Sekisui SAP film since 2014, Hanwha E-ssential HBF launching 2026, Sumitomo Bakelite intermittent attempts) have spent 5-15 years matching dielectric specs, not adhesive specs, because dielectric specs are what the customer buys.

**ABF application engineering (substrate-vendor side)**: ABF arrives at the substrate vendor as a B-stage (semi-cured) film on release-liner backing — 600×400mm sheets at 20-60μm thickness depending on spec (frontier AI substrate runs 20-30μm; PC substrate 40-60μm). The substrate is built up layer-by-layer on a BT-resin core (from Mitsubishi Gas Chemical) via a 7-step sequence repeated 14-20 times per side at frontier AI spec:

| Step | Process | Equipment | Parameters / yield drivers |
|---|---|---|---|
| 1 | **Vacuum lamination** of ABF film onto prepared core / previous build-up layer | Vacuum laminator (Meiki, Nikko-Materials, Apic Yamada) | 100-130°C, 5-15 atm, vacuum 1-10 Pa; air-pocket elimination is binary pass/fail; conformal flow over 15-25μm Cu trace topology |
| 2 | **Thermal cure** (B-stage → C-stage advancement) | Convection oven | 130-180°C × 30-90 min; cure-profile drift compresses Dk uniformity and downstream lithography registration |
| 3 | **Laser drilling** of micro-vias through cured ABF | UV / CO2 laser drill (Mitsubishi Electric, Via Mechanics, Disco) | 30-50μm diameter at >10:1 aspect ratio; via-wall taper and roughness gate downstream Cu adhesion |
| 4 | **Desmear** + plasma cleaning of via walls | Wet desmear (KMnO4 swell-and-etch) + plasma | Wall roughness 0.5-1μm Ra target; over-etch erodes filler particles, under-etch leaves smooth resin that fails Cu adhesion |
| 5 | **Electroless copper seed** on top surface + via walls | Electroless plating bath (Atotech, Uyemura) | 0.5-1μm uniform Cu seed; thickness uniformity controls flash-etch margin in step 7 |
| 6 | **Photoresist + lithography + electrolytic Cu plating** of trace pattern | Stepper or DI laser writer + Cu plating cell (Atotech, Ebara) | Trace pitch 15-30μm at frontier AI substrate; resist lithography is the geometric throat for downstream layer counts |
| 7 | **Resist strip + flash etch** of seed Cu in non-pattern areas | Wet processing line | Removes seed Cu cleanly without over-etching plated traces |

Steps 1-7 repeat 14-20 times per side for AI-class substrates; the iterated build-up means a single ABF defect (filler agglomerate, thickness variance, void) compounds yield loss multiplicatively across layers. At 99% per-layer yield × 16 layers, cumulative yield is ~85%; at 97% per-layer × 16 layers, cumulative yield drops to ~62%. This compounding effect is why ABF dielectric uniformity (Ajinomoto's hardest-to-replicate specification) is structurally over-valued by the bulk-material-cost framing competitors use to enter the market — Sekisui has held ~5% share for 12 years despite being qualified at major substrate vendors, because the marginal Sekisui ABF that doesn't quite hit Ajinomoto uniformity specs costs the substrate vendor 3-5pp of cumulative yield, more than offsetting any Sekisui price discount.

**ABF chemistry and B-stage behavior**: the B-stage film is "tacky-flowable" — the epoxy-novolac base resin is partially polymerized (~30-50% conversion) such that it deforms under heat and pressure to conform to substrate surface topology (covering 15-25μm-thick Cu traces from the previous build-up layer) without flowing so freely that it migrates off-panel. Inorganic filler loading (~50-70% by weight, silica + alumina + proprietary surface-treated particles) tunes four critical properties:
- **Thermal expansion**: filler reduces CTE from ~60 ppm/°C (pure resin) to 12-17 ppm/°C (filled film), targeted at substrate-core CTE to minimize panel warpage
- **Laser drillability**: filler particle-size distribution (peak at ~3-5μm with controlled tail to <10μm) enables clean 30-50μm via walls; oversized filler grains cause jagged via walls that fail Cu adhesion
- **Dielectric constant**: filler chemistry tunes Dk to ~3.5 for controlled-impedance routing at high-speed signals
- **Mechanical strength**: filler provides post-cure stiffness for downstream handling without crack propagation

Ajinomoto's IP concentrates in (a) the specific filler chemistry + surface-treatment + particle-size distribution, and (b) the B-stage advancement profile that gives the film its handling tolerance window. These are 30 years of process knowledge that competitors (Sekisui since 2014, Hanwha E-ssential since 2020, Sumitomo Bakelite intermittent) have spent 5-15 years trying to replicate without crossing the yield-impact threshold — explaining the >50% segment operating margin at quasi-monopoly pricing.

**Storage and supply chain**: ABF film must be stored refrigerated (typically <0°C) to prevent premature B-stage advancement; shelf life is 3-6 months refrigerated. Substrate vendors maintain 4-8 weeks of ABF inventory under sole-source-supplier protocol — providing the supply-chain buffer that absorbs short-term Kawasaki disruption risk and partially de-risks the geographic-concentration thesis weakness (see Risk 6 / Mechanism 3 bear case).

**Ajinomoto Fine-Techno (AFT)** is the wholly-owned operating subsidiary that produces ABF; established 1998 as the fine-chemicals consolidation entity. AFT's revenue + profit consolidate fully into parent Ajinomoto.

## Industry Context

The ABF substrate supply chain has three functionally distinct layers — **dielectric film** (Ajinomoto monopoly), **substrate fabrication** (Ibiden / Unimicron / Nan Ya / Shinko private / AT&S oligopoly), **end-customer packaging** (TSMC CoWoS / Intel Foveros / Samsung I-Cube) — plus several adjacent material monopolies (MGC BT resin, Nittobo glass cloth, Taiyo Ink solder mask). Full sector context: [[Sectors/ABF Substrates & Advanced Packaging Supply Chain]].

**Where Ajinomoto sits in the value chain**: Ajinomoto is at the top of the substrate-materials BOM. Every advanced IC substrate in volume production contains 30-60g of Ajinomoto ABF film distributed across 12-18 build-up layers. The film is consumed irreversibly during substrate lamination — no recycling, no second life. Each AI accelerator package (NVIDIA B300, AMD MI350, Broadcom custom ASIC, Intel EMIB-T) carries $4-8 worth of Ajinomoto film against $400-1,000 substrate-vendor ASP and $5,000-40,000 finished-package ASP — Ajinomoto captures 0.5-1.5% of finished-package value at >50% gross margin, the highest-margin BOM line in the entire AI accelerator stack measured by margin × consumption-irreversibility.

**End-to-end advanced packaging process flow (AI accelerator example)**: ABF consumption sits in the organic-substrate-fabrication stage, which is one of 8 distinct process stages composing an end-to-end advanced AI accelerator package. Using NVIDIA B300 / Intel EMIB-T as reference architectures:

| Stage | Process | Location | Output / key components | ABF involvement |
|---|---|---|---|---|
| 1 | **Front-end wafer fabrication** — compute die, I/O die, chiplet logic | TSMC N3/N4 fab (Hsinchu, Phoenix) | Singulated logic dies | None |
| 2 | **HBM stack fabrication** — DRAM die stacks with TSVs and base-die controller | SK Hynix / Samsung / Micron memory fabs | HBM3E / HBM4 stacks (8-16 dies per cube, 24-36 GB capacity) | None |
| 3 | **Silicon interposer fabrication** — TSV etching, on-wafer RDL, micro-bump formation | TSMC CoWoS line (Longtan / AP6 / AP7) | Silicon interposer with TSVs + 4-6 RDL layers + micro-bumps (40-100μm pitch) | None |
| 4 | **Organic substrate fabrication** — BT-resin core + ABF build-up dielectric + Cu RDL | Ibiden / Unimicron / Nan Ya / Shinko fabs (Japan + Taiwan) | FC-BGA organic substrate (80×100mm at B300, projected 120×180mm at EMIB-T, 150×200mm frontier) with 14-20 ABF build-up layers per side | **30-60g of ABF consumed irreversibly per substrate**, at all 14-20 build-up layers |
| 5 | **Die-to-interposer attach** — compute die + HBM stacks bonded to silicon interposer | TSMC CoWoS line | Compute die + HBM mounted on silicon interposer via micro-bumps (40-100μm pitch) or hybrid bonding (1-9μm pitch at frontier HBM4) | None |
| 6 | **Interposer-to-substrate attach** — silicon-interposer-with-dies assembly bonded to organic substrate | TSMC CoWoS line | Full stack: dies → silicon interposer → organic substrate, via flip-chip bumps (~150-200μm pitch) | ABF already consumed in stage 4 |
| 7 | **BGA ball attach + underfill + overmold** — board-level interconnect + mechanical protection | TSMC CoWoS or OSAT (ASE, Amkor) | Finished package with thousands of BGA balls (B300: ~5,000+ balls at 0.8-1.0mm pitch) | None |
| 8 | **Test + burn-in + ship** — electrical test, thermal cycling, screening | TSMC + OSAT | Tested package shipped to OEM (Foxconn, Quanta, Dell, HPE) for server integration | None |

**Interposer vs substrate distinction** (the architectural reason both layers exist):

| Feature | Silicon interposer (stage 3, TSMC) | Organic substrate (stage 4, Ibiden / Unimicron, ABF-based) |
|---|---|---|
| Base material | Silicon wafer (12") | BT-resin core (from MGC) + ABF build-up dielectric (from Ajinomoto) |
| Fabrication location | TSMC CoWoS line | Substrate-vendor specialized factory |
| Trace pitch | 1-2μm (lithography-defined on silicon) | 15-30μm (laser-drilled vias + photolithography-defined Cu traces) |
| Connection pitch (top side) | 40-100μm micro-bumps to dies | 150-200μm flip-chip bumps to interposer |
| Connection pitch (bottom side) | (Connects to substrate above, not PCB) | 0.8-1.0mm BGA balls to PCB / motherboard |
| RDL / build-up layers | 4-6 on silicon wafer surface | 14-20 ABF build-up layers per side |
| Cost per cm² | 10-30× organic (silicon front-end-grade) | Baseline |
| Function in package | High-density die-to-die interconnect with minimum signal loss | Fan-out from interposer-pitch (~100μm) down to board-pitch (~1mm); mechanical support for BGA attachment to PCB |
| ABF presence | None — silicon-only | **The entire dielectric stack is ABF** (or ABF + Sekisui hybrid in some accounts) |

The interposer + substrate stack forms a "fan-out hierarchy" from chip-level micron-pitch wiring (silicon interposer) to board-level millimeter-pitch BGA balls (organic substrate). Both are required because:
- Silicon interposer is too small (max ~6-8-reticle-stitched at ~120×100mm) and too expensive ($500-2,000 per finished interposer) to interface directly to the PCB
- Organic substrate is too coarse (trace pitch limited to ~15μm) to interface directly to die-level micro-bump pitches (~40μm)
- The substrate provides 5-10× pitch fan-out and ~50-100× area-fan-out from the interposer to the BGA pattern

**Where ABF demand growth comes from in this flow**:

1. **Substrate body-size growth (stage 4)**: as compute + HBM stacks on a single package grow, the silicon interposer footprint grows (stage 3), forcing the organic substrate underneath (stage 4) to grow proportionally. B300 at 80×100mm → projected EMIB-T at 120×180mm → frontier 150×200mm by 2027-2028. Each step compounds ABF consumption ~AREA proportionally (e.g., 120×180mm / 80×100mm = 2.7× ABF per package vs B300).

2. **Layer count growth (stage 4)**: higher die-bump count + tighter signal-routing requirements drive more RDL fan-out layers in the substrate. Modern AI substrate has 14-20 build-up ABF layers per side; PC CPU substrate had 8-12. Each additional layer is one full ABF lamination + cure + laser + plate cycle — multiplicative on per-package ABF consumption.

3. **Yield-driven over-consumption**: at 85% cumulative substrate yield (typical at frontier spec), ~15% of ABF film is consumed in substrates that fail outgoing QC and are scrapped; substrate-vendor yield improvement does not reduce ABF consumption proportionally because yield gains come from later steps (lithography, plating) not from reducing the upstream ABF lamination volume.

4. **CoWoS-L localized-silicon-bridge architecture (TSMC roadmap)**: for some next-gen packages, the full silicon interposer (stage 3) is replaced by smaller localized silicon bridges embedded in the substrate (stage 4). This eliminates some interposer demand but moves complexity into the substrate — substrate body-size grows AND build-up layer count grows. Net effect: ABF demand is preserved or enhanced even as silicon-interposer demand softens.

5. **EMIB / Foveros architecture distinctions**: Intel EMIB (Embedded Multi-die Interconnect Bridge) embeds silicon bridges within the organic substrate — eliminating the full silicon interposer entirely. Intel Foveros adds 3D-stacking with through-silicon vias for die-on-die interconnect. Both use ABF-based organic substrate underneath as the fan-out + BGA-attach layer; EMIB in particular consumes more ABF per package than CoWoS because the embedded silicon bridges require extra ABF dielectric layers above and below the bridge for routing isolation.

6. **HBM hybrid bonding (post-2026 HBM4 generation)**: at HBM4 / HBM4E spec, hybrid bonding (direct Cu-to-Cu) is replacing micro-bumps at the die-die interface within HBM stacks. This affects HBM-base-die substrate ABF demand secondarily — hybrid-bonded HBM stacks need less RDL fan-out in their base-die substrate than micro-bumped HBM stacks, marginally compressing per-HBM-stack ABF consumption, but the effect is dwarfed by the AI-accelerator-substrate-side ABF growth.

7. **Glass substrate evolution (post-2030)**: if glass cores replace BT-resin cores in stage 4, the build-up dielectric layers on top of the glass core may still use ABF or ABF-derived chemistry — the glass-core-plus-organic-build-up architecture preserves ABF demand through ~2032+ (see Glass substrate displacement physics below).

**The architectural insight that drives the bull case**: every visible dimension of advanced-packaging evolution (larger interposers, more chiplets, more HBM stacks, higher signal density, denser RDL fan-out, CoWoS-L localized bridges, EMIB-T embedded silicon, glass core + organic build-up) increases ABF consumption per package. The framework "more silicon dies per package = more interposer area = more substrate area = more ABF" holds across every packaging roadmap visible from 2026-2030. Ajinomoto's revenue is structurally upstream-of-everything in the AI compute scaling cycle — the company sells the irreplaceable input to the irreplaceable substrate underneath the irreplaceable interposer beneath the irreplaceable chips.

**Pricing power trajectory**: Ajinomoto's pricing power is structurally rising 2025-2028 because:

1. **Body-size scaling** (50×50mm Skylake-EP → 120×180mm EMIB-T) compounds film consumption per package at ~2× the substrate-vendor ASP growth rate (since film is area × layer-count product).
2. **Layer-count growth** (8-12 layers PC → 14-16 AI → 16-20 frontier) drives 50-100% incremental film per AI-class package.
3. **Mix shift** to AI substrates (40% in 2017 → 70% in 2025 → guided 75-85% by 2030) shifts blended segment ASP because AI-class film carries 50-100% premium pricing.
4. **Capacity-tight industry** through at least 2028 — substrate vendor capex 2024-2027 (~$8-10B) barely keeps pace with body-size-driven good-substrate capacity compression; Ajinomoto's +50% capacity by 2030 mirrors the substrate-vendor capex curve.
5. **Single-source dynamics** preserve quasi-monopolistic pricing — Sekisui's 5% share has not moved Ajinomoto pricing in 12 years; Hanwha HBF launching 2026 will face the same 18-36 month qualification cycle.

**Competitive landscape**: see Sector note for full vendor matrix. Top-level dynamics:

| Competitor | Share | Threat horizon | Likelihood of taking >5% share by 2030 |
|---|---|---|---|
| **Sekisui Chemical** (SAP build-up film, since 2014) | ~5% | Current | Capped at low-end / niche substrate |
| **Hanwha E-ssential HBF** (Korea, launching 2026) | 0% | 2027-2030 | Moderate at Korean memory-substrate; low at AI-accelerator substrate |
| **Sumitomo Bakelite** | <2% | Current | Minimal — has tested but never volume-adopted |
| **Resonac / Hitachi Chemical** | <1% | Current | Minimal at high-end ABF |
| **Thintronics** (US startup) | 0% | 2028+ | Low — no substrate-vendor qualification |
| **Qin Film** (China) | 0-1% | Current Chinese-domestic | Locked out of Western supply chain |
| **Glass substrates** (TSMC / Samsung R&D) | 0% (R&D) | 2030+ | Real but multi-year — Intel stopped internal funding; TSMC R&D-only |

**Adjacent material monopolies in the substrate stack**:
- **Mitsubishi Gas Chemical** (BT resin core, ~70-80% share) — second monopoly; pricing power is parallel to Ajinomoto's
- **Nittobo + Asahi Kasei** (glass fiber for BT resin reinforcement) — ~3-supplier oligopoly; Nittobo announced 20% price hike 2025
- **Taiyo Ink** (solder mask, ~60% share) — adjacent quasi-monopoly

**Substrate-vendor consolidation**: the 2024 Shinko privatization (Japan Investment Corp + Mitsui + DNP, $5.4B) tightened the Japanese substrate-vendor camp around Ibiden + Shinko-private; combined with the Ajinomoto + MGC + Nittobo + Taiyo Ink Japanese materials concentration, the ABF supply chain is now overwhelmingly Japan-centric at the top end (~70-80% of substrate-materials BOM by value originates in Japan). This is a competitive moat for Ajinomoto (national-champion alignment, METI strategic policy support) and a geopolitical concentration risk for end customers — driving the geographic-diversification mandate that itself supports Japan-camp pricing power on long-term substrate contracts.

**Glass substrate displacement physics**: glass substrates replace the organic BT-resin core (and potentially the build-up dielectric stack including ABF) with an aluminosilicate or borosilicate glass core penetrated by through-glass vias (TGVs). The physics favor glass at frontier-AI-substrate body sizes (120×180mm+) on five vectors:

| Physical property | Organic ABF substrate | Glass substrate | Why it matters at frontier body size |
|---|---|---|---|
| CTE (coefficient of thermal expansion) | 12-17 ppm/°C | 3-9 ppm/°C | Silicon CTE is 2.6 ppm/°C — glass match is 3-4× tighter; at 120×180mm body size, organic-substrate thermal-cycling warpage drops yields to <85% vs glass projected 95%+ |
| Through-via diameter | 30-50μm (laser-drilled in ABF dielectric) | 5-10μm (TGV laser-drilled in glass) | 3-5× I/O density unlock — critical for HBM-base-die-substrate and chiplet-bridge applications where I/O count is the binding constraint |
| Dielectric loss tangent | 0.005-0.008 | ~0.001 | At >50 GHz (NVLink-7 / CXL 4.0 / PCIe 7.0 generation), glass loses ~5× less signal energy per inch of trace — enables longer high-speed lanes across larger substrates without re-driver overhead |
| Young's modulus | 15-25 GPa | ~70 GPa | Glass flexes 3-4× less under mechanical load, improving solder-joint reliability for >1,000-ball BGA arrays at frontier AI accelerators |
| Thermal conductivity | 0.3-0.5 W/m·K | 1-1.5 W/m·K | Glass dissipates 3-5× more substrate-level heat, lowering die-junction temperature at frontier compute densities |

**Why glass hasn't displaced ABF yet (and why the ABF-displacement timeline is multi-year)**:

1. **Manufacturing maturity**: large-body-size glass substrate fabrication is in early-stage R&D; current yields for 120×180mm glass substrates with 1,000+ TGVs run 40-50% versus organic at 80-90%. Economics don't work until yields cross 75%+.
2. **Cost premium**: glass cores cost 3-5× organic cores per unit area; TGV fabrication adds another 2-3× cost layer (each via is individually laser-drilled and electroplated). Total substrate cost at frontier glass spec runs 4-7× equivalent organic — only viable for the highest-end packages where substrate cost is <5% of finished-package value.
3. **Substrate-vendor capex inertia**: Ibiden + Unimicron + Nan Ya hold ~$5-10B combined in organic-substrate manufacturing lines on a 7-10 year depreciation curve. Migration to glass requires complete new equipment + qualification cycles (3-5 year transition window per vendor).
4. **End-customer qualification**: TSMC, Intel, NVIDIA require 18-36 months per substrate-technology change at each end-customer; glass qualification at TSMC CoWoS or Intel Foveros has not begun in volume — first qualification samples 2027-2028.

**The Ajinomoto-specific nuance — glass core + organic build-up architecture preserves ABF demand**: even in a "glass substrate" world, glass substrates likely retain organic build-up dielectric layers (where ABF lives) on top of the glass core for RDL (redistribution-layer) fabrication. The intermediate architecture is: glass core (replacing BT-resin core) + TGVs (replacing organic core vias) + organic build-up dielectric (ABF or reformulated equivalent) for RDL layers. In this hybrid, ABF demand is preserved and arguably enhanced — more RDL layers per package to leverage the higher I/O density unlocked by TGVs. The pure-displacement scenario for ABF is only "full-glass substrate" with glass build-up dielectric replacing ABF — a technology that is 2032-2034+ at earliest with no visible roadmap before mid-2030s.

This directionally insulates Ajinomoto's ABF franchise from the 2030+ glass-substrate transition that materially threatens organic-substrate-vendor cohort economics: Ibiden / Unimicron lose substrate-fabrication value (substrate-vendor capex obsolescence) 2-4 years before Ajinomoto loses ABF dielectric value (build-up dielectric survives the core transition). The competitive-threat-stack from glass against Ajinomoto is therefore narrower and longer-dated than against the substrate vendors immediately downstream.

## Key Metrics

| Metric | Value | Notes |
|---|---|---|
| Market Cap | ~¥5.04T (~US$34B) | May 15, 2026; stock ¥5,269; ~957M shares outstanding |
| EV/Revenue | ~3.2× consolidated | ¥5.04T MC + ~¥150B net debt against ¥1,584B FY2025 sales |
| Revenue Growth (FY2025) | +3% consolidated / +31% Electronic Materials | Electronic Materials segment is the growth engine; food + amino acid grew low single digits |
| Gross Margin | ~36% consolidated | Electronic Materials segment >65% gross margin (implied from >50% operating margin); food + amino acid ~30-32% |
| Operating Margin | ~11.4% consolidated / >50% Electronic Materials | Segment-level Electronic Materials margin is the structural driver |
| Business Profit (FY2025) | ¥181.1B (+13% YoY) | Of which Electronic Materials ¥54.6B (+35% YoY) ≈ 30% of total |
| FCF Yield | ~3.5-4% | Capex elevated 2024-2030 (Gunma + Kawasaki ¥25B + Gifu plant from 2028); FCF compressed during capex cycle |
| Forward P/E | ~38× FY2026E | EPS guided ~¥140; stock ¥5,269 |
| Forward EV/Adj. EBITDA | ~16-18× | Conglomerate multiple; Electronic Materials alone at standalone semi-materials multiples would imply 25-30× |
| Dividend yield | ~1.5% | ¥80/share annual; payout ratio ~55-60% |
| Net cash position | ~¥150B net debt | Modest leverage; ample capacity for ABF capex commitments |
| Sell-side consensus 12M PT | ¥4,288-4,939 avg (Buy bias; 10 buys / 3 holds / 0 sells across 13 analysts) | Stock trades above most consensus PTs; Morningstar fair value ¥8,178 |
| ABF segment standalone implied value (SOTP) | ¥1.5-2.5T at 25-30× run-rate EBIT | Consolidated MC ¥5.04T less ¥3-3.5T implied for food + amino + pharma at peer multiples = ¥1.5-2T residual for Electronic Materials franchise |

> [!question] 2026-05-16 → Addressed 2026-05-16
> **Prompt:** *What is the reason for the large delta between P/E ratio and FCF yield. Is normalised FCF yield closer to its reported FCF yield today or closer to its P/E ratio.*
>
> **Response:** The ~100-140bps spread (FCF yield 3.5-4% vs P/E-implied earnings yield 2.6%) reflects four drivers — D&A timing lag ahead of capex catch-up, ¥40-60B working capital release from 2023-2025 SCM program, ~100-200bps cash-tax-below-P&L-tax deferred benefit, and equity-method JV dividend overhang above recognized earnings. Normalized FCF yield (post-capex-peak + segment-margin capture) lands ~4-5% near-term and ~6-7% by FY2030 — structurally closer to reported FCF yield than to P/E-implied earnings yield, because the P/E 38× embeds a growth-markup premium on FY2028+ EPS expansion (¥140 → ¥260-300 bull) rather than a fair-value-on-current-earnings signal. Full reconciliation table + normalized-yield trajectory: §Key Metrics → Valuation Decomposition: SOTP and FCF Bridge.

### Valuation Decomposition: SOTP and FCF Bridge

**Pre-ABF-era food peer multiple**: 2010-2019 Ajinomoto traded at ~20-25× P/E in line with Japanese food peer median — Kikkoman ~25×, Nissin Foods ~22×, Yakult ~24×, Suntory Beverage ~20×, Ajinomoto ~22× (pre-ABF, pre-Murata-like-monopoly-recognition). Food peer growth rates running at 3-5% revenue CAGR with stable 11-14% operating margins support the 20-25× P/E band durably.

**SOTP attribution by segment** — applying peer multiples to FY2025 segment business profit:

| Segment | FY2025 BP (¥B) | Applied multiple | Multiple rationale | Implied value (¥T) |
|---|---|---|---|---|
| Food Products | ~95 | 22× | Japanese food peer median (Kikkoman / Nissin / Yakult / Suntory) | ~2.1 |
| Amino Acids | ~25 | 14× | Animal-nutrition + industrial-input commodity exposure, lower-multiple band | ~0.35 |
| Healthcare & Others | ~10 | 18× | Specialty chemistry / pharma intermediate peer set | ~0.18 |
| **Non-Electronic-Materials subtotal** | **~130** | — | — | **~2.6** |
| **Implied Electronic Materials residual** | (¥55B segment OP) | — | (Residual = ¥5.04T MC − ¥2.6T) | **~2.4** |
| Electronic Materials standalone OP multiple | — | **~44×** | Implied at residual valuation | — |

The food + amino + healthcare segments support ~50-55% of current ¥5.04T market cap at peer multiples; the residual ~45-50% (~¥2.3-2.5T) is implicitly attributed to Electronic Materials at a ~44× standalone operating-profit multiple. The 44× standalone multiple sits in line with high-quality semi-materials monopolies (peer reference: Shin-Etsu Chemical ~35×, Tokyo Electron ~30×, ASML ~35-40×) — confirming the SOTP arithmetic supports current valuation rather than implying a deep arbitrage. The market-cap-to-segment-value bridge has moved meaningfully: at ¥3,500 in late 2024, food + amino + healthcare absorbed ~75% of market cap and Electronic Materials residual was ~25% at ~25× standalone multiple (deep SOTP value); the run to ¥5,269 has compressed the SOTP arbitrage to baseline-fair.

**P/E vs FCF yield reconciliation** — the ~100-140bps spread between FCF yield (3.5-4%) and earnings yield (2.6%, implied by 38× P/E) is driven by four mechanical factors:

1. **D&A timing lag**: FY2025 D&A ~¥80B currently exceeds ABF-segment growth capex run-rate; reported earnings include this D&A as a non-cash expense, while FCF adds it back. As Gunma + Kawasaki expansion (¥25B 2024-2030) + Gifu plant (¥30-50B 2028-2032) ramps, capex catches up to D&A and this differential compresses by FY2028.
2. **Working capital release**: Ajinomoto's group SCM optimization (2023-2025 efficiency program) has released ~¥40-60B cumulative working capital; this benefit reverses to neutral by FY2027.
3. **Cash tax below P&L tax**: cash tax has run ~100-200bps below P&L effective tax rate on past-capex deferred-tax benefits; converges by FY2028.
4. **Equity-method JV dividends**: Ajinomoto Genexine, AjiPro-L, and other JV operations recognize equity earnings below operating profit but cash dividends often exceed P&L recognition by ¥5-10B annually.

**Normalized FCF yield trajectory**:

| Year | Business profit (¥B) | FCF conversion | Normalized FCF (¥B) | FCF yield at ¥5.04T MC |
|---|---|---|---|---|
| FY2025 reported | 181 | ~90% (working-cap tailwind) | ~163 | ~3.2% (actual: 3.5-4% with non-recurring items) |
| FY2028E bull | 250-300 | ~80% (capex peak) | 200-240 | ~4.0-4.8% |
| FY2030E bull | 350-450 | ~85% (post-capex normalization) | 300-380 | ~6.0-7.5% |

**Answering the framing question**: normalized FCF yield is structurally closer to reported FCF yield (3.5-4%) than to P/E-implied earnings yield (2.6%), and rises above current reported FCF yield as the capex cycle peaks and ABF-segment OP compounds. The P/E 38× embeds a growth-markup premium on FY2028+ EPS expansion (¥140 FY2026E → ¥260-300 FY2028 bull) rather than a fair-value-on-current-earnings signal. The implication: P/E-based mean-reversion bears are anchored on the wrong metric — the FCF-yield trajectory is the structurally rising indicator that supports continued multiple support through FY2028. The gap closes by both EPS growing into the multiple AND FCF capturing the segment-margin expansion, not by P/E mean-reverting downward.

## Bull Case

A genuine 2-3× equity return scenario over a 3-5 year horizon — not impossible given the segment trajectory, but requires several structural conditions to hold simultaneously:

**Mechanism**: Electronic Materials segment compounds at 30-40% annual revenue growth for FY2025-2028 (consistent with current run-rate +31% YoY and AI substrate body-size scaling), expanding from ¥101B FY2025 to ¥250-300B by FY2028. Segment operating margin holds at 50-55% (consistent with FY2025 entry margin and continued AI-class mix shift), driving FY2028 segment operating profit to ¥125-165B. At that scale, Electronic Materials is the dominant earnings driver of consolidated Ajinomoto (vs ¥55B FY2025), and the conglomerate-multiple discount partially closes.

**Financial trajectory**:
- FY2025 actual: ¥101B segment sales, ¥54.6B segment OP, ~30% of consolidated BP
- FY2028E bull: ¥250-300B segment sales, ¥125-165B segment OP, ~50% of consolidated BP
- Consolidated business profit FY2028E bull: ~¥250-300B (vs ¥181B FY2025), driven primarily by ABF expansion
- Multiple re-rating: from ~38× P/E (food-conglomerate anchor) toward ~30× P/E (mixed conglomerate with semi-materials weight); minimal multiple compression on absolute scale but EPS doubles from ~¥140 to ~¥260-300

**FY2030 segment-share extension scenario**: extending the bull case to FY2030 under the chip-volume-doubling × substrate-AREA × layer-count × yield-adjusted-throughput framework:

| Driver | 2026 → 2030 multiplier | Source |
|---|---|---|
| AI accelerator unit volume (chip-level deliveries) | 2.0× | Base assumption: advanced-packaging finished-product volume doubles 2026 → 2030 |
| Substrate area per package (body-size scaling, e.g., 80×100mm → 120×180mm → 150×200mm frontier) | 2.5× | Intel EMIB-T 2026 + projected EMIB-T-Plus 2027 + NVIDIA Rubin Ultra body-size step |
| Layer count per substrate (14-16 → 18-20 avg) | 1.20× | Frontier-AI-substrate roadmap commentary at Ibiden / Unimicron |
| Yield-adjusted throughput (better yields = more usable film per gross output) | 1.10× | Substrate-vendor yield improvement on mature ramps |
| AI mix-shift premium ASP (mix shift toward higher-margin AI film) | 1.15× | Ajinomoto guidance: AI mix 70% (FY2025) → 75-85% (FY2030) |
| **Composite ABF revenue multiplier 2026 → 2030** | **~7.6×** | 2.0 × 2.5 × 1.20 × 1.10 × 1.15 |

Applying to FY2026E ABF segment baseline (~¥130B, extrapolated from FY2025 ¥101B + 30% growth): **FY2030 ABF segment revenue projection ¥800B–¥1.0T** at the central case (¥130B × 6-8×, accounting for execution slippage and competitive entry). At 50-55% segment operating margin: **FY2030 ABF segment operating profit ¥400-550B**.

**FY2030 consolidated composition**:

| FY2030 line | Bull case range | vs FY2025 |
|---|---|---|
| Food + amino + healthcare revenue (3-4% CAGR) | ¥1,720-1,790B | ¥1,483B → +16-21% |
| ABF segment revenue | ¥800-1,000B | ¥101B → ~8-10× |
| Total revenue | ¥2,520-2,790B | ¥1,584B → +59-76% |
| **ABF as % of revenue** | **~32-36%** | vs ~6% today |
| Food + amino + healthcare BP | ¥150-170B | ¥126B → +19-35% |
| ABF segment BP | ¥400-550B | ¥55B → ~7-10× |
| Total business profit | ¥550-720B | ¥181B → ~3-4× |
| **ABF as % of business profit (≈EBIT)** | **~73-76%** | vs ~30% today |

**Caveats and execution-discounted scenarios**: the ~7.6× composite multiplier assumes near-frictionless compounding; realistic execution discounts to:

| Realization | ABF revenue multiplier 2026→2030 | FY2030 ABF revenue | ABF % of revenue | ABF % of EBIT |
|---|---|---|---|---|
| 100% Bull realization (frictionless compounding) | ~7.6× | ~¥1.0T | ~36% | ~76% |
| 60-70% Bull (Hanwha qualifies at 2-3% share, mild ASP pressure on contract resets) | ~5× | ~¥650B | ~26-28% | ~65-68% |
| 40-50% Bull (Hanwha qualifies at 8-10% share + mild AI demand reset 2027-2028) | ~3.5× | ~¥450B | ~20% | ~55-60% |
| 25-30% Bull (Hanwha 10%+ share AND AI capex digestion AND mild substrate-vendor pricing-power compression) | ~2.5× | ~¥320B | ~16% | ~45-50% |

The directional point survives even at 25-30% realization: by FY2030, ABF is the dominant EBIT driver of Ajinomoto in every scenario except a coordinated multi-mechanism bear case (Hanwha + glass substrate + AI demand reset). The asymmetric segment-to-consolidated shift is the underlying engine for the equity multiple re-rating — the conglomerate-multiple narrative becomes untenable by FY2028-2030 because the ABF segment's earnings dominance forces an equity-frame rebase from food-staple to specialty-semi-materials regardless of which intermediate scenario unfolds.

**Valuation outcome**: stock target ¥8,000-10,000 (~50-90% upside from ¥5,269), within Morningstar's existing ¥8,178 fair value frame.

**What has to go right**:
1. AI substrate body sizes continue scaling to 100×100mm+ / 120×180mm EMIB-T volume by H2 2026, with NVIDIA Rubin substrate ramp by 2027 and Rubin Ultra by 2028.
2. Hanwha E-ssential HBF qualification is slower than 2027-2028 (Sekisui-trajectory: ~5% share after 10+ years).
3. Glass substrate volume remains 2030+ (current consensus); TSMC accelerated R&D does not pull forward to 2027-2028.
4. Kawasaki + Gunma capacity expansion ramps on schedule (no execution delays).
5. Substrate-vendor pricing pass-through holds — Ibiden + Unimicron continue to accept 50-100% film-ASP step-up on AI substrate body sizes.

**Probability assessment**: 25-35%. The structural conditions are individually >60% likely each, but the compound probability of all five lining up over 3-5 years is moderate. The principal upside-removal risk is Hanwha qualification or glass substrate acceleration faster than expected.

## Bear Case

A 30-40% drawdown scenario over 18-36 months, driven by either competitive entry or end-demand reset:

**Mechanism 1 (Competitive — Hanwha)**: Hanwha E-ssential HBF qualifies at Simmtech for SK Hynix HBM-base-die substrate by H2 2027 + at Korean substrate vendor Samsung Electro-Mechanics by H1 2028, taking 8-12% global share within 2-3 years of commercial launch. Ajinomoto market share drops from 95% to 83-87% by FY2029. The visible competitive entry breaks the monopoly-multiple narrative — segment operating margin compresses from 50%+ to 38-42% as Ajinomoto absorbs pricing concessions on Korean-domestic accounts and lowers ASP on substrate-vendor contracts to retain Western share. Electronic Materials operating profit growth flatlines or compresses; consolidated business profit growth reverts toward food-segment cyclicality (~3-5% annually). Equity multiple compresses to ~28-32× P/E (closer to food peer multiples).

**Mechanism 2 (Demand — AI capex reset)**: AI capex digestion + monetization gap (per [[Macro & Technology/AI Bubble Risk and Semiconductor Valuations]] — $650B annual AI revenue requirement by 2030; current monetization lags) triggers a hyperscaler capex pause in 2027-2028. Substrate vendor orders for AI accelerator carriers drop 25-40% in a 6-12 month window. Ajinomoto's AI-class ABF revenue (~70% of segment) compresses 25-30%; segment operating margin compresses 5-8pp on under-absorption + ASP pressure. Consolidated FY2028 business profit declines 8-12% YoY. Equity multiple compresses to 25-28× P/E on cyclical-substrate fear.

**Mechanism 3 (Catastrophic single-facility)**: Kawasaki facility incident (earthquake, fire, supply chain disruption) takes ABF production offline for 6-18 months. Stock drops 35-50% on supply-chain-shock narrative; recovery depends on Gunma + Gifu (2032) plant capacity adequacy.

**Bear price target across mechanisms 1+2** (probability-weighted): ¥3,400-3,800 (~30-35% downside). Mechanism 3 (Kawasaki incident) is a tail risk that would drive ¥2,500-3,000 (50%+ downside) but probability-weighted low (<5% over 3 years).

**What has to go wrong**:
1. Hanwha HBF + glass substrate timeline accelerates faster than the qualification-cycle moat anticipates.
2. AI substrate end-demand collapses on hyperscaler capex digestion (J.P. Morgan $650B threshold not met).
3. Substrate-vendor pricing power compresses (TSMC vertical integration of CoWoS carrier substrate, Intel EMIB-T cost discipline at scale) cascading upstream.
4. ABF segment capex cycle (¥60-100B 2024-2032) compresses segment ROIC faster than the AI-substrate margin tailwind compounds.

**Probability assessment**: combined bear-mechanism probability 20-30% over 3 years; tail catastrophic ~5%.

## Catalysts

| Date / window | Event | Direction | Significance |
|---|---|---|---|
| H2 2026 (Aug-Nov 2026) | Intel EMIB-T volume ramp (Microsoft Maia 2, AWS AI Fabric, Google AI accelerator) | Bullish | 120×180mm body = ~2× ABF consumption per package vs B300; volume signal validates AI-substrate ramp |
| Q3 2026 (Aug 2026) | Ajinomoto Q1 FY2026 earnings | Both | First read on FY2026 Electronic Materials trajectory; consensus expects continued >25% segment growth |
| H2 2026 | Hanwha E-ssential HBF commercial launch | Bearish | First competitive ABF entrant in 30 years; substrate-vendor qualification path becomes visible |
| Q4 2026 | NVIDIA Rubin substrate qualification at Ibiden + Unimicron | Bullish | Rubin substrate consumption ramps Q1 2027; ABF demand visibility through 2028 |
| H2 2026 | TSMC COUPE / advanced-packaging roadmap update (Symposium on VLSI Technology, Hot Chips) | Both | First substantive glass-substrate timeline commentary; will inform 2028-2030 demand trajectory |
| FY2027 (Apr 2026-Mar 2027) | Full-year Electronic Materials sales target (Ajinomoto's own guidance) | Bullish if exceeded | Management guides ABF-driven segment growth +25-30% for FY2026; beat would re-rate |
| H1 2027 | Hanwha HBF first substrate-vendor qualification at Simmtech / Samsung Electro-Mechanics | Bearish if confirmed | Visible share-loss path begins; Ajinomoto narrative crack |
| H2 2027 | NVIDIA Rubin Ultra and Intel EMIB-T-Plus body-size confirmations (150×200mm projected) | Bullish | Frontier body-size step compounds ABF consumption per package |
| 2028 | Kani-Mitake Gifu plant construction start | Bullish if on schedule | Visible third-facility geographic-diversification execution |
| 2028-2029 | Glass substrate first volume orders (TSMC / Samsung) | Bearish if accelerates | Long-term ABF displacement timeline visibility |
| 2030 | Gunma + Kawasaki +50% capacity expansion fully operational | Bullish if delivered | Capacity-tight industry overhang lifts |
| 2032 | Kani-Mitake third plant operational | Bullish (resilience + capacity) | Concentration risk discount unwinds |

## Risks

**Thesis risks (investment case is wrong)**:

1. **Hanwha E-ssential HBF qualification faster than the 18-36 month base-case timeline.** Hanwha has Korean memory-ecosystem commercial relationships that may compress qualification cycles at SK Hynix-adjacent substrate vendors (Simmtech). If HBF qualifies at Simmtech + Samsung Electro-Mechanics by 2027 and reaches 8-12% global share by 2029, the monopoly-multiple narrative breaks and segment operating margin compresses to 38-42%.

2. **Glass substrate displacement timeline accelerates from 2030+ to 2027-2028.** TSMC has committed engineering resources to glass substrate R&D; if TSMC announces CoWoS-glass volume by 2027 or NVIDIA Rubin Ultra-equivalent on glass substrate by 2028, Ajinomoto's frontier-AI-substrate revenue (the highest-margin mix) starts compressing 2-3 years ahead of model. Intel discontinued internal glass substrate funding mid-2025 (Intel-specific de-risk) but Samsung + TSMC continue investing.

3. **Substrate-vendor pricing pass-through breaks.** Ibiden + Unimicron consume ABF as a cost of goods sold and pass through to end customers. If TSMC vertically integrates CoWoS carrier substrate at Chunan, Unimicron's substrate-vendor margin compresses and substrate vendor pricing power against Ajinomoto compresses correspondingly. Ajinomoto film ASP could face structural pressure 2027-2028 even at constant AI substrate volume.

4. **AI capex digestion / hyperscaler reset.** Hyperscaler capex compresses through 2027 (per [[Macro & Technology/AI Bubble Risk and Semiconductor Valuations]] — $650B revenue requirement vs current monetization lag); AI accelerator orders drop 25-40% in a single 6-12 month window. ABF segment growth flattens; multiple compresses.

5. **Conglomerate capital allocation suboptimization.** Management allocates 50-60% of group FCF to food + amino-acid growth initiatives rather than accelerating ABF capacity + geographic diversification. Segment growth is constrained by Kawasaki-Gunma capacity adequacy through 2030 rather than demand; pricing power captures but unit volume capped. Equity narrative remains conglomerate-discounted indefinitely.

**Position risks (thesis right but stock falls)**:

6. **Kawasaki seismic event or facility incident.** Low-probability (<5% per 5-year window) but catastrophic if it occurs — 6-18 month ABF production disruption with 35-50% equity drawdown.

7. **Conglomerate-discount sustainability.** Even if Electronic Materials compounds at the bull-case trajectory, management may never proactively spin / list / separate the segment. Equity remains permanently structurally undervalued without a forcing-function catalyst.

8. **JPY appreciation against USD / TWD.** Substrate vendors and end customers price in USD; Ajinomoto reports in JPY. A 10-15% JPY appreciation (e.g., BOJ rate normalization, US Fed cuts) compresses reported ABF revenue + earnings 8-12% without operating-business change. JPY currently ~¥155/USD (favorable); BOJ exit from negative rates already priced in but currency direction uncertain.

9. **Food / amino-acid segment margin compression.** US frozen-food competitive intensity, Asian seasoning input cost inflation, or animal-nutrition cyclicality could compress 70%-of-revenue food segment margin by 100-200bp, compressing consolidated EPS 5-8% even with strong ABF growth. The equity narrative is more vulnerable to food-segment shocks than the underlying ABF franchise warrants.

10. **Crowded long.** Ajinomoto is increasingly being identified by Japanese institutional + Western semi-focused funds as the "hidden Japanese semi-monopoly trade" (alongside [[Theses/6981 - Murata Manufacturing]]). Positioning risk if the trade becomes consensus and faces multi-fund unwind on AI cycle concerns.

## Conviction Triggers

→ **HIGH if**: Electronic Materials FY2026 segment sales exceed ¥150B (+50% YoY vs current run-rate +31%) AND segment operating margin holds above 50% AND Hanwha HBF fails to qualify at any major substrate vendor by H2 2027. This combination validates the AI-substrate compounding case beyond current model and removes the largest visible competitive threat. Stock target would be ¥9,000-11,000 over 24 months.

→ **LOW if**: Electronic Materials segment quarterly operating margin compresses below 42% for any single quarter (FY2026 or FY2027) AND Hanwha HBF or another competitor qualifies at Ibiden / Unimicron / Nan Ya for AI substrate spec. This combination signals the monopoly-margin franchise is structurally compressing. Reduce position, re-underwrite at ¥4,000-4,500.

→ **CLOSE if**: TSMC announces glass substrate volume production timeline within 24 months (2028 or earlier) on CoWoS or successor packaging, OR Hanwha E-ssential reaches ≥10% global ABF share confirmed by independent industry research within 36 months. Either condition fundamentally compresses the structural monopoly narrative; conviction MEDIUM cannot survive demonstrated competitive displacement.

## Related Research

- [[Sectors/ABF Substrates & Advanced Packaging Supply Chain]] — sector primer documenting the full ABF substrate stack (Ajinomoto + MGC + substrate vendors + end customers); this thesis is the upstream-monopoly leg of the substrate-stack capital-allocation framework
- [[Sectors/Semiconductor Foundries]] — TSMC CoWoS + Intel Foveros / EMIB / EMIB-T + Samsung I-Cube demand engines that drive substrate body-size growth and ABF consumption
- [[Sectors/Semiconductor Capital Equipment]] — substrate manufacturing equipment + adjacent specialty equipment / materials context
- [[Sectors/Compute & AI Compute Accelerators]] — end-customer demand (NVIDIA / AMD / AVGO / Intel / hyperscaler ASIC) that flows through substrate vendors to ABF
- [[Sectors/DRAM & HBM Memory]] — HBM stack integration; HBM-base-die substrate is the Hanwha HBF qualification entry point
- [[Sectors/MLCC & Power Semiconductors]] — adjacent Japanese specialty monopoly precedent ([[Theses/6981 - Murata Manufacturing]])
- [[Theses/TSM - Taiwan Semiconductor]] — CoWoS demand engine; carrier-substrate franchise that consumes ~40-45% of total ABF for AI; glass-substrate disruption risk to ABF
- [[Theses/INTC - Intel]] — Foveros + EMIB + EMIB-T advanced-packaging franchise; Ibiden / Shinko substrate consumption that drives ABF demand
- [[Theses/NVDA - Nvidia]] — Blackwell + Rubin substrate consumption volumes that drive ABF body-size growth
- [[Theses/AMD - Advanced Micro Devices]] — MI accelerator + EPYC chiplet substrate consumption
- [[Theses/AVGO - Broadcom]] — custom-ASIC substrate consumption via TSMC CoWoS
- [[Theses/BESI - BE Semiconductor Industries]] — hybrid-bonding tooling at die-substrate interface; substrate spec evolution drives BESI throughput requirements
- [[Theses/000660 - SK Hynix]] — HBM-base-die substrate is a Hanwha HBF qualification entry point; ABF consumption per HBM stack
- [[Theses/6981 - Murata Manufacturing]] — analogous Japanese specialty-monopoly-hidden-in-mid-cap precedent; MLCC market position similar to ABF substrate-materials position
- [[Theses/AMAT - Applied Materials]], [[Theses/LRCX - Lam Research]], [[Theses/KLA - KLA Corporation]] — semicap front-end + advanced-packaging equipment cluster that supports the substrate-volume narrative
- [[Macro & Technology/AI Bubble Risk and Semiconductor Valuations]] — AI capex monetization gap framework; bear-case Mechanism 2 (AI demand reset) source
- [[Research/2026-05-16 - Insight Surface Scan]] — surface scan that flagged Ajinomoto as top-priority initiation candidate (Insight #1)
- [[Research/2026-05-11 - HBM Packaging Equipment Stack - MR-MUF to Hybrid Bonding Transition - deep-dive]] — adjacent packaging equipment / materials context; cites Ajinomoto ABF 98% IP licensing on substrate dielectric
- [[Research/2026-05-24 - 2802 vs 6857 - Competitive Comparison]] — Ajinomoto vs Advantest on ROIC × valuation × growth; documents the conglomerate-discount asymmetry vs the AI-purity premium, the ~75% shared AI-capex driver correlation, and the segment-vs-group ROIC parity that defines the preference trigger between the two names

## Log

### 2026-05-16
- Initial thesis created. Conviction: medium — ~95% ABF film monopoly inside ¥1.6T food + amino-acid conglomerate; Electronic Materials segment ¥101B sales (+31% YoY) / ¥55B OP (+35% YoY) / >50% segment margin / 30% of consolidated business profit despite <7% of revenue. AI substrate body-size growth (50×50mm → 120×180mm) + layer-count growth (8 → 16-20) + AI mix shift (40% → 70% → guided 75-85% by FY2030) compound ABF consumption per package on a steeper curve than substrate-vendor ASP step-up the market has already priced. Three credible competitive entrants (Hanwha E-ssential HBF 2026 launch, Sekisui SAP ~5% share, glass substrates at TSMC R&D) cap conviction at MEDIUM; rally to ¥5,269 (vs ~¥4,288-4,939 sell-side avg, Morningstar fair value ¥8,178) has absorbed easy SOTP arbitrage. Three-to-five year compounder bet on a tightening AI-substrate cycle, not a 12-month re-rate. Stock above most consensus price targets but Morningstar fair value implies ~55% upside; bull case ¥8,000-10,000 on AI substrate compounding through FY2028. Reminder to user: run `/graph last` to register new thesis in vault adjacency map.
- Addressed user callouts: 4 [!question] callouts — FY2030 ABF share projection (composite 7.6× revenue multiplier → 32-36% of revenue / 73-76% of EBIT bull, 16-20% / 45-50% bear-bull; Bull Case → FY2030 extension); pre-ABF food peer multiple 20-25× P/E, SOTP attributes ~¥2.6T (~52% MC) to food+amino+healthcare and ~¥2.4T (~48% MC) to Electronic Materials at ~44× standalone OP multiple (Key Metrics → Valuation Decomposition); glass substrate physics — 5-vector advantage (CTE / TGV precision / loss tangent / Young's modulus / thermal conductivity) but glass-core+organic-build-up intermediate architecture preserves ABF demand through 2032+ (Industry Context → Glass substrate displacement physics); P/E-FCF reconciliation — 100-140bps spread driven by D&A lag + working capital release + cash-tax deferral + JV dividends, normalized FCF yield 4-5% near-term and 6-7% by FY2030 closer to reported FCF than P/E-implied 2.6% (Key Metrics → Valuation Decomposition). Conviction unchanged at MEDIUM — analyses validate existing structural framing; no new disconfirming evidence surfaced.
- Addressed user callout: detailed ABF engineering view + end-to-end advanced packaging process flow — added 7-step ABF build-up engineering subsection (Business Model & Product Description → ABF application engineering) covering vacuum lamination → cure → laser drilling → desmear → electroless seed → pattern plating → flash etch, plus B-stage chemistry / filler tuning / 16-layer compounding-yield math showing why Ajinomoto IP is structurally hard to replicate; added 8-stage end-to-end packaging flow table + interposer-vs-substrate fan-out hierarchy distinction (Industry Context → End-to-end advanced packaging process flow) placing ABF consumption in stage 4 (organic substrate fab) of front-end wafer → HBM stack → silicon interposer → organic substrate → die-to-interposer attach → interposer-to-substrate attach → BGA/underfill → test+ship; added 7 ABF-demand-growth drivers including CoWoS-L localized-silicon-bridge and EMIB embedded-silicon architectures, both of which preserve or grow ABF demand even as silicon-interposer demand softens. Conviction unchanged at MEDIUM — engineering deep-dive strengthens the process-moat framing at >50% segment margin; no new disconfirming evidence.
- Refined ABF function framing: added "ABF function — dielectric insulator, not adhesive" lead-in to ABF application engineering subsection (Business Model & Product Description) pre-empting common reader confusion that the film+lamination+cure application sequence implies adhesive function. Clarifies that primary function is electrical insulation between 14-20 copper RDL layers in build-up stack, with vias as controlled punctures of the dielectric; defining specs are dielectric (Dk ~3.5, Df 0.005-0.008, thickness ±2-3μm, laser drillability 30-50μm) not adhesive; categorical placement alongside FR-4 prepreg / low-k dielectric / BT-resin core, distinct from underfill / DAF / TIM adhesives. No structural thesis change — clarifies existing content; conviction unchanged at MEDIUM.

### 2026-05-22 (manual)
- Status change: portfolio-wide realignment — not in current Live Portfolio holdings; status active→monitoring.

### 2026-05-24
- Comparison [[Research/2026-05-24 - 2802 vs 6857 - Competitive Comparison]]: Advantest wins on consolidated ROIC (~25-28% vs ~10-12%) and headline growth (+26% vs +3% group / +31% Electronic Materials), but Ajinomoto wins on every valuation multiple (EV/Revenue 3.2× vs 5.8×, fwd P/E 38× vs 40-57×, FCF yield 3.5-4% vs 2.1%) and offers a rare conglomerate-discount asymmetry where the ABF segment alone (>50% margin, +31% growth) rivals Advantest's standalone ROIC at a fraction of the implied multiple. The two are NOT diversifying — ~75% AI-capex correlation in shared underlying demand drivers (HBM unit volume + AI accelerator wafer starts) means owning both creates hidden AI-cycle concentration. Conviction unchanged at MEDIUM — comparison validates the conglomerate-discount thesis and underscores that the preference flip depends on whether the investor pays for AI-purity (favor Advantest) or embedded segment-discount (favor Ajinomoto), not on which company is fundamentally superior.

### 2026-05-29
- [[Research/2026-05-29 - Earnings Transcripts vs Thesis - 6 Holdings - synthesis]]: corrected Insight #1 food framing — transcripts (through Q3 FYE-Mar-26) show food improving (seasonings driving growth, frozen recovering, FY food forecast revised up), not "dragged by margin pressure." ABF confirmed strong: full-year guided +28% (actual +31%), growth plan revised up, Gunma online Oct 2025. Conviction unchanged (medium).
