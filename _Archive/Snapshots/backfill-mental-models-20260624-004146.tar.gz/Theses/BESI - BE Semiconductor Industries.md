---
date: 2026-04-14
tags: [thesis, semiconductors, BESI, hybrid-bonding, HBM, advanced-packaging, CPO]
status: active
conviction: high
sector: Semiconductor Capital Equipment
ticker: BESI
source: Vault research synthesis + web search (TrendForce, Investing.com, Simply Wall St, Reuters, 36Kr, EE Times, BESI IR)
---

# BESI — BE Semiconductor Industries

## Summary

~67% D2W hybrid bonding market share, 150+ installed systems across 18 customers (TSMC, Intel, Samsung, SK Hynix), and the only production-proven inline bonding platform (Kinex, co-developed with Applied Materials). The market narratives BESI as a pure HBM timing play — this framing is wrong. Switching costs are front-end-grade: ISO 3 cleanrooms, sub-0.5nm surface roughness, queue times measured in minutes. Competitors are 2-3 years behind in production qualification. The correct model: BESI already owns the critical node in 3D integration across logic, memory, NAND, and photonics — each end-market inflects on its own timeline. Dual takeover interest from Lam Research and Applied Materials validates that the two largest WFE companies view BESI's IP as irreplaceable strategic infrastructure.

---

## Key Non-consensus Insights

- **BESI is not an HBM play — it is a 3D integration monopoly the market has miscategorized.** 150+ installed base predominantly at logic foundries (TSMC SoIC, Intel Foveros Direct), not memory fabs. HBM revenue is *additive* to an already-entrenched logic position. 13% selloff on JEDEC relaxation news reflects fundamental misunderstanding of installed base composition.

- **Memory vendor adoption is advancing on survival necessity, not JEDEC timelines.** Samsung HBM share collapsed 41% to 17% from thermal failures, making HCB existential (>20% thermal resistance reduction vs. thermocompression) — dedicated HCB lines at Cheonan independent of any standard. SK Hynix's March 2026 Kinex order is the key underweighted signal: the dominant HBM producer (53-60% share), never used thermocompression, most vocal skeptic, has begun the transition. When the market leader moves, Micron follows.

- **Applied Materials' 9% stake and dual takeover interest validate irreplaceable strategic infrastructure.** AMAT spent five years co-developing Kinex because it cannot offer complete advanced packaging without BESI's bonding technology. Takeover interest from the two largest WFE companies (March 2026). Kinex reduces queue-time contamination from up to 13 hours to minutes. Samsung Semes "lags behind BESI" per April 2026 analysis; ASMPT LITHOBOLT remains pre-production.

- **BESI's competitive position is actively widening, not static.** Hanmi's share at SK Hynix projected to fall from majority to 20-30% by 2026 as HBM4's tighter accuracy requirements favor BESI even in conventional bonding. Gen-2 50nm shipped Q4 2025; Gen-3 sub-25nm in development. Competitors working toward initial production qualification on capabilities BESI delivered two generations ago.

- **Multiple independent demand vectors beyond HBM — silicon photonics and 3D NAND — provide TAM diversification the market ignores.** ~75% share in advanced die attach for TSMC's COUPE co-packaged optics (volume production 2026), CPO market at 37% CAGR to $20B+ by 2036. NVIDIA's Spectrum-X and Quantum-X use TSMC's hybrid bonding. Samsung licensed YMTC's hybrid bonding patent for 400-layer NAND as the industry pushes toward 1,000 layers. Each end-market inflects independently.

---

## Outstanding Questions

1. **JEDEC HBM4E/HBM5 thickness standard** — Will the consortium finalize at ~825µm, ~900µm, or maintain ~775µm? Expected late 2026. This is the single highest-impact binary variable for near-term revenue trajectory
2. **SK Hynix Kinex qualification results** — Successful qual at the 53–60% HBM market share leader would trigger volume orders and likely pull Micron into the transition. Timeline: H2 2026
3. **Samsung Cheonan HCB line yields** — Currently ~10%. Any sustained improvement above 30% would validate the technology for production and trigger additional equipment orders
4. **M&A resolution** — Will Lam Research or Applied Materials proceed to a formal bid? What will the Dutch national security review determine? Talks reportedly ongoing despite U.S.-EU Greenland tensions
5. **Q1 2026 earnings (April 23)** — Guided for 5–15% revenue increase QoQ with 63–65% GM. Order momentum is the key metric — will the Q4 2025 surge (€250.4M, +105% YoY) sustain?
6. **Gen-2 50nm platform qualification breadth** — How many customers will qualify the Gen-2 system in 2026? Broader adoption validates the ASP uplift (~20% premium to ~$3.6M)
7. **BESI hybrid bonding revenue disclosure** — The company does not separately report hybrid bonding revenue. FT estimates €476M for 2026. Will management provide more granularity?
8. **ASMPT LITHOBOLT competitive progress** — Can ASMPT qualify at a second major customer and begin to compress BESI's D2W share from 67%?
9. **Dutch export controls** — Will the Netherlands extend ASML-style restrictions to advanced packaging equipment? China order momentum was significant in FY2025
10. **CPO/COUPE ramp and "hybrid of hybrid" architecture implications** — TSMC targets 2026 volume production for COUPE. When does BESI's die attach/bonding position translate to material silicon photonics revenue? And if the industry adopts face-to-face hybrid bonding between die pairs with microbumps between pairs, does this reduce or increase total hybrid bonding steps per stack?

---

## Business Model & Product Description

BESI's business model is the "ASML of advanced packaging" — a near-monopoly toolmaker for an inevitable semiconductor technology transition, earning outsized margins from capital equipment that becomes physically unavoidable as the industry moves to 3D integration. Like ASML in lithography, BESI's competitive position derives not from cost leadership but from being the only company that can deliver production-proven equipment at the precision levels customers require (~67% D2W market share, 150+ installed systems across 18 customers). Revenue is equipment-driven with system ASPs ranging from sub-€1M for standard die attach to €3.6M for Gen-2 hybrid bonding platforms — each generation commanding a ~20% premium over its predecessor. The installed base creates a compounding qualification moat: customers invest 12-24 months in process-of-record certification, making supplier switches prohibitively expensive. ~50% of FY2025 orders were AI-related.

BESI designs and manufactures semiconductor assembly equipment, with revenue concentrated in two primary product categories:

### Hybrid Bonding Systems (~67% D2W market share)

Die-to-wafer (D2W) hybrid bonding equipment that fuses copper pads to copper pads at the atomic level through a two-step process: dielectric surface bonding followed by metal thermocompression. This technology becomes physically unavoidable below ~10µm bump pitch, where solder-based interconnects fail due to bridging and non-wetting defects.

- **Gen-1 Platform** (~100nm alignment accuracy, ~€3M ASP): Production-proven systems installed at all major foundries and memory makers. 150+ systems across 18 customers including TSMC, Intel, Samsung, and SK Hynix.
- **Gen-2 Platform** (50nm accuracy, ~€3.6M ASP, ~20% premium): Shipped to a leading Taiwanese foundry in Q4 2025. Enables sub-5µm pitches required for HBM4E and advanced logic chiplet packaging.
- **Gen-3 Platform** (sub-25nm accuracy, in development): Targets higher throughput and tighter accuracy for next-generation packaging architectures.
- **Kinex Integrated Inline System** (co-developed with Applied Materials): The industry's first fully integrated D2W hybrid bonding platform, combining AMAT's surface preparation (CMP, plasma activation, dielectric deposition, metrology) with BESI's precision die bonding in a single inline flow. Solves the critical queue-time contamination problem — reducing atmospheric exposure from up to 13 hours to minutes. A single 1µm particle creates a bond void of 10mm diameter, making this inline integration essential for production yields.

**Application end-markets for hybrid bonding:**
- *HBM memory stacking*: Required for 16+ layer stacks where thermocompression bonding reaches physical limits. Samsung building dedicated HCB lines at Cheonan; SK Hynix ordered Kinex for mass-production development (March 2026).
- *Advanced logic chiplet packaging*: TSMC SoIC, Intel Foveros Direct — heterogeneous integration of multiple chiplets at sub-5µm pitches.
- *3D NAND beyond 300 layers*: Die-to-die and wafer-to-wafer connections for string-stacked architectures as the industry pushes toward 1,000 layers.
- *Silicon photonics / Co-Packaged Optics*: TSMC's COUPE process places electrical dies directly on photonic dies via hybrid bonding.

### Die Attach Equipment (~42% global market share)

Conventional die bonding systems for placing individual semiconductor dies onto substrates, lead frames, or other dies. Includes:

- **Thermocompression bonding systems**: Used for current-generation HBM production (HBM3E, early HBM4). Market share expanding as HBM4's tighter placement accuracy requirements push customers away from competitors like Hanmi (whose share at SK Hynix is projected to fall from majority to 20-30% by 2026).
- **Advanced die attach for silicon photonics**: ~75% market share in equipment used for TSMC's COUPE co-packaged optics process, which targets volume production in 2026.
- **Standard die attach**: Epoxy and eutectic die bonding for mainstream semiconductor packaging across automotive, industrial, and consumer applications.

~50% of FY2025 orders were AI-related. Manufacturing is concentrated in the Netherlands, with system ASPs ranging from sub-€1M for standard die attach to €3.6M for Gen-2 hybrid bonding platforms.

---

## Industry Context

### Hybrid Bonding Technology Landscape

Hybrid bonding eliminates solder-based interconnects entirely, directly fusing copper pads to copper pads at the atomic level through a two-step process: dielectric surface bonding followed by metal thermocompression. The technology becomes physically unavoidable below ~10µm bump pitch — the threshold at which solder bridging and non-wetting defects make conventional approaches unmanufacturable. HBM stacks beyond 16–20 layers, advanced logic chiplets at sub-5µm pitches, and 3D NAND beyond 300 layers all converge on this constraint.

The critical manufacturing challenges are formidable: copper pad surface roughness must be below 0.5nm, alignment accuracy for production D2W is ~100nm today (Gen-1) with Gen-2 targeting 50nm, and queue time between surface activation and bonding is critical — contamination at the bonding interface from even minutes of atmospheric exposure can destroy yields. Current production yields for hybrid bonding in HBM remain ~10%, well below the 70%+ needed for volume economics.

### Three-Vendor Bonding Philosophies

**Samsung — betting survival on hybrid bonding.** Samsung's aggressive HCB pivot is inseparable from its HBM market share collapse (41% → 17%). Samsung finally passed NVIDIA's 12-layer HBM3E qualification in ~September 2025, approximately 18 months after development completion. Initial HBM4 (12-layer, shipped February 2026) still uses TC-NCF, but dedicated HCB lines at Cheonan are being equipped with March 2026 delivery. Samsung's 1c DRAM yields were ~50% as of November 2025, compounding the hybrid bonding yield challenge. Samsung claims HCB reduces thermal resistance by >20% — a direct response to the thermal issues that cost it the NVIDIA contract. Samsung is planning a 50% HBM capacity surge in 2026 to ~250K wafers/month.

**SK Hynix — "Maximize MR-MUF for as long as possible."** SK Hynix has never used thermocompression bonding. Its proprietary Mass Reflow with Molded Underfill process delivers higher throughput, ~10% better thermal dissipation, and lower bump damage risk vs. TC-NCF. VP Lee Kang-seok confirmed HBM4 (up to 16-layer) will use Advanced MR-MUF, with hybrid bonding partially introduced for HBM4E 20-layer stacks and fully adopted at HBM5. **SK Hynix's March 2026 Kinex order is for logic-line/2nm primary use with dual-use HBM5 hybrid-bonding qualification path** (clarified via [[Research/2026-05-11 - HBM Packaging Equipment Stack - MR-MUF to Hybrid Bonding Transition - deep-dive]]) — confirms the transition has begun but at a slower architectural pace than a direct HBM-line order would have implied. The company projects ~70% of NVIDIA Vera Rubin HBM4 supply (vs ~30% Samsung, 0% Micron initial), giving it no incentive to rush a technology transition. JEDEC HBM4 height-spec relaxation 720→775→900µm extends the MR-MUF runway through HBM4E 16-Hi (2026-2027) and likely HBM5 first-gen 20-Hi (2028-2029) before hybrid bonding becomes architecturally mandatory at HBM5+ 24-Hi (2029-2030).

**Micron — pragmatic silence.** Micron uses TC-NCF and has licensed hybrid bonding IP from Adeia (180+ patents) but made no public production timeline commitment. Its HBM4 uses an in-house base die emphasizing 30% lower power efficiency. Micron broke ground on a $7B HBM advanced packaging facility in Singapore in 2025 (production 2027). Likely the last major vendor to adopt hybrid bonding, at HBM5 or later.

### Equipment Competitive Dynamics

| Competitor | Technology | Status (April 2026) | Threat Level |
|---|---|---|---|
| **ASMPT** | LITHOBOLT D2W hybrid bonder | First system to logic customer Q3 2024; planning Gen-2 for HBM | Medium — broadest portfolio rival, but 2–3 years behind in production qualification |
| **SUSS MicroTec** | XBC300 Gen2 D2W platform | Launched May 2025 | Low-Medium — unproven at scale |
| **Hanmi Semiconductor** | Investing 100B won in hybrid bonding factory | Targeting HBM bonder delivery by end-2027; TCB share at 71% but falling — ASMPT took ~100-unit TC-bonder order from SK Hynix Dec 2025 amid Hanmi-Hanwha patent dispute | Low — earliest delivery 18+ months away; share pressured on conventional TCB before hybrid bonding entry |
| **Samsung Semes** | In-house hybrid bonder development | Quality "lags behind BESI" per 36Kr April 2026 | Low — captive supplier, not competitive externally |
| **EVG (EV Group)** | GEMINI FB W2W platform; entering D2W via Co-D2W | >70% W2W market share; D2W approach less suited for heterogeneous integration | Low for D2W — different architectural approach |
| **Tokyo Electron** | Synapse platform, primarily W2W | Estimates bonder TAM at ~$670M (2025) → $2B (2030) | Low for D2W — focused on W2W |
| **CEA-Leti** | Self-assembly D2W process (research) | Lab-scale; ±200nm alignment via capillary forces | Negligible — R&D institute, not equipment vendor |

BESI's 42% die attach market share (2022) has expanded as HBM4's tighter placement accuracy requirements push customers away from Hanmi and toward BESI even in conventional bonding.

### The Applied Materials Strategic Partnership

Applied Materials acquired a 9% strategic stake in BESI in April 2025, culminating a five-year co-development effort. The resulting Kinex platform is the industry's first fully integrated die-to-wafer hybrid bonding system, combining AMAT's surface preparation (CMP, plasma activation, dielectric deposition, metrology) with BESI's precision die bonding in a single inline flow. This integration directly solves the queue-time contamination problem that plagues standalone tools — reducing exposure from up to 13 hours to minutes. The partnership creates a bundled ecosystem that competitors cannot easily replicate, as it requires both front-end process expertise (AMAT) and back-end bonding precision (BESI) working in a single integrated vacuum-to-ambient flow.

### Silicon Photonics & Co-Packaged Optics

TSMC's COUPE silicon photonics platform uses SoIC-X chip stacking to place an electrical die directly on a photonic die via hybrid bonding, enabling ultra-low impedance at the die-to-die interface. COUPE is targeting volume production in 2026. NVIDIA's Spectrum-X and Quantum-X800 platforms — the world's first 3D-stacked silicon photonics engines — incorporate this technology. BESI holds ~75% market share in the advanced die attach equipment used for COUPE. The CPO market is projected at 37% CAGR to $20B+ by 2036 (IDTechEx). Samsung is developing a competing CPO turnkey service targeting 2029. This represents a TAM entirely independent of memory — and one where BESI's position is already established.

### M&A Landscape

Reuters reported in March 2026 that BESI is fielding takeover interest from Lam Research and Applied Materials, with Morgan Stanley advising. BESI shares surged ~14% to a then-record €214. Discussions began mid-2025, paused during U.S.-EU Greenland tensions, and resumed recently with Lam reportedly maintaining active interest. Under Dutch law, any acquisition of strategic technology requires national security review — a process that could take 6–12 months and may include conditions or rejection. This regulatory shield paradoxically benefits BESI shareholders: it prevents hostile bids, gives management complete negotiating leverage, and ensures any successful acquisition would require a substantial premium to compensate for regulatory risk and timeline.

---

## Key Metrics

| Metric | Value | Notes |
|--------|-------|-------|
| Market Cap | ~€16.75B (~$16.7B) | Near all-time high |
| Share Price | ~€207.10 | April 13, 2026; 52-wk range €85.68–€214.00 |
| FY2025 Revenue | €591.3M | Down 2.7% YoY — cyclical trough |
| FY2025 Orders | €685M | +16.8% YoY — inflection signal |
| Q4 2025 Orders | €250.4M | +105.4% YoY — hybrid bonding driven |
| Q1 2026 Guidance | €175–191M rev | +5–15% QoQ; GM 63–65% |
| FY2025 Gross Margin | 63.3% | |
| Trailing P/E | ~127x | |
| Forward P/E (2026E) | ~66x | Based on ~€3.2 consensus EPS |
| Price/Sales (ttm) | ~28.5x | |
| D2W Market Share | ~67% | Dominant position |
| Hybrid Bonding Revenue | €36M (2023) → ~€476M (2026E) | FT estimate; not separately disclosed |
| Installed Hybrid Bonding Systems | 150+ | Across 18 customers |
| System ASP | ~€3M (Gen-1) / ~€3.6M (Gen-2) | Gen-2 at 50nm accuracy; ~20% premium |
| AI % of Orders | ~50% | FY2025 |
| UBS 2027E Revenue | €1.23B | EBIT margin 42.3% |
| BESI LT Targets | €1.5–1.9B rev | 40–55% op margins (2025 Investor Day) |
| Projected Hybrid Bonder Demand | 1,400 systems by 2030 | ~€2.8B equipment TAM |

---

## Bull Case

- ~~JEDEC maintains tight thickness standards (~775µm)~~ **Bull-pillar updated (2026-05-11): JEDEC has formally relaxed HBM4 to 900µm** ([[Research/2026-05-11 - HBM Packaging Equipment Stack - MR-MUF to Hybrid Bonding Transition - deep-dive]]); the front-loaded-by-thickness path is closed. Bull case now pivots to **HBM5+ 24-Hi architectural-mandate path**: hybrid bonding becomes physically required for HBM5+ 24-Hi (2029-2030), giving BESI a structural ~3-year runway of inflection demand (2027 logic-line ramp → 2028 HBM4E pilot → 2029-2030 HBM5+ volume) — the demand wave is delayed but unavoidable
- SK Hynix and Samsung both enter volume hybrid bonding production, creating a demand wave BESI's competitors cannot serve at scale due to 2–3 year qualification gap. **SK Hynix's March 2026 Kinex order for logic-line/2nm production is the first hybrid-bonding production-revenue line** — confirms BESI is in the SK Hynix Tier-1 equipment stack independent of HBM timing
- Lam Research or Applied Materials bids at 30–50% premium (~€220–250+), setting a hard floor; Dutch security review process ensures orderly negotiation favoring BESI shareholders
- Gen-2 50nm platform becomes the standard for sub-5µm logic packaging at TSMC, driving secular demand entirely independent of HBM timing
- CPO/silicon photonics TAM materializes post-2026 as TSMC COUPE enters volume production, with BESI capturing 75% of die attach equipment demand
- Revenue trajectory to €1.2B+ by 2027 compresses forward P/E to ~25–30x on 2027E — reasonable for a monopoly with 40–55% target operating margins
- 3D NAND beyond 300 layers creates additional hybrid bonding demand independent of HBM, broadening the TAM beyond current consensus estimates
- Micron's $7B Singapore facility (production 2027) represents a major greenfield equipment demand event

## Bear Case

- **Bear-pillar #1 partially actualized (2026-05-11): JEDEC has already relaxed HBM4 to 900µm** ([[Research/2026-05-11 - HBM Packaging Equipment Stack - MR-MUF to Hybrid Bonding Transition - deep-dive]]). Mass hybrid bonding adoption is delayed to HBM5+ 24-Hi (2029-2030), pushing BESI's HBM-driven revenue inflection out ~2 years vs prior expectations. Stock is exposed to 40x+ 2027E P/E re-rating risk if BESI cannot bridge the 2026-2028 gap with logic-line (TSMC SoIC-X, 2nm logic) + CPO/photonics revenue; if guidance for FY2026 fails to reflect logic-side substitution, multiple compression is the base case
- Competitors gain traction: ASMPT LITHOBOLT qualifies at a major memory customer, SUSS XBC300 Gen2 wins business, Samsung Semes closes the internal quality gap
- Extreme valuation (127x trailing P/E) leaves zero margin for timing disappointments — any guidance miss triggers severe multiple compression
- AI capex cycle decelerates, reducing urgency for HBM capacity expansion and advanced packaging equipment orders
- M&A falls through — Dutch security review blocks a deal or parties fail to agree on price, removing the takeover premium from the stock
- Hybrid bonding yields remain stuck near 10%, extending the pilot-to-production gap and frustrating customer adoption across all three memory vendors
- "Hybrid of hybrid" transitional architecture reduces total hybrid bonding steps per stack, lowering addressable system demand vs. pure hybrid bonding scenarios
- Dutch export controls extend to advanced packaging equipment, constraining China sales that contributed meaningfully to FY2025 order momentum

## Catalysts

- **Q1 2026 earnings** (April 23, 2026) — order momentum and hybrid bonding backlog commentary are the critical metrics
- **JEDEC HBM4E/HBM5 thickness standard finalization** (expected late 2026) — the single highest-impact binary event
- **SK Hynix Kinex qualification results** (H2 2026) — successful qual triggers volume orders from the dominant HBM producer
- **Samsung Cheonan HCB line yield milestone** — improvement above 30% would trigger additional equipment orders
- **M&A resolution** — formal bid from Lam Research or Applied Materials would crystallize significant premium
- **Gen-2 50nm platform customer qualification announcements** — validates ASP uplift and extends technology lead
- **First hybrid-bonded HBM4E stacks** — anticipated in 2026 per BESI's March investor presentation
- **Micron Singapore advanced packaging facility** (production 2027) — greenfield $7B investment requiring bonding equipment
- **TSMC COUPE volume production** (2026) — first material CPO/photonics equipment demand
- **Samsung and SK Hynix hybrid-bonded HBM3E samples submitted to NVIDIA for testing** (reported April 2026) — qualification cycle has begun regardless of JEDEC decisions

## Risks

1. **Timing risk (primary):** The entire acceleration case depends on when hybrid bonding transitions from pilot to volume production; JEDEC decisions could shift this by 1–2 years. The secular case is intact, but the valuation demands the revenue inflect soon
2. **Valuation risk:** 127x trailing P/E and 28.5x P/S are priced for near-perfect execution. Any timeline slippage triggers disproportionate multiple compression given the optionality premium embedded in the stock
3. **Competitive risk:** ASMPT, SUSS MicroTec, Hanmi, and Samsung Semes are all investing heavily; BESI's 67% D2W share could erode as the market scales and customers seek second-source options
4. **Customer concentration:** TSMC is likely the dominant revenue contributor; any slowdown in TSMC's advanced packaging capex disproportionately impacts BESI
5. **Yield risk:** Hybrid bonding at ~10% yield is pre-production quality; if fundamental yield barriers prove harder to solve, the entire transition timeline shifts
6. **Geopolitical/export control risk:** Dutch government may extend ASML-style restrictions to advanced packaging equipment, constraining China sales
7. **M&A uncertainty:** Takeover speculation inflates the stock; if no deal materializes, the premium unwinds and creates a valuation air pocket
8. **Cyclicality:** Semiconductor equipment is inherently cyclical; FY2025 revenue was already down 2.7% YoY despite the AI narrative

---

## Related Research

- [[Research/2026-04-10 - Hybrid Bonding and BESI Revenue Impact]] — Comprehensive hybrid bonding market analysis, vendor strategies, BESI financials, JEDEC dynamics
- [[Research/2025-11-01 - BESI - BESI Role in HBM Manufacturing]] — BESI's role in HBM hybrid bonding (note: source file contains ingestion artifacts)
- [[Research/2025-07-06 - BESI - Analyst Estimates and Valuation Trends]] — Grok export: analyst estimates, valuation context, competitive segment analysis, plating/die bonding technology overview
- [[Research/2025-11-26 - Semis - Gemini Silicon Photonics Canvas]] — BESI as Tier 3 enabler in silicon photonics supply chain; 75% die attach market share for COUPE
- [[Research/2025-11-27 - Semis - Gemini HBM4 Market Canvas]] — HBM4 technology trajectory, vendor bonding strategies, yield dynamics
- [[Research/2026-02-26 - Semis - Gemini Lam vs AMAT Canvas]] — AMAT/LRCX strategic analysis; AMAT's hybrid bonding partnership context
- [[Research/2025-11-01 - DRAM HBM Competitive Dynamics]] — Samsung/Micron/Hynix HBM competitive dynamics
- [[Research/2026-03-20 - Lam Research and Applied Materials Evaluation]] — Tier-1 WFE supplier outlook (Lam/AMAT context for M&A)
- [[Research/2026-03-10 - LITE - Gemini Photonics CPO Canvas]] — CPO market dynamics, TSMC COUPE architecture
- [[Research/2026-01-17 - Semis - Gemini AI Compute HBM Canvas]] — AI compute and HBM demand modeling
- [[Theses/SNDK - SanDisk]] — HBF uses TSV/advanced packaging; adjacent NAND thesis
- [[Theses/285A - Kioxia]] — Adjacent NAND thesis; BiCS die stacking technology
- [[Research/2026-04-15 - BESI - Hybrid Bonding Market Projections]] — HB market $1.47B→$5.6B (2030) at 25.1% CAGR, D2W positioning, Samsung/SK Hynix/Micron adoption timelines
- [[Sectors/Semiconductor Capital Equipment]] — Sector-level WFE thesis positions BESI as Tier 2 satellite (10% allocation); frames hybrid bonding debate as market distraction — equipment spend growing 40%+ regardless of hybrid bonding timeline via CoWoS expansion
- [[Sectors/Semiconductor Capital Equipment]] — Sector hub (absorbed prior `Theses/SEMICAP - Semiconductor Capital Equipment` thesis 2026-04-29; sector now serves dual role as MoC and basket-level investment hub)
- [[Research/2026-05-11 - HBM Packaging Equipment Stack - MR-MUF to Hybrid Bonding Transition - deep-dive]] — JEDEC HBM4 720→775→900µm relaxation (bear-pillar #1 partially actualized); Mar 2026 SK Hynix Kinex order = logic-line/2nm primary (dual-use HBM5 path); Vera Rubin HBM4 ~70/30/0 SK Hynix/Samsung/Micron initial; Hanmi 71% TCB falling, ASMPT taking ~100-unit Dec 2025 SK Hynix TC-bonder share; HB inflection now driven by HBM5+ 24-Hi architectural mandate (2029-2030) rather than HBM4 thickness-mandate
- [[Research/2026-05-24 - Semiconductor Portfolio Rebalancing - synthesis]] — Tier 2 WFE compounder; UPSIZE Low→4-5% (hybrid bonding monopoly; logic-line bridge + HBM5+ 24-Hi mandate; JEDEC relaxation delayed HBM ramp ~2yr)
- [[Research/2026-05-31 - CPO Scale-Up Inflection and Supply Chain - deep-dive]] — SemiAnalysis CPO deep-dive: TSMC SoIC die-to-wafer hybrid bond is the performance-critical CPO optical-engine bond (23× density vs bumps) — reinforces the hybrid-bonding secular theme, though the article credits TSMC-internal capability (indirect BESI read-through)
- [[Research/2026-05-31 - DRAM HBM Memory Supercycle - deep-dive]] — memory supercycle: HBM wafer capacity ~5x in 4 years (123→668 kwspm) + back-end TC-bonder intensity supports HBM packaging / hybrid-bonding demand

## Log

### 2026-04-19 (TSM stress test sync)
- [[Research/2026-04-19 - TSM - Stress Test]]: TSM Kaohsiung/Chunan CoWoS under invasion/destruction scenario = 100% loss of BESI's TSMC advanced-packaging equipment pipeline (HBM4 hybrid bonding + SoIC lines). Partial offset via Arizona/Japan/Germany rebuild demand but 5-7yr EUV replication lag and ASML 60-unit/yr global output constraint cap near-term substitution — indirect Taiwan exposure materially higher than sector consensus; conviction unchanged.

### 2026-04-15 (cross-thesis sync)
- [SEMICAP thesis]: Advanced packaging equipment spend growing 40%+ regardless of hybrid bonding timing (CoWoS 35K→130K wafers/month). HB transition to HBM4E/HBM5 is additive upside — conviction strengthened, supports multi-end-market demand thesis.

### 2026-04-15
- [Template restructure + research sync]: Repositioned Business Model section. Linked HB market projections ($1.47B→$5.6B by 2030). Conviction unchanged.

### 2026-04-14
- [Major restructure]: Consolidated ChatGPT/Claude/Grok/Gemini sources. Added Hanmi share erosion, Gen-3 development, 3D NAND demand vectors. Web confirmed stock near ATH €207. Upgraded draft → active — conviction medium on timing uncertainty and extreme valuation.

### 2026-04-14 (initial)
- [Thesis created]: Built from 3 research notes + web search. Core thesis: 3D integration monopoly mispriced as HBM timing bet. Conviction medium.

### 2026-04-22
- Sector re-scoped: Semiconductors → Semiconductor Capital Equipment (vault-wide subsector taxonomy reorganization).

### 2026-04-22 (Wikilink cleanup)
- Wikilink cleanup: Replaced stale `[[Sectors/Semiconductors]]` parent reference with `[[Sectors/Semiconductor Capital Equipment]]` in Related Research; parent sector note retired during vault reorganisation. Thesis body unchanged; conviction unchanged.

### 2026-05-11 (/sync)
- [[Research/2026-05-11 - HBM Packaging Equipment Stack - MR-MUF to Hybrid Bonding Transition - deep-dive]]: JEDEC HBM4 720→775→900µm relaxation actualizes Bear pillar #1 (HBM-driven inflection delayed 2 years); demand pivot to HBM5+ 24-Hi architectural-mandate path (2029-2030) + logic-line (TSMC SoIC-X, SK Hynix Mar 2026 Kinex for 2nm logic) preserves multi-year revenue trajectory. Bull pillar #1 rewritten — front-loaded-by-thickness path closed, replaced by architecture-mandate path. Industry Context updated: SK Hynix Kinex order reclassified as logic-line primary (dual-use HBM), Vera Rubin ~70/30/0 confirmed, Hanmi-ASMPT TC-bonder share dynamic added. Conviction directionally weakened on 2026-2028 HBM revenue ramp velocity; unchanged on 2030 hybrid-bonding TAM materialization.

### 2026-05-12 (/sync)
- [[Research/2026-05-11 - INTC - Institutional Equity Research - deep-dive]]: Intel **Foveros Direct (hybrid bonding) is BESI-tooled** and Intel deployed it earlier than TSMC at Meteor Lake (first high-volume hybrid-bonded client product) — Intel is a confirmed customer in BESI's 18-customer / 150+-system hybrid-bonding installed base. Foveros + EMIB capacity scaling +150% / +30% in New Mexico through 2027 plus EMIB-T H2 2026 (120×180mm 24-HBM-stack) and 18A-PT 2028 timeline implies sustained Intel tooling pull through 2027–2028. Adds an Intel-specific logic-line demand vector independent of the SK Hynix HBM5+ 24-Hi architectural-mandate path. Conviction unchanged — confirms multi-customer logic-line breadth (TSMC SoIC-X + SK Hynix Kinex + Intel Foveros) underwriting BESI's 2026–2028 revenue trajectory across both HBM and logic.

### 2026-05-19 (/sync)
- Cross-thesis propagation from [[Macro & Technology/800VDC Adoption]]: Macro note covers 800VDC rack-architecture transition + new quant-screening framework (AI-DC Rev/OP %, ROIC/EV-EBIT) across ~50 value-chain beneficiaries. BESI listed under §Adjacent exposure in the macro: hybrid-bonders for advanced packaging (CoWoS, 3D stacking) increasingly demanded at Rubin/Rubin Ultra power densities — power-delivery requirements drive new packaging tools as on-die voltage-regulation integration becomes architecturally tighter. The macro's bottleneck-cascade analysis (§Framework / Mental Model) puts wide-bandgap silicon + on-board VPD at Layers 4-5; BESI's hybrid-bonding tooling is the upstream enabler for the densest power-delivery architectures (Vicor Power-on-Package geometry requires ChiP-style fabrication that BESI's bonders enable at scale). Conviction unchanged at medium — adds a power-density tail vector to the existing multi-customer logic-line + HBM5+ architectural-mandate framework.

### 2026-05-22 (manual)
- Status change: portfolio-wide alignment — confirmed as current Live Portfolio holding; conviction medium→high.

### 2026-05-26
- [[Research/2026-05-24 - Semiconductor Portfolio Rebalancing - synthesis]]: Rebalancing flags UPSIZE to 4-5% (hybrid bonding monopoly intact; HBM ramp velocity revised down post-JEDEC, HBM5+ mandate path locked) — conviction unchanged (high); sizing call.

### 2026-05-31 (/sync)
- [[Research/2026-05-31 - CPO Scale-Up Inflection and Supply Chain - deep-dive]]: TSMC SoIC die-to-wafer hybrid bond is the performance-critical CPO OE bond (23× density vs bumps) — reinforces the secular hybrid-bonding theme, but the article credits TSMC's *internal* capability rather than merchant tool vendors, so the CPO read-through is indirect. Conviction unchanged (high).

### 2026-06-01 (/sync)
- [[Research/2026-05-31 - DRAM HBM Memory Supercycle - deep-dive]]: HBM wafer capacity ~5x in 4 years (123→331→668 kwspm) + rising back-end (TC-bonder) intensity supports HBM packaging/hybrid-bonding demand; conviction unchanged (high).
