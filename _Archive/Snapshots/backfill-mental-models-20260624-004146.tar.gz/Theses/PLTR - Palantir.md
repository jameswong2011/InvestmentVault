---
date: 2026-04-15
tags: [thesis, enterprise-software, AI, defense, PLTR]
status: active
ticker: PLTR
conviction: high
sector: Enterprise Workflow AI & Automation
source: Consolidated from Gemini Canvas (2), ChatGPT (2), Claude (4), Grok (1) research conversations + web research April 2026
---

# PLTR — Palantir Technologies

## Summary

Q4 2025: $1.41B revenue (+70% YoY), U.S. commercial +137%, Rule of 40 at 127%. FY2026 guided $7.19B (+61%) with $4.0B adjusted FCF. Palantir's Ontology architecture — a semantic intelligence layer with governed write-back to operational systems of record — is the critical differentiator. Unlike Databricks/Snowflake (analytical read-path) or ServiceNow (workflow automation), Palantir built the operational write-path first and added the data platform underneath, creating structural advantages in complex, regulated, mission-critical environments. The central tension remains valuation: even after a ~35%+ correction from the $207.52 ATH, multiples remain extreme. Forward PEG (~1.0-1.5) is cheaper than Snowflake (3.3x), and the defense revenue floor ($1.2B+ annually, anchored by $10B Army Enterprise Agreement and $1.275B Maven ceiling) provides downside protection pure-play commercial AI companies lack.

---

## Key Non-consensus Insights

- **The Ontology is an operational control plane with write-back capability, not a data analytics tool — and the market still partially prices Palantir as a data analytics company.** An Ontology Action atomically updates objects, writes back to source ERPs (SAP, Oracle), and logs the full decision chain with ACID guarantees and cascading updates. Databricks and Snowflake are architected for OLAP reads and bulk writes — fundamentally different workloads. Databricks' Neon acquisition (Lakebase) reveals it understands this gap but solves at the infrastructure layer rather than the semantic layer, representing a 2-3 year product development gap. Building down from the application layer (Palantir's approach) is architecturally easier than building up from the data platform.

- **The "Context Gap" — not model selection — is the real bottleneck for enterprise AI adoption, and Palantir's Ontology-Augmented Generation (OAG) is architecturally LLM-native in a way no competitor's data model is.** OAG goes beyond RAG by giving LLMs access to deterministic logic tools, structured queries over interconnected business objects, and governed write-back actions — all under the same security policies governing human users. Semantic object types with typed properties and named links map naturally to how language models reason, unlike ServiceNow's procedural GlideRecord patterns that require additional abstraction layers. AI outputs grounded in structured, relationship-aware enterprise data substantially reduce hallucination risk vs flat document retrieval.

- **Palantir and ServiceNow are complementary layers of the enterprise AI stack, not competitors — but the market still prices them as substitutes, understating both companies' addressable markets.** ServiceNow's CMDB maps hierarchical service dependencies for closed-loop IT/HR/security automation; Palantir's Ontology maps dynamic semantic relationships across arbitrary entities for cross-domain reasoning and governed action execution. An AI agent reasoning about incident impact needs a service dependency graph (ServiceNow); an AI agent reasoning about supply chain disruption needs to cross-reference manufacturing defects with supplier contracts with warranty claims across siloed domains (Palantir). Complementary positioning effectively doubles the addressable market relative to a competitive framing.

- **The 5-day AIP bootcamp model is a structural distribution disruption that inverts enterprise software economics — and the market hasn't fully modeled its implications for long-term unit economics.** ~75% conversion rate in 5 days vs traditional 6-18 month sales cycles; documented wins include $26M ACV in five weeks and $19M bank expansion in four months. Walgreens deployed to 4,000 stores in 8 months. Net revenue retention 139%; U.S. commercial RDV up 145% YoY to $4.38B. Professional services declined from ~25% of revenue (2021) to ~18-20% (2025), with AI-powered FDE agent further reducing human dependency. Still early at 954 customers vs Databricks' 20,000+, but the pipeline is compounding.

- **DOGE and Pentagon budget scrutiny are paradoxically bullish for Palantir — the market prices federal spending cuts as a headwind, but budget rationalization systematically benefits AI-native platforms and destroys legacy contractors.** Administration directed 8% annual cuts (~$50B) across Pentagon programs but simultaneously requested a record $1.5T defense budget for 2027. $10B Army Enterprise Agreement consolidated 75 legacy contracts into a single Palantir integration; ShipOS demonstrated 160 manual hours to 10 minutes for submarine schedule planning. Warp Speed (L3Harris, GE Aerospace, Boeing), ShipOS ($448M Navy), NOS (Nuclear OS), and $1.275B Maven ceiling create long-duration revenue decoupled from commercial SaaS cycles. NVIDIA Sovereign AI OS Reference Architecture (March 2026) addresses air-gapped AI needs hyperscalers structurally cannot serve.

## Outstanding Questions

- **At what growth deceleration rate does the current multiple compress faster than earnings grow, creating a negative return even with continued strong execution?** Palantir's trailing P/E of ~130-240x (depending on recent price) embeds expectations of sustained 50%+ revenue growth for multiple years. Historical precedent for high-growth software companies shows that the transition from 60% growth to 40% growth typically triggers 30-50% multiple compression. The FY2026 guide of 61% growth implies deceleration from Q4's 70% — is this the beginning of a normalization curve that takes growth to 30-40% by FY2027, and if so, what's the appropriate steady-state multiple? The forward PEG of ~1.0-1.5 is reasonable for current growth, but PEG breaks down when growth decelerates because the denominator shrinks faster than the numerator adjusts.

- **How exposed is Palantir's $1.2B government revenue base to DOGE-driven budget rationalization and shifting political priorities?** The $10B Army Enterprise Agreement and $1.275B Maven ceiling provide contractual anchoring, but shared-savings contract structures (like ShipOS) mean revenue realization depends on demonstrated impact metrics. If the 2027 defense budget request of $1.5T faces Congressional opposition or sequestration risk, what's the impact on new contract velocity vs. existing backlog? Palantir's explicit endorsement of budget scrutiny ("tear up our contracts if they don't deliver value") is strategically astute but untested — what happens when specific programs face actual cuts?

- **Can Palantir solve the international commercial stall that saw revenue decline 10% YoY in Q1 2025?** U.S. commercial is the growth engine (+137% YoY), but international commercial underperformance suggests the bootcamp model and FDE-intensive go-to-market may face structural friction in non-U.S. markets (regulatory complexity, data sovereignty concerns, cultural resistance to American defense-adjacent software). The NVIDIA Sovereign AI partnership addresses the sovereignty concern for government buyers, but commercial expansion in Europe and Asia requires a different playbook. Is international commercial a "fix it later" problem or a structural ceiling on the total addressable market?

- **Does Palantir's 954-customer base vs. Databricks' 20,000+ reflect early innings or a structural distribution ceiling imposed by the FDE-intensive model?** Former CFO Colin Anderson acknowledged the FDE model "is only financially sustainable for seven-figure contracts and above." This creates a natural mid-market exclusion zone. The AI FDE agent (natural language Foundry operation) and OSDK (developer self-service) are designed to lower this threshold, but the question is whether the platform complexity inherent in semantic ontology modeling can ever be reduced enough to serve the long tail of enterprises that Databricks/Snowflake/ServiceNow capture. If the answer is no, Palantir's TAM may be structurally smaller than the market assumes — hundreds of billions in defense and complex industrial operations, but not the trillions implied by "enterprise AI OS" positioning.

- **How real is the LLM commoditization threat to the Ontology's value as an orchestration layer?** Open-source models (Llama, Nemotron) now achieve 90%+ of frontier model performance at 84% lower cost. If these models become powerful enough to handle complex, multi-step reasoning without a dedicated ontology — if a sufficiently large context window and a well-constructed prompt can substitute for a structured semantic layer — Palantir's architectural moat narrows. The current evidence suggests the application of the model to messy, real-world data remains a much harder problem than building the model itself, but this assumption requires continuous monitoring. The deeper risk is not that open-source models replicate the Ontology, but that "good enough" semantic layers from Databricks, Microsoft Fabric IQ, or emerging open-source agent frameworks satisfy 80% of enterprise use cases at a fraction of Palantir's cost.

- **Microsoft Fabric IQ directly copies the Ontology concept and was announced in November 2025 — what is the realistic timeline before it becomes production-ready and commoditizes the simpler end of Palantir's commercial market?** Fabric IQ is years from production maturity, but Microsoft's distribution advantage (ubiquitous enterprise relationships, bundled pricing, developer ecosystem) means even a "good enough" semantic layer embedded in the M365/Azure stack could intercept Palantir's commercial land-and-expand at the mid-market tier. Every seam between Microsoft products (SQL Server, Cosmos DB, Dataverse, Power Automate, Fabric IQ) is a place where consistency guarantees break, audit trails fragment, and latency accumulates — but enterprises embedded in the Microsoft ecosystem may accept this friction for the simplicity of a single vendor. This is the "good enough" risk in its most potent form.

- **What does the persistent insider selling pace (~$6M/day in early 2026) signal about management's private assessment of valuation?** Almost all sales occur under pre-scheduled Rule 10b5-1 plans, which structurally reduces the information content of each transaction. But the aggregate pace — $6M daily despite record revenue and earnings — creates persistent technical supply pressure. Institutional accumulation is partly offsetting this (JP Morgan +183%, Vanguard +4%, BlackRock +5%), but the insider/institutional divergence warrants monitoring. The question is whether this represents rational diversification by founders with concentrated positions or a subtle signal about growth sustainability at current multiples.

- **How severe is the customer concentration risk from the top-20 customers generating $94M average revenue each?** At ~$4.5B total FY2025 revenue, the top-20 contribute roughly $1.9B or ~42% of total revenue. A single customer loss at this tier would represent a ~$94M revenue hit (~2% of total), but the guidance revision and market reaction would be disproportionate. The bootcamp-driven expansion of the customer base (954 total, +34% YoY) is the structural remedy, but the ratio of top-20 revenue to total revenue is the metric to watch — diversification requires the tail to grow faster than the head, which hasn't been definitively demonstrated yet.

## Business Model & Product Description

### The Conceptual Architecture: Nervous System, Not Brain

The simplest analogy for Palantir's business is that it is the enterprise nervous system — the connective tissue between the AI brain (LLMs, which any company can access) and the enterprise body (operational systems like ERPs, industrial controls, logistics networks, and weapons systems). Databricks and Snowflake are the skeletal system — they store and organize data. ServiceNow is the circulatory system — it delivers workflow oxygen to every department. But neither the skeleton nor the circulatory system can sense, decide, and act in real-time across the whole organism. That is the nervous system's job, and it is what Palantir's Ontology provides.

This distinction matters commercially because it means Palantir is complementary to — not competitive with — the major enterprise platforms. Palantir runs on top of Snowflake, Databricks, AWS, Azure, and GCP data stores. It integrates with ServiceNow, SAP, and Oracle workflows. It deploys on NVIDIA infrastructure. It is model-agnostic, supporting GPT, Claude, Gemini, Llama, and Nemotron. The Ontology is the semantic layer that makes all of these components work together for operational decision-making.

### Product Architecture

Palantir's product stack operates in five layers:

**1. Foundry** — The data integration and transformation platform. Foundry ingests data from any source (ERPs, sensors, databases, documents, APIs), transforms it through configurable pipelines (batch or streaming), and stores it in an immutable, versioned data layer (Parquet/Iceberg). Foundry is the "data operating system" — it handles the messy, unglamorous work of cleaning, joining, and governing enterprise data. The Pipeline Builder supports incremental execution to prevent expensive full-dataset reprocessing.

**2. Ontology** — The semantic intelligence layer. The Ontology sits atop Foundry datasets and translates raw data into business-meaningful objects (a Transformer, an Aircraft, a Patient, a Shipment) with typed properties and named relationships. Objects are connected through dynamic semantic links, not hierarchical dependencies, enabling complex cross-domain reasoning. The Ontology uses a Multimodal Data Plane (MMDP) to coordinate read and write operations across heterogeneous infrastructure without requiring massive data replication. OSv2 supports indexing tens of billions of objects per type.

**3. AIP (Artificial Intelligence Platform)** — The AI application layer. AIP provides the tools for building, deploying, and governing AI agents on top of the Ontology. Key components include:
- **AIP Logic**: No-code LLM-powered function builder using Ontology objects as inputs
- **AIP Agent Studio**: Build conversational AI agents powered by any major LLM combined with Ontology context, document context, and custom function-backed context
- **AIP Evals**: Integrated framework for testing agent performance across models and scenarios
- **AIP Document Intelligence**: Advanced chunking and embedding strategies for RAG workflows, using vision-language models and Markdown-optimized chunking for unstructured documents (PDFs, emails, spreadsheets)
- **AI FDE**: Natural language interface for Foundry, converting conversational intent into data transformations, code repository management, and ontology building — effectively an AI-powered Forward Deployed Engineer

**4. Apollo** — The autonomous deployment layer. Apollo allows Palantir software to run in any environment — public cloud, private cloud, air-gapped, classified, or edge — with average patch time of 3.5 minutes. This is the key enabler for defense and sovereign AI deployments where cloud connectivity is either impossible or prohibited.

**5. Rubix** — A hardened, zero-trust Kubernetes substrate for managing compute resources in on-premises deployments. Combined with Apollo, Rubix enables the turnkey AI datacenter architecture that underpins the NVIDIA Sovereign AI OS Reference Architecture.

### Revenue Segmentation

Palantir's revenue divides into four segments with dramatically different growth trajectories:

| Segment | Q4 2025 | YoY Growth | FY2026 Guidance | Character |
|---------|---------|------------|-----------------|-----------|
| **U.S. Commercial** | $507M | +137% | >$3.14B (>115%) | Hypergrowth engine; AIP bootcamp-driven |
| **U.S. Government** | $570M | +66% | Not disclosed | Structural floor; Army EA + Maven + ShipOS |
| **International Commercial** | Est. ~$150M | Stalled/declining | Not disclosed | Key concern; growth friction outside U.S. |
| **International Government** | Est. ~$180M | Moderate | Not disclosed | NATO Maven + sovereign AI expanding |

The U.S. business surpassed $1B for the first time in Q4, growing 93% YoY and 22% sequentially. The asymmetry between U.S. commercial hypergrowth and international commercial stagnation is the most important segmental dynamic to monitor.

A novel way to segment the revenue is by contract durability:

- **Structural floor (~35-40%)**: Long-duration government contracts with multi-year or decade-scale terms — $10B Army Enterprise Agreement, $1.275B Maven ceiling, $448M ShipOS, £240.6M UK MoD (sole-source). These are quasi-annuity revenue streams with near-zero churn risk and expansion built into contract ceilings.
- **High-growth engine (~40-45%)**: AIP bootcamp-driven commercial revenue with 75% conversion, 139% NRR, and $4.38B RDV pipeline. This is where growth comes from, but also where volatility lives.
- **Strategic investments (~15-20%)**: Vertical-specific deployments (Warp Speed manufacturing, NOS nuclear, Mortgage OS financial services) and international expansion efforts. These are lower-revenue but high-optionality bets that could become the next growth engine.

### Go-to-Market Model

Palantir's go-to-market operates through three channels:

**AIP Bootcamps**: 5-day intensive workshops where customers build production-grade AI use cases on their own data. ~75% conversion rate. Over 1,300 completed by late 2024 and continuing to scale. This is the primary commercial growth driver and the mechanism that compressed sales cycles from months to days.

**Forward Deployed Engineers (FDEs)**: Full-stack software engineers embedded in customer environments who build production systems, identify patterns, and feed abstractions back into the platform. FDEs are best understood as a distribution strategy disguised as services — they create operational lock-in and drive NRR of 139%. The model is "only financially sustainable for seven-figure contracts and above" (former CFO Colin Anderson), which creates a natural mid-market exclusion zone that limits customer count but maximizes revenue per customer.

**OSDK (Ontology Software Development Kit)**: Auto-generated TypeScript, Python, and Java bindings that enable developers to build applications directly on top of the Ontology. This is the self-service channel designed to reduce FDE dependency and enable platform adoption beyond the bootcamp-converted customer base.

### Revenue Model

Revenue is primarily software subscriptions with a declining professional services component (from ~25% of revenue in 2021 to ~18-20% in 2025). The subscription model includes annual escalators and is increasingly consumption-based for AIP workloads. The joint venture strategy (Syndicate 2479 in re-insurance, Aither in software development, TWG Global, Knox in IT consulting) allows Palantir to embed its software in new industries while sharing operational risk with domain experts — an asset-light expansion model that complements the FDE-intensive direct sales approach.

## Industry Context

### The Enterprise AI Platform Landscape: A Three-Front War

> [!question] 2026-04-27 → Addressed 2026-04-27
> **Prompt:** *Why are competitors unable to clone Palantir's technology especially its ontology and writeback functionalities. Is this due to patent protection? If so, whats the duration.*
>
> **Response:** Patent protection is the weakest layer of the moat — Palantir's foundational Foundry/Ontology architecture patents (filed circa 2010-2015) carry a 20-year statutory term and expire 2030-2035, but software patents have narrow claims that competitors routinely engineer around. The real replication barriers are structural: architectural inversion (top-down vs bottom-up build), MMDP atomic write-back across heterogeneous source systems, the customer-flywheel ontology library, security certifications (DoD IL6, FedRAMP High, Apollo air-gapped deployment), and FDE talent — none patent-dependent, all compound with every deployment. See §Industry Context → Why the Ontology Resists Replication for full analysis.

Palantir is fighting a competitive war on three distinct fronts, each with different dynamics and different competitive advantages:

**Front 1: The "Build Your Own" Threat (Databricks, Snowflake).** Data platform giants argue that enterprises should build their own AI stacks on top of open data infrastructure rather than buying Palantir's integrated platform. Databricks — at $5.4B+ annualized revenue, 20,000+ customers, and a $134B private valuation growing >65% YoY — is the most credible threat to Palantir's commercial enterprise ambitions. Databricks is aggressively moving up-stack toward operational AI with Unity Catalog (governance), Lakebase (transactional backbone), Agent Bricks (AI agents), and Genie (natural language data access). However, the write-back gap remains structural: Lakebase gives AI agents a place to persist state and execute fast writes, but it is a Postgres instance with no awareness of business objects, relationships, or domain rules. The bridge from "fast transactional database" to "governed semantic action layer" is where Palantir's 2-3 year product development lead sits. The Databricks-Palantir partnership (100+ joint customers within seven months of announcement) signals the market is already moving toward a "best of both" model: open data layer + proprietary operational/semantic layer. Snowflake's landmark 2025 partnership allowing AIP to run natively on Snowflake's Data Cloud reinforces this — Snowflake provides the "fuel" (data), Palantir provides the "engine" (intelligence).

**Front 2: The Ecosystem Play (Microsoft, AWS, Google).** Hyperscalers use their ubiquity to offer "good enough" analytics that come practically free with existing cloud contracts. Microsoft's Fabric IQ, announced November 2025, directly copies the Ontology concept but is years from production maturity. Wiring a Fabric IQ ontology entity to a Power Automate flow that validates business rules and writes back to Dynamics 365 is technically possible today — but it is a multi-product integration exercise, not a single-platform atomic operation. Every seam between products is a place where consistency guarantees break. Microsoft's distribution advantage (M365/Azure relationships across most enterprises) means even a "good enough" semantic layer could intercept Palantir's mid-market expansion. AWS and Google compete less directly — their AI offerings (Bedrock, Vertex) focus on model serving and inference rather than operational decision-making. The key risk is not that Microsoft builds a perfect Ontology replica — they won't need to. The risk is that "good enough" satisfies 80% of use cases at a fraction of Palantir's cost.

**Front 3: The Defense/Government Moat (No viable competitor at scale).** In classified, air-gapped, and sovereign environments, Palantir has no peer. The company holds DoD Impact Level 6 provisional authorization (one of only six cloud providers), FedRAMP High baseline, CMMC Level 2 certification, and the ability to deploy in fully air-gapped environments through Apollo. The $10B Army Enterprise Agreement consolidates 75 existing contracts. Maven Smart System ($1.275B ceiling) has 20,000+ active users across 35+ military entities in three security domains. TITAN — where Palantir is the first software company to serve as primary contractor on a major hardware program — delivered its first two prototypes on time and on budget. NATO adopted Maven in "one of the most expeditious" acquisitions in its history. The UK MoD awarded £240.6M without competitive tender. These certifications and operational dependencies took 20+ years and hundreds of millions of dollars to build. In classified environments, switching providers is virtually impossible due to security certification requirements, training dependencies, and operational continuity needs.

### Why the Ontology Resists Replication: Structural Moats vs. Patent Protection

Patent protection is the weakest layer of the moat. Palantir holds an extensive patent portfolio covering specific implementations of Foundry, Ontology, and AIP, but software patents have narrow claims that competitors routinely engineer around — the foundational architecture patents (filed circa 2010-2015) carry a 20-year statutory term and expire 2030-2035, by which time the structural barriers below will have compounded enough that legal protection is irrelevant to thesis-relevant horizons. The replication barriers are architectural and operational, not legal:

**1. Architectural inversion.** Palantir built top-down — operational decision-making first (intelligence, counter-terrorism, and fraud-detection workflows from 2003 onward), then the data infrastructure underneath. Competitors built bottom-up: Databricks started with Apache Spark (data engineering), Snowflake with cloud data warehouse (analytical reads), ServiceNow with ITSM workflows (procedural automation). Inverting the stack requires rebuilding foundational layers, not bolting capabilities on top. Databricks' Lakebase (Postgres for transactional state) and Unity Catalog (governance metadata) are credible bottom-up attempts but represent a 2-3 year product gap precisely because they add operational capabilities onto an analytical core rather than rebuilding from the operational layer outward.

**2. Multimodal Data Plane (MMDP) and atomic write-back.** An Ontology Action atomically updates objects, writes back to source systems of record (SAP, Oracle, custom ERPs), and logs the decision chain — with ACID guarantees across heterogeneous infrastructure. Each source system has different APIs, consistency models, and failure semantics; achieving atomic, governed write-back requires custom integrations with hundreds of source systems, a distributed rules engine that reconciles business logic across them, and two-phase commit-style coordination across systems that don't natively support it. Databricks' Lakebase gives agents a place to persist state, but it remains a Postgres instance with no semantic awareness of business objects or cross-system rules — the bridge from "fast transactional database" to "governed semantic action layer" is not a patentable feature, it is a decade of distributed-systems engineering.

**3. Customer-data flywheel and ontology library.** 20+ years of FDE deployments in classified, manufacturing, healthcare, and financial-services environments produced an institutional library of pre-built object types and relationships — defense logistics ontologies, pharmaceutical supply chain ontologies, naval shipyard ontologies, fraud-detection ontologies. Competitors don't have these. Even if Microsoft Fabric IQ achieves technical parity with the Ontology architecture, it lacks the domain-specific semantic models that took thousands of FDE-years to build. This is the moat that widens with every customer deployment and is impossible to replicate via legal IP — domain knowledge embedded in production ontologies is trade secret, not patent.

**4. Security certifications and air-gapped deployment.** DoD Impact Level 6 provisional authorization (one of six cloud providers), FedRAMP High baseline, CMMC Level 2, and the Apollo deployment system enabling air-gapped execution with 3.5-minute average patch times. These certifications take 5-10 years and tens of millions of dollars to obtain — they are not patent-protected but are practically replication-proof on relevant timescales. Databricks holds none, Snowflake holds none, Microsoft has Azure Government but nothing comparable to Apollo's edge/classified deployment capability. A competitor starting the IL6 process today would not reach parity until 2032+.

**5. FDE talent and engineering culture.** The Forward Deployed Engineer model — full-stack engineers embedded in customer environments who build production systems and feed abstractions back to the platform — has been refined over two decades. The talent pool that can do this work is small, and Palantir has trained the largest cohort. Competitors hiring senior FDEs face non-competes, and inheriting individual engineers does not transfer the institutional patterns (project structuring, abstraction harvesting, ontology design heuristics) that make the model financially viable at $1M+ ACVs.

**Patent duration is not the binding constraint.** The relevant question is not when Palantir's 2010-2015 architecture patents expire, but whether the structural moats degrade faster than competitor execution closes the gap. The Databricks-Palantir partnership (100+ joint customers within seven months of announcement) and the Snowflake native AIP integration suggest the market is converging on a "best of both" model — open data layer + proprietary semantic/operational layer — which preserves Palantir's competitive positioning even as the build-your-own narrative loses steam. The moats to monitor are not legal but operational: erosion in NRR (139% currently), customer count growth versus Databricks (954 vs 20,000+), and any successful Microsoft Fabric IQ commercial wins at the mid-market tier.

### Value Chain Positioning

The enterprise AI value chain can be decomposed into four layers:

| Layer | Function | Key Players | Palantir's Position |
|-------|----------|-------------|---------------------|
| **Infrastructure** | Compute, storage, networking | NVIDIA, AWS, Azure, GCP | Consumer (runs on all); NVIDIA partnership for sovereign |
| **Data Platform** | Data storage, transformation, governance | Databricks, Snowflake, Microsoft Fabric | Sits atop all; Foundry integrates via MMDP |
| **Semantic/Intelligence** | Object modeling, AI reasoning, decision logic | **Palantir (Ontology + AIP)** | **Core competitive position** |
| **Workflow/Action** | Process automation, task management | ServiceNow, Salesforce | Complementary; Ontology feeds into workflow systems |

Palantir occupies the semantic/intelligence layer — the layer that translates raw data into business-meaningful context and enables AI-driven decisions that write back to operational systems. This is the highest-value layer because it is where data becomes actionable intelligence, and it is the layer with the fewest credible competitors. The key architectural moat is that Palantir built its platform from the top down (starting with operational decision-making and adding data infrastructure underneath), while every competitor is building from the bottom up (starting with data platforms and trying to add operational capabilities on top).

### Competitive Differentiation by Dimension

| Capability | Palantir | Databricks | Microsoft Fabric IQ | ServiceNow |
|-----------|----------|------------|---------------------|------------|
| Semantic object modeling | **Native (Ontology)** | Unity Catalog (metadata) | Preview (announced Nov 2025) | CMDB (hierarchical CIs) |
| Write-back to operational systems | **Full (Actions → ERP/SAP)** | Lakebase (Postgres, no semantic awareness) | Multi-product integration | RaptorDB (transactional ITSM) |
| AI agent orchestration | **AIP Agent Studio + Evals** | Agent Bricks | Copilot agents (early) | Now Assist + AI Agent Fabric |
| Classified/air-gapped deployment | **Apollo + Rubix (IL6, FedRAMP)** | None | Azure Gov (limited) | Cloud-only (excluded) |
| Scale (objects/entities) | **Tens of billions per type** | Petabytes of data (different metric) | Large (unclear semantic scale) | 1-7M CIs (degrades >2.3M) |
| Customer base | 954 | 20,000+ | Millions (M365) | 8,200+ (85% of Fortune 500) |
| Go-to-market model | Bootcamps + FDEs | Self-service + partners | Bundled with M365/Azure | Multi-year roadmaps + partners |
| Token efficiency for LLMs | **High (typed objects, named links)** | Moderate (tabular, schema-on-read) | Unknown | Low (GlideRecord → SELECT *) |

### Key Market Dynamics

The enterprise AI market is evolving toward **multi-vendor strategies** rather than single-platform dominance. Organizations are adopting Palantir for core intelligence work (complex, cross-domain, regulated), Databricks or Snowflake for general analytics and data engineering, ServiceNow for workflow automation and IT operations, and Microsoft for productivity and collaboration. This fragmentation benefits Palantir's positioning as the semantic/intelligence layer that connects all other platforms, but it also limits Palantir's ability to capture the full enterprise AI wallet. The partnership approach (Databricks 100+ joint customers, Snowflake native integration, NVIDIA sovereign AI architecture) reflects a strategic acceptance of this market structure — Palantir wins by being the indispensable layer, not by replacing everything else.

The governance dimension is becoming increasingly decisive. As AI regulation fragments (the 10-year federal moratorium on state AI laws was stripped by a 99-1 Senate vote in July 2025, leaving a patchwork of state rules), enterprises need platforms with built-in compliance tooling. Palantir's "causal lineage" — the ability to trace every AI agent action back to specific data, logic, and governance rules — was originally designed for classified defense environments but is becoming a commercial differentiator as state-level AI laws proliferate. Competitors without built-in compliance architecture face rising friction costs that widen Palantir's moat incrementally with each new regulation.

## Key Metrics

| Metric | Value | Notes |
|--------|-------|-------|
| Market Cap | ~$240-355B | Mid-April 2026; volatile (tariff/DOGE sell-off from $207 ATH) |
| Share Price | ~$100-148 | Closed $148.46 Apr 3; declined since; highly volatile |
| EV/Revenue (trailing) | ~52-79x | On FY2025 $4.48B; depends on recent price |
| EV/Revenue (forward) | ~33-49x | On FY2026 guide $7.19B |
| Revenue Growth | +70% YoY (Q4); +61% guided FY2026 | Accelerating from +29% FY2025 full year |
| Gross Margin | ~81% | Q4 2025 estimate |
| GAAP Operating Margin | 41% | Q4 2025 |
| Adj. Operating Margin | 57% | Q4 2025; difference is primarily SBC |
| FCF Yield (trailing) | ~0.6-0.9% | FY2025 FCF >$2.2B / market cap |
| FCF Yield (forward) | ~1.1-1.7% | FY2026 FCF guide $4.025B / market cap |
| Q4 2025 Revenue | $1.41B | +70% YoY; beat high-end guidance by 900+ bps |
| Q1 2026 Revenue Guidance | $1.53-1.54B | ~+56% YoY implied |
| FY2026 Revenue Guidance | $7.18-7.20B | +61% YoY; U.S. Commercial >$3.14B (>115%) |
| FY2026 Adj. FCF Guidance | $4.025B | +77% YoY |
| Rule of 40 | 127% | Q4 2025 (revenue growth + FCF margin) |
| Customer Count | 954 | +34% YoY |
| U.S. Commercial RDV | $4.38B | +145% YoY; multi-year pipeline visibility |
| Net Revenue Retention | 139% | Strong expansion within existing customers |
| Bootcamp Conversion | ~75% | 5-day cycle; $1M+ average deal size |
| Top 20 Customer Avg Rev | $94M | Concentration risk (~42% of revenue) |
| Forward PEG | ~0.9-1.5 | At recent prices; vs SNOW at 3.3x |
| Analyst Consensus | Buy | Median target ~$197; range $70-$255 |
| Insider Selling Pace | ~$6M/day | Rule 10b5-1 plans; persistent technical supply |

## Bull Case

- **AI adoption is still early innings**: AIP bootcamp flywheel accelerates into 2027+ as the ~75% conversion rate compounds against a growing pipeline; $4.38B U.S. commercial RDV provides multi-year visibility
- **Sovereign AI becomes standard for NATO nations**: The NVIDIA partnership (Blackwell Ultra + Rubix + Apollo + AIP) opens a massive government TAM currently dominated by legacy defense IT that cannot deploy AI in classified environments
- **U.S. commercial sustains 100%+ growth**: Ontology becomes the de facto enterprise AI deployment architecture; customer base grows from 954 toward 2,000+ as AI FDE and OSDK lower the adoption threshold
- **Defense revenue floor provides downside protection**: $10B Army EA + $1.275B Maven + $448M ShipOS + NATO + UK MoD create a ~$1.2B+ annuity-like base that pure-play commercial AI companies lack
- **DOGE reshuffles defense IT spending in Palantir's favor**: Budget scrutiny eliminates legacy contractors; Palantir's demonstrated ROI metrics (160 hrs → 10 min at Electric Boat) make it the winner of every cost-benefit analysis
- **Warp Speed and ShipOS create a new "Industrial OS" category**: Manufacturing MES + supply chain + naval production worth tens of billions in TAM; early wins with L3Harris, GE Aerospace, Boeing, Lear validate the category
- **Forward PEG at recent prices (~0.9-1.5) is cheaper than Snowflake (3.3x)**: Growth-adjusted valuation is reasonable relative to enterprise software peers; any acceleration in commercial revenue would compress PEG further
- **Complementary positioning with ServiceNow expands addressable market**: Market re-rates from "competitive" to "complementary" framing, benefiting both companies
- **Price target range**: Analyst median ~$197; high-side $230-$255 (Wedbush, Citigroup)

## Bear Case

- **Extreme valuation requires near-perfect execution**: Even after a 35%+ correction, trailing P/E of ~130-240x leaves zero room for growth deceleration, margin compression, or guidance misses; any quarter of sub-50% revenue growth likely triggers severe multiple compression
- **Insider selling at ~$6M/day creates persistent downward pressure**: Scheduled or not, the aggregate selling pace exceeds institutional accumulation and creates a technical headwind that amplifies any fundamental weakness
- **Customer concentration risk is acute**: Top-20 customers generate ~42% of revenue (~$94M average each); a single loss in this tier would not only impact financials but erode the "N of 1" narrative
- **LLM commoditization narrows the Ontology moat over time**: Open-source models at 90%+ of frontier performance + "good enough" semantic layers from Databricks/Microsoft Fabric IQ could satisfy 80% of commercial use cases at a fraction of Palantir's cost, limiting TAM to the complex/regulated/defense niche
- **International commercial stall may be structural**: -10% YoY international commercial growth (Q1 2025) suggests the bootcamp model and defense-adjacent brand carry material friction outside the U.S.; geopolitical exposure (IDF contracts, NHS controversy) limits European expansion
- **SBC dilution erodes per-share value**: $1.57B in annual stock-based compensation represents ~35% of FY2025 revenue; GAAP vs. adjusted margin divergence (41% vs 57%) reflects the true cost of the compensation model
- **954 customers vs. 20,000+ for Databricks**: Distribution ceiling imposed by FDE model may be structural rather than temporary; the long tail of enterprise AI spend may never be addressable at Palantir's price point
- **Price risk**: Support at $95-100 (if correction continues); capitulation risk below $90 in a broad market sell-off

## Catalysts

- **Q1 2026 earnings** (expected May 2026): $1.53-1.54B revenue guide; any beat-and-raise on U.S. commercial trajectory would validate continued hypergrowth
- **NVIDIA Sovereign AI OS deployments ramping through 2026**: First production installations in NATO allies and Five Eyes nations could unlock large new government contracts
- **ShipOS expansion beyond initial $448M**: Success at General Dynamics Electric Boat creates a playbook for the broader maritime industrial base and defense prime contractors
- **Warp Speed adoption by additional industrial enterprises**: Manufacturing MES deployments at GE Aerospace, Boeing, Lear expanding into broader industrial categories
- **AI FDE general availability**: Democratizes Foundry operation via natural language; if successful, addresses the distribution ceiling concern by reducing FDE dependency
- **FY2026 U.S. commercial revenue exceeding $3.14B guide** (~115% YoY): Continued acceleration would force the market to price sustained hypergrowth rather than deceleration
- **International commercial inflection**: Any evidence of bootcamp success outside the U.S. would address the most significant growth concern
- **S&P 500 weight increase**: Continued market cap growth drives passive index buying
- **Potential DOGE-driven defense contract wins**: Legacy contractor displacement flowing to AI-native platforms

## Risks

1. **Valuation risk**: Extreme multiples require sustained hyper-growth; any quarter of sub-50% revenue growth triggers disproportionate drawdown. The 35%+ correction from ATH demonstrates this dynamic in practice.
2. **Insider selling**: ~$6M/day selling pace despite record fundamentals creates persistent technical headwind and raises questions about management's private valuation assessment
3. **Customer concentration**: Top-20 customers at ~$94M average each (~42% of revenue); a single loss materially impacts guidance and narrative
4. **LLM commoditization / "good enough" threat**: Databricks' Lakebase + Agent Bricks, Microsoft Fabric IQ, and open-source agent frameworks could commoditize the simpler commercial end of Palantir's market within 2-3 years
5. **Geopolitical/reputational risk**: IDF contracts and NHS controversy create brand liability in European commercial markets; "defense-adjacent" positioning limits TAM in ESG-sensitive sectors
6. **SBC dilution**: $1.57B annually; GAAP operating margin of 41% vs adjusted 57% reflects real economic dilution
7. **International commercial stagnation**: -10% YoY growth suggests structural friction, not temporary headwinds
8. **DOGE/federal budget risk**: Despite structural benefits, near-term Pentagon program cuts could create revenue gaps before defense budget growth materializes in 2027-2028
9. **FDE model scalability**: 954 customers vs. 20,000+ peers; AI FDE and OSDK are designed to address this but remain unproven at scale
10. **Macro/tariff risk**: Broad market sell-off driven by trade war escalation compresses all growth multiples regardless of company-specific fundamentals

## Related Research

- [[Research/2026-03-21 - PLTR - Gemini Strategy Canvas]] — Comprehensive strategy, product, financial, and valuation analysis (Gemini Canvas export)
- [[Research/2026-03-29 - PLTR - Gemini Automation Platforms Canvas]] — Palantir Ontology vs ServiceNow CMDB deep-dive: complementary not competitive
- [[Research/2026-03-29 - Palantir Comparison]] — Claude conversation: Palantir vs ServiceNow end-to-end automation platform analysis
- [[Research/2026-03-31 - Databricks Threat to Palantir]] — Claude conversation: Databricks competitive threat assessment, write-back gap analysis, Microsoft Fabric IQ convergence
- [[Research/2026-04-05 - ServiceNow CMDB vs Palantir Ontology]] — Claude conversation: Database architecture deep-dive, LLM-native data model comparison
- [[Research/2026-04-09 - ServiceNow CMDB Dependency and Limitations]] — Claude conversation: CMDB constraints, Knowledge Graph evolution, Salesforce Agentforce comparison
- [[Research/2026-04-15 - PLTR - Competitive Win Scenarios]] — Win scenario analysis: defense, supply chain, healthcare, manufacturing IoT
- [[Research/2025-02-19 - PLTR - Palantir Valuation Analysis]] — Grok valuation analysis: P/E 655 (Feb 2025), analyst consensus Hold, early growth data
- [[Research/2026-04-14 - NOW - AI Disruption Risk - deep-dive]] — AI disruption framework validating orchestration layer thesis; MCP/A2A protocol dynamics
- [[Theses/NOW - ServiceNow]] — Complementary enterprise AI positioning (Ontology vs CMDB)
- [[Theses/NET - Cloudflare]] — Adjacent enterprise software / edge AI thesis
- [[Sectors/Enterprise Workflow AI & Automation]]
- [[AI Bubble Risk and Semiconductor Valuations]]
- [[Research/2026-04-23 - Scenario - Iran Ground Invasion May 2026]] — Scenario: kinetic conflict accelerates defense procurement (Maven, Warp Speed, Alpamayo, ShipOS); NATO sovereign AI expansion
- [[Research/2026-05-11 - Private Credit BDC Redemption Gating Wave - news]] — Tangential: AI-driven margin compression on private-credit-financed software borrowers (TCPC ~33% of Q1 markdowns software-related); public-market platforms with strong FCF (PLTR Ontology) are the credit-cycle echo of the productivity-disruption beneficiary thesis
- [[Research/2026-06-04 - AI Dark Output GDP Measurement Gap - deep-dive]] — Macro lens: AI output is real but largely unmeasurable; "Captured AI Output" requires pricing power. Supports PLTR as the deployment layer that makes enterprise AI output visible/capturable (Ontology governed write-back); PLTR's own value capture rests on consumption pricing + 139% NRR holding
- [[Research/2026-06-11 - PLTR - Karp on Frontier Lab Discontent - news]] — Karp (CNBC): enterprises "unhappy" with frontier labs ("tokenmaxxing"), "implementation is where the value is" (next 7yrs), "most of Anthropic's public projects run on Palantir" — CEO-level color for the deployment-layer value-capture insight; self-serving source, Anthropic-on-PLTR claim unverified

## Log

### 2026-04-15
- [Major thesis restructure]: Complete rewrite to Thesis Template; consolidated 9 research sources (Gemini/ChatGPT/Claude/Grok); added all template-required sections; updated metrics to April 2026 — conviction unchanged (medium), status draft to active.

### 2026-04-15 (earlier)
- [Research sync]: Linked [[Research/2026-04-15 - PLTR - Competitive Win Scenarios]] — win scenarios across defense, supply chain, healthcare, manufacturing IoT — conviction unchanged.

### 2026-04-14
- [ChatGPT research integration]: Added insights from PLTR vs NOW AI comparison, AI regulation, AI bubble risk — conviction unchanged.
- [NOW research sync]: AI disruption analysis reinforces complementary thesis; MCP 97M monthly SDK downloads, multi-agent error amplification ~10x — strengthened (governance moat validation).
- [Grok ingestion]: Valuation analysis (P/E 655 Feb 2025, $74.59 avg target) — conviction unchanged.

### 2026-04-13
- [Initial thesis]: Created from two Gemini canvases (Strategy, Automation Platforms); Ontology as operational control plane with write-back, complementary to ServiceNow — conviction set at medium.

### 2026-04-22
- Sector re-scoped: Enterprise Software & Defense → Enterprise Workflow AI & Automation (vault-wide subsector taxonomy reorganization).
- Wikilink cleanup: Replaced `[[Sectors/Enterprise Software]]` and `[[Sectors/Defense & Geopolitics]]` → `[[Sectors/Enterprise Workflow AI & Automation]]` in Related Research section during sector-fill of [[Sectors/Enterprise Workflow AI & Automation]].

### 2026-04-23
- Scenario [[Research/2026-04-23 - Scenario - Iran Ground Invasion May 2026]]: positive via kinetic-conflict defense procurement acceleration (Maven, Warp Speed, Alpamayo, ShipOS, TITAN); NATO sovereign AI $30B+ expansion — conviction strengthened: ground invasion is textbook demand trigger for AI-native defense platforms; DOGE budget rationalization + active-threat combine to favor Palantir's demonstrated-ROI model over legacy contractors.

### 2026-04-27
- Addressed user callouts: PLTR — addressed `[!question]` on competitive moat / patent protection in §Industry Context; added new subsection "Why the Ontology Resists Replication: Structural Moats vs. Patent Protection" covering 5 structural barriers (architectural inversion, MMDP atomic write-back, ontology library flywheel, security certifications, FDE talent) — conviction unchanged: structural moats compound faster than 2010-2015 architecture patents expire (2030-2035), making patent duration non-determinative for thesis horizon.

### 2026-05-01 (/sync)
- [[Research/2026-04-24 - Luo Fuli on OpenClaw and Agent-Era Compute Reallocation - video-transcript]]: Frontier-lab framing of agent moat as "meticulously orchestrated context engineering" directly validates Ontology-as-control-plane thesis — context-substrate moat compounds in agent era. Conviction unchanged.
- [[Research/2026-04-24 - Thomas Kurian on TPU Capacity Anthropic Hosting and Agentic Chip Design - video-transcript]]: Hyperscaler agentic-chip co-design (Wiz cybersecurity agents, Gemini Enterprise +60% in 3 months) signals enterprise-AI inflection; PLTR's defense-grade Ontology positioned ahead of commoditized agent layer. Conviction unchanged.
- [[Research/2026-04-22 - Marc Andreessen on Internet Media Fragmentation and Outrage Cycles - video-transcript]]: Tangential AI-policy/dark-money mention; no thesis-moving evidence. Conviction unchanged.

### 2026-05-11 (/sync)
- [[Research/2026-05-11 - Private Credit BDC Redemption Gating Wave - news]]: Tangential — AI productivity disruption destroying private-credit-financed cash-burning software borrowers (TCPC ~33% of Q1 markdowns software-related); public-market platforms with strong FCF (PLTR Ontology) are the credit-cycle echo of the productivity-disruption beneficiary thesis. Conviction unchanged — no direct PLTR operating signal.

### 2026-05-22 (manual)
- Status change: portfolio-wide alignment — confirmed as current Live Portfolio holding; conviction medium→high.

### 2026-06-05 (/sync)
- [[Research/2026-06-04 - AI Dark Output GDP Measurement Gap - deep-dive]]: SemiAnalysis "Dark Output" reframes the bubble's monetization gap as a capture (not output) problem — supports PLTR's deployment-layer "extract-ROI" positioning; value capture rests on Ontology pricing power + 139% NRR holding. Conviction unchanged (high) — macro framing, no direct PLTR signal.

### 2026-06-11 (/sync)
- [[Research/2026-06-11 - PLTR - Karp on Frontier Lab Discontent - news]]: Karp (CNBC) — enterprises "unhappy" with frontier-lab "tokenmaxxing," "implementation is where the value is," "most of Anthropic's public projects run on Palantir" — CEO-level corroboration of the deployment-layer value-capture insight. Conviction unchanged (high) — self-serving source, Anthropic-on-PLTR unverified, no new operating signal.
